function [p_value,add] = Backtesting(conditional,returns_y,VaRy,alpha_y,vareps)
%% Backtesting: Backtesting for marginal model
%
%% SYNTAX:
%        [p_value,add] = Backtesting(conditional,returns_y,alpha_x,vareps)
%
%% INPUT:
%              conditional:
%                   0 --> Kupiec
%                   1 --> Christoffresen
%              returns: time-series of returns
%              weights_y: Weights from each state.
%              mu_y : Conditional mean for t+1 in the model
%              sigma2_y : Conditional variance for t+1 in the model
%              alpha_y : significance level of the VaR (0.01,0.05,0.1)
%              vareps : significance level of the test (0.01,0.05,0.1)
%
%% OUTPUT:
%               p_value : p-value
%               ADD: if conditional --> 0
%                     Column vector, each row says:
%                       #1 : lim inf of number of exceedances for not refusing H0
%                       #2 : lim sup of number of exceedances for not refusing H0
%                       #3 : number of exceedances
%                       #4 : number of observations
%                    if conditional --> 1
%                     Column vector, each row says:
%                       #1 : t00 (no exceedences yesterday neither today)
%                       #2 : t01 (exceedences yesterday but not today)
%                       #3 : t10 (no exceedences yesterday but today yes)
%                       #4 : t11 (exceedences yesterday and today)
%
%% Javier Ojea Ferreiro 20/07/2017
%
T=length(VaRy);
Tx=T;
tt=2:T; %for checking outliers I see from the second to the last observation
%VaR is computed at each value using the mean and sigma for t+1, so I
%choose from the 1 value to T-1
ttplus=3:T; %for checking exceedences at t1x
ttminus=2:T-1; %for checking exceedences at tx1

% ttMinus1=2:T-1;
I=(returns_y(tt)<=VaRy(tt-1)); %VaR (expressed as returns) at t are the maximum losses for t+1
It1x=(returns_y(ttplus)<=VaRy(ttplus-1));
Itx1=(returns_y(ttminus)<=VaRy(ttminus-1));

%% Kupiec
if conditional==0 %Kupiec's Backtesting
    X=sum(I); %number of exceedences
    %% Statistic for the contrast
    LR=(alpha_y^(X)*(1-alpha_y)^(Tx-X)) / (((Tx-X)/Tx)^(Tx-X)*(X/Tx)^(X));
    if (Tx==0) %
        p_value=NaN;
        x1=NaN;
        x2=NaN;
    else
        if LR==0 % problems in the 
            LR=(alpha_y^(X))/(((Tx-X)/Tx)^(Tx-X)*(X/Tx)^(X)).*...
                (1-alpha_y)^(Tx-X);
    % 
        end
            %% p-value
            critiquevalue = -2*log(LR);
            fun = @(P) critiquevalue-chi2inv(1-P,1);
            p_value = lsqnonlin(fun,0.1,0,1);
            %% non rejection interval
            fun2 = @(x) (-chi2inv(1-vareps,1)-2*log((alpha_y^(x)*(1-alpha_y)^(Tx-x))/(((Tx-x)/Tx)^(Tx-x)*(x/Tx)^(x))));
%             x1(1,1)=lsqnonlin(fun2,0,0,Tx); % lower bound
%             x1(1,1)= ceil(x1(1,1)); %round
%             x2(1,1)=lsqnonlin(fun2,round(Tx/25),x1(1,1)+1,Tx); %upper bound
%             x2(1,1)=floor(x2(1,1)); %round
            cc=0;
            for t=1:Tx+1
                if isinf(fun2(t-1))==0
                    cc=cc+1;
                    x(cc)=t-1;
                    f_x(cc)=fun2((t-1));
                end
            end
            points=find([0,diff(f_x>0)~=0]);
%%
                x1(1,1)=lsqnonlin(fun2,0,0,x(points(1))); % lower bound
                x1(1,1)= ceil(x1(1,1)); %round
                x2(1,1)=lsqnonlin(fun2,x(points(2))-1,x(points(2))-2,Tx); %upper bound
                x2(1,1)=floor(x2(1,1)); %round

    add=[x1;x2;X;Tx]; %Column vector
    end
  
    
%% Christoffersen    
elseif conditional==1
    t00=0; %count
    t01=0;
    t10=0;
    t11=0;
    if (Tx==0) %
        p_value=NaN;
        add=NaN(4,1);
    else
    for i=1:Tx-2 %count couple of exceedences
        couple(i,:)=[It1x(i),Itx1(i)];
        if couple(i,:)==[0,0]
            t00=t00+1;
        elseif couple(i,:)==[0,1]
            t01=t01+1;
        elseif couple(i,:)==[1,0]
            t10=t10+1;
        elseif couple(i,:)==[1,1]
            t11=t11+1;
        end
    end
    p01=t01/(t00+t01);
    p11=t11/(t10+t11);
    p=(t01+t11)/(Tx-1);
    
    if (isnan(p01)) || (p01 == 0)
        p01 = eps;
    end
    if isnan(p11) || (p01 == 0)
        p11 = eps;
    end
    
         %% Statistic for the contrast
    LR=(p/p01)^t01*(p/p11)^t11*((1-p)/(1-p01))^t00*((1-p)/(1-p11))^t10;
     %% p value
    critiquevalue=-2*log(LR);
    fun = @(P)critiquevalue-chi2inv(1-P,1);
    if isnan(critiquevalue)==1 %
       p_value=NaN();
    else
       p_value=lsqnonlin(fun,0.5,0,1);
    end
    add= [t00;t01;t10;t11]; %Column vector
    end
end

            
