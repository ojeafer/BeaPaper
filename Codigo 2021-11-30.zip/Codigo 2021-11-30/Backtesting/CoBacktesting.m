function [p_value,add]=CoBacktesting(conditional,returns_x,returns_y, VaRx,CoVaRy, beta, vareps)
%[p_value,add]=CoBacktesting(conditional,returns_y,returns_x,param_y,param_x, mu_y, mu_x,  sigma2_y,sigma2_x, alpha, beta vareps)
%% Backtesting: Backtesting about the CoVaR 
%
%% SYNTAX:
%        [p_value,x1,x2]=Backtesting(conditional,param_j, sigma2_j, innovation_j, returns_j, CoVaR_ij, returns_i, alpha_i, vareps)
%
%% INPUT:
%              conditional:
% 0 --> Kupiec
% 1 --> Christoffresen
%               alpha_i : confidence level for the conditioned event --> Introudced CoVaR
% MUST HAVE the same alpha_i
%               alpha_j : confidence level for the conditioning event
%               param_j : parameters of the marginal distribution for the conditioning
% institution
%               sigma2_j : time-series conditional variance for the conditioning
% institution
%               innovation_j : innovation for the onditioning institution
%               returns_j : returns of the conditioning institution
%               CoVaR_ij : CoVaR of the institution i conditionaed to institution j
%               returns_i : returns of the conditioned institution
%               alpha_i : level of confidence of the CoVaR_ij
%               vareps : significance level of the test
%% OUTPUT:
%               p_value : p-value o
%               x1 : lim inf of number of exceedances for not refusing H0
%               x2 : lim sup of number of exceedances for not refusing H0
%% Javier Ojea Ferreiro 20/07/2017


%%
% T=length(mu_y);
% VaRx=CoVaR(alpha*ones(T,1),param_x,mu_x,sigma2_x);
T=length(VaRx);
 Ix=(returns_x(2:end)<=VaRx); %exceedances for the conditioning institution
 Ix=[0;Ix];
 moment=find(Ix==1); %disstress moments for conditioning institution
 Tx=sum(Ix); %length of the distress moments for the conditioning institution
 tt=2:T;%for checking outliers I see from the second to the last observation
%VaR is computed at each value using the mean and sigma for t+1, so I
%choose from the 1 value to T-1
ttplus=3:T; %for checking exceedences at t1x
tt_con=2:Tx; %for checking exceedences at tx1
Iyx=(returns_y(moment)<=CoVaRy(moment-1)); %CoVaR at t-1 are the maximum losses for t
if conditional==0 %Kupiec's Backtesting
    X=sum(Iyx); %number of exceedences
    %% Statistic for the contrast
    LR=(beta^(X)*(1-beta)^(Tx-X))/(((Tx-X)/Tx)^(Tx-X)*(X/Tx)^(X));
    if (Tx==0) %
        p_value=NaN;
        x1=NaN;
        x2=NaN;
    else
    %% p-value
    critiquevalue=-2*log(LR);
    fun = @(P) critiquevalue-chi2inv(1-P,1);
    p_value=lsqnonlin(fun,0.1,0,1);
     %% non rejection interval
        fun2 = @(x) (-chi2inv(1-vareps(1),1)-2*log((beta^(x)*(1-beta)^(Tx-x))/(((Tx-x)/Tx)^(Tx-x)*(x/Tx)^(x))));
       cc=0;
            for t=1:Tx+1
                if isinf(fun2(t-1))==0
                    cc=cc+1;
                    x(cc)=t-1;
                    f_x(cc)=fun2((t-1));
                end
            end
            points=find([0,diff(f_x>0)~=0]);
%%
                x1(1,1)=lsqnonlin(fun2,x(points(1)-1),0,x(points(1))); % lower bound
                x1(1,1)= ceil(x1(1,1)); %round
                x2(1,1)=lsqnonlin(fun2,x(points(2))-1,x(points(2))-2,Tx); %upper bound
                x2(1,1)=floor(x2(1,1)); %round
    end 
    add=[x1;x2;X;Tx];%Column vector
elseif conditional==1
    t00=0;%count
    t01=0;
    t10=0;
    t11=0;
    if (Tx==0) %
        p_value=NaN;
        add=NaN(4,1);
    else
    for i=2:Tx %count couple of exceedences
        couple=[Iyx(i-1),Iyx(i)];
        if couple==[0,0]
            t00=t00+1;
        elseif couple==[0,1]
            t01=t01+1;
        elseif couple==[1,0]
            t10=t10+1;
        elseif couple==[1,1]
            t11=t11+1;
        end
    end
 p01=t01/(t00+t01);
 p11=t11/(t10+t11);
 p=(t01+t11)/ (Tx-1);
     %% Statistic for the contrast
 LR=(p/p01)^t01*(p/p11)^t11*((1-p)/(1-p01))^t00*((1-p)/(1-p11))^t10;
 %% p value
 critiquevalue=-2*log(LR);
 fun = @(P)critiquevalue-chi2inv(1-P,1);
 if isnan(critiquevalue)==1 %
     p_value=NaN();
 else
 p_value=lsqnonlin(fun,0.5,0,1);
 end
 add= [t00;
    t01;
    t10;
    t11];%Column vector
    end
end