function [percentage_exc, pVal_K, pVal_C] = VaR_backtesting(r,mu,sigma2,nu,lambda,alpha_bt,vec_tau)

difobs = length(sigma2) - length(mu) + 1;

% alpha_bt = 0.05; % Level of significance of the test

% vec_tau = [0.01, 0.025, 0.05, 0.1]; % Level of significance of the VaR
conditional = [0, 1];

for i = 1:length(vec_tau)
    tau = vec_tau(i);
    % VaR at tau% significance level
    VaRSt(:,i) = skewtdis_inv(tau,nu,lambda)*sqrt(sigma2) + mu;
  
    % Excedances of VaR
    for t = 2:length(r)
        Ind_St(t) = sum(r(t) <= VaRSt(t-1,i));
    end
    excSt(i) = sum(Ind_St)/size(VaRSt,1) * 100;
    
    % VaR Backtesting
    for c = 1:length(conditional) 
        cond = conditional(c); % Conditional=0 -> Kupiec; Conditional=1 -> Christoffersen
        [p_valueSt(c,i),addSt(:,i+length(vec_tau)*cond)] = Backtesting(cond,r,VaRSt(2:end,i),tau,alpha_bt);
    end    
    
%     % Plot VaR
%     figure(i); 
%     haxes = axes();
%     plot(datewt(difobs:end),[r_st(difobs-1:end),VaRSt(:,i)])
%     legend('Stock returns','VaR($\tau$), Skewed Student t distribution','interpreter','latex')
%     ylabel('Returns','interpreter','latex')
%     xlabel('Date','interpreter','latex')
%     set(haxes,'TickLabelInterpreter','latex')
%     if tau == 0.01
%         title('Nikkei225 returns vs VaR($\tau=1\%$)','interpreter','latex')
%     elseif tau == 0.025
%         title('Nikkei225 returns vs VaR($\tau=2.5\%$)','interpreter','latex')
%     elseif tau == 0.05
%         title('Nikkei225 returns vs VaR($\tau=5\%$)','interpreter','latex')
%     elseif tau == 0.1
%         title('Nikkei225 returns vs VaR($\tau=10\%$)','interpreter','latex')
%     end
end

pVal_K = p_valueSt(1,:)';
pVal_C = p_valueSt(2,:)';
percentage_exc = excSt'; 

