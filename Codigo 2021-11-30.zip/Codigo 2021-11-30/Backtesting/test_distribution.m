function [pValue, h0, table_tests] = test_distribution(z,nu_t,nu_St,lambda_St,alpha_level)

%% Generate theorical distribution
cdf_t = tinv(rand(length(z),1),nu_t);
cdf_St = skewtdis_inv(rand(length(z),1),nu_St,lambda_St); % Skewed Student t distribution


%% Tests
for i = 1:length(alpha_level)
    alpha = alpha_level(i);
    
    % 1) TEST IF RESIDS ARE WHITE NOISE AND IF THERE ARE ARCH EFFECTS
    %   - Ljung-Box
    [h0_LBQ(i),pV_LBQ(i)] = lbqtest(z);

        %   - ARCH (Engle)
    [h0_ARCH(i),pV_ARCH(i)] = archtest(z);


    % 2)VERIFY THE RESIDUALS' DISTRIBUTION
    %   - Jarque-Bera (Normality)
    [h0_JB(i),pV_JB(i)] = jbtest(z,alpha);

    %   - Kolmogorov-Smirnov
    [h0_KS_N(i),pV_KS_N(i)] = kstest(z,'Alpha',alpha); % Normal distribution
    [h0_KS_t(i),pV_KS_t(i)] = kstest2(z,cdf_t,'Alpha',alpha); % Student t distribution
    [h0_KS_St(i),pV_KS_St(i)] = kstest2(z,cdf_St); % Skewed Student t distribution

    %   - Anderson-Darling
    [h0_AD_N(i),pV_AD_N(i)] = adtest(z,'Distribution','normal');   % Normal
    [ADStat_t(i), pV_AD_t(i)] = AnDarksamtest([[z; cdf_t],...
                    [ones(length(z),1); 2*ones(length(z),1)]]); % Student t      
        if pV_AD_t(i) <= alpha
            h0_AD_t(i) = 1;
        else
            h0_AD_t(i) = 0;
        end
    [ADStat_St(i), pV_AD_St(i)] = AnDarksamtest([[z; cdf_St],...
                    [ones(length(z),1); 2*ones(length(z),1)]]); % Skewed Student t
        if pV_AD_St(i) <= alpha
            h0_AD_St(i) = 1;
        else
            h0_AD_St(i) = 0;
        end

end


 %% Outputs
pValue = [pV_LBQ(1); pV_ARCH(1);
          pV_KS_N(1); pV_KS_t(1); pV_KS_St(1);
          pV_AD_N(1); pV_AD_t(1); pV_AD_St(1)];
h0 = [h0_LBQ; h0_ARCH;
      h0_KS_N; h0_KS_t; h0_KS_St;
      h0_AD_N; h0_AD_t; h0_AD_St]; 

test_name = { 'Ljung-Box                                 ';
              'ARCH (Engle)                              ';
              'Kolmogorov-Smirnov (Normal dist)          ';
              'Kolmogorov-Smirnov (Student t dist)       ';
              'Kolmogorov-Smirnov (Skewed Student t dist)';
              'Anderson-Darling (Normal dist)            ';
              'Anderson-Darling (Student t dist)         ';
              'Anderson-Darling (Skewed Student t dist)  '};      
table_tests = table(pValue,h0,'RowNames',test_name);      
disp('    * Values of h0 equal to 0 indicate a failure to reject the null');