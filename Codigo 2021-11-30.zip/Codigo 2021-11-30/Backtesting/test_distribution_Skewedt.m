function [pValue, h0, table_tests] = test_distribution_Skewedt(z,nu,lambda,alpha_level)

%% Generate theorical distribution
cdf_St = skewtdis_inv(rand(length(z),1),nu,lambda); % Skewed Student t distribution


%% Tests
for i = 1:length(alpha_level)
    alpha = alpha_level(i);
    
    % 1) TEST IF RESIDS ARE WHITE NOISE AND IF THERE ARE ARCH EFFECTS
    %   - Ljung-Box
    [h0_LBQ(i),pV_LBQ(i)] = lbqtest(z);

        %   - ARCH (Engle)
    [h0_ARCH(i),pV_ARCH(i)] = archtest(z);


    % 2)VERIFY THE RESIDUALS' DISTRIBUTION
    %   - Jarque-Bera (Normality)
    [h0_JB(i),pV_JB(i)] = jbtest(z,alpha);

    %   - Kolmogorov-Smirnov
    [h0_KS_St(i),pV_KS_St(i)] = kstest2(z,cdf_St); % Skewed Student t distribution

    %   - Anderson-Darling
    [ADStat_St(i), pV_AD_St(i)] = AnDarksamtest([[z; cdf_St],...
                    [ones(length(z),1); 2*ones(length(z),1)]]); % Skewed Student t
        if pV_AD_St(i) <= alpha
            h0_AD_St(i) = 1;
        else
            h0_AD_St(i) = 0;
        end

end


 %% Outputs
pValue = [pV_LBQ(1); pV_ARCH(1); pV_KS_St(1); pV_AD_St(1)];
h0 = [h0_LBQ; h0_ARCH; h0_KS_St; h0_AD_St]; 

test_name = { 'Ljung-Box         ';
              'ARCH (Engle)      ';
              'Kolmogorov-Smirnov';
              'Anderson-Darling  '};      
table_tests = table(pValue,h0,'RowNames',test_name);      
disp('    * Values of h0 equal to 0 indicate a failure to reject the null');