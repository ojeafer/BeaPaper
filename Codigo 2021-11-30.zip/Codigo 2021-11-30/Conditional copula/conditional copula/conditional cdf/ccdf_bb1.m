function q=ccdf_bb1(u1,u2,paramhat)
%% ccdf_bb1: Conditional bb1 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb1(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb1 copula
%
%% Javier Ojea Ferreiro 20/06/2018
% u1 = 0.9710;
% u2 = 0.1247;
% paramhat = [277.7958, 1.0214];

%%
theta=paramhat(:,1);
delta=paramhat(:,2);
A=(u1.^(-theta)-1);
B=(u2.^(-theta)-1);
q=(1+(A.^delta+B.^delta).^(1./delta)).^(-(1+theta)./theta).*...
    (A.^(delta)+B.^(delta)).^(1./delta-1).*A.^(delta-1).*u1.^(-theta-1);
% q=max(min(q,1-5e-6),5e-6);