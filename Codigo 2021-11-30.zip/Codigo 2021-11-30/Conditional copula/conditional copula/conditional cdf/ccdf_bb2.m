function q=ccdf_bb2(u1,u2,paramhat)
%% ccdf_bb2: Conditional bb2 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb2(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb2 copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
A=log(exp(delta.*(u1.^(-theta)-1))+exp(delta.*(u2.^(-theta)-1))-1);
q=(1+delta.^(-1).*A).^(-(theta+1)./theta).*(exp(delta.*(u1.^(-theta)-1))+...
    exp(delta.*(u2.^(-theta)-1))-1).^(-1).*exp(delta.*(u1.^(-theta)-1)).*...
    u1.^(-theta-1);