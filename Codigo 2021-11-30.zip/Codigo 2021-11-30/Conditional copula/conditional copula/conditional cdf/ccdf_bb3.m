function q=ccdf_bb3(u1,u2,paramhat)
%% ccdf_bb3: Conditional bb3 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb3(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb3 copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
u1_hat=-log(u1);
u2_hat=-log(u2);
x=exp(delta.*u1_hat.^(theta));
y=exp(delta.*u2_hat.^(theta));
A=x+y-1;
q=exp(-(delta.^(-1).*log(A)).^(1./theta)).*delta.^(1-1./theta).*...
    (log(A)).^(1./theta-1).*A.^(-1).*x.*u1_hat.^(theta-1)./u1;