function q=ccdf_bb5(u1,u2,paramhat)
%% ccdf_bb5: Conditional bb5 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb5(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb5 copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
u1_hat=-log(u1);
u2_hat=-log(u2);
A=u1_hat.^(theta)+u2_hat.^(theta)-...
    (u1_hat.^(-theta.*delta)+u2_hat.^(-theta.*delta)).^(-1./delta);
q=(exp(-A.^(1/theta)).*A.^(1./theta-1))./u1.*...
    (u1_hat.^(theta-1)-u1_hat.^(-theta.*delta-1).*...
    (u1_hat.^(-theta.*delta)+u2_hat.^(-theta.*delta)).^(-1./delta-1));