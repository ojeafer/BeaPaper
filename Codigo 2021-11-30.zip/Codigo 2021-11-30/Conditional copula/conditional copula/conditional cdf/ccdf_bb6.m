function q=ccdf_bb6(u1,u2,paramhat)
%% ccdf_bb6: Conditional bb6 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb6(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb6 copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
u1_bar=1-u1;
u2_bar=1-u2;
A=(-log(1-u1_bar.^(theta)));
B=(-log(1-u2_bar.^(theta)));
q=(1-exp(-(A.^delta+B.^delta).^(1./delta))).^(1./theta-1).*...
    exp(-(A.^delta+B.^delta).^(1./delta)).*(A.^delta+B.^delta).^(1./delta-1).*...
    A.^(delta-1).*u1_bar.^(theta-1)./(1-u1_bar.^(theta));