function q=ccdf_bb7(u1,u2,paramhat)
%% ccdf_bb7: Conditional bb7 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb7(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb7 copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
C=(1-(1-u1).^theta);
B=(C.^(-delta)+(1-(1-u2).^(theta)).^(-delta)-1);
A=1-B.^(-1./delta);
q=A.^(1./theta).*B.^(-1./delta-1).*C.^(-delta-1).*(1-u1).^(theta-1);
