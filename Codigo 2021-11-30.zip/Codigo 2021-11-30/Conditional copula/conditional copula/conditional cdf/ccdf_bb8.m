function q=ccdf_bb8(u1,u2,paramhat)
%% ccdf_bb8: Conditional bb8 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb8(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb8 copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
A=(1-delta.*u1);
B=(1-delta.*u2);
C=(1-A.^(theta)).*(1-B.^(theta))./(1-(1-delta).^(theta));
q=(1-C).^(1./theta-1).*(1-B.^(theta)).*A.^(theta-1)./(1-(1-delta).^(theta));
