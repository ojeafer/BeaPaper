function q=ccdf_clayton(u1,u2,paramhat)
%% ccdf_clayton: Conditional clayton copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_clayton(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2: quantile for the conditioned institution
%        paramhat: parameter theta
%% OUTPUT:
%         q: Conditional distribution of the clayton copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
if theta<15e-3 % theta=0 --> independence
    q=u2;
else
    q=(u1.^(-theta)+u2.^(-theta)-1).^(-(1+theta)./theta) .* u1.^(-theta-1);
end