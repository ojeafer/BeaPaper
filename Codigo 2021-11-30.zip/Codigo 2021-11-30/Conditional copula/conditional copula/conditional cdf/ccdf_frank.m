function q=ccdf_frank(u1,u2,paramhat)
%% ccdf_frank: Conditional frank copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_frank(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameter theta 
%% OUTPUT:
%         q : Conditional distribution of the frank copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
q=(1+((exp(-theta.*u1)-1).*(exp(-theta-u2)-1))./(exp(-theta)-1)).^(-1).*...
    (exp(-theta)-1).^(-1).*(exp(-theta.*u2)-1).*exp(-theta.*u1);
