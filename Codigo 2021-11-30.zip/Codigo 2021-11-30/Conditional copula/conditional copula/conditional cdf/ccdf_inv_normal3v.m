function u = ccdf_inv_normal3v(u1,u2,q,paramhat)
%% ccdf_inv_normal: Conditional gaussian copula inverse cumulative distribution function
%% ccdf_inv = C^{-1}_{3|1,2}(u3|u1,u2)
% C_{3|1,2}(u3|u1,u2)=q --> C^{-1}_{3|1,2}(q|u1,u2)=u3
%
%% SYNTAX:
%        u = ccdf_inv_normal(u1,u2,q,paramhat)
%
%% INPUTS:
%        u1: quantile for the first conditioning asset
%        u2: quantile for the second conditioning asset
%        q: conditional distribution of the gaussian copula
%        paramhat: parameters rho from the gaussian copula
%           paramhat(1) = rho12
%           paramhat(2) = rho13
%           paramhat(3) = rho23
%
%% OUTPUT:
%        u: quantile for the conditioned institution = inverse cdf of the copula
%
%%
u1 = min(u1,1-1e-5);
u2 = min(u2,1-1e-5);
q = min(q,1-1e-5);
u1 = max(u1,1e-5);
u2 = max(u2,1e-5);
q = max(q,1e-5);

%% Parameters
param12 = paramhat(1);
param13 = paramhat(2);
param23 = paramhat(3);


%% Conditional trivariate copula
% u_int = norminv(q)*omega3*sqrt(1-param13^2-(param23-param12*param13)^2/(1-param23^2)) + ...
%         norminv(u1)*omega1*param13 + ...
%         norminv(u2)*omega2*(param23-param12*param13)^2/(1-param12^2);
u_int = norminv(q)*real(sqrt(1-param13^2-(param23-param12*param13)^2/(1-param23^2))) + ...
        norminv(u1)*param13 + ...
        norminv(u2)*(param23-param12*param13)^2/(1-param12^2);
u = normcdf(u_int);


end