function q=ccdf_joe(u1,u2,paramhat)
%% ccdf_joe: Conditional joe copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_joe(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameter theta
%% OUTPUT:
%         q : Conditional distribution of the joe copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
A=(1-u1);
B=(1-u2);
q=(A.^(theta)+B.^(theta)-A.^(theta).*B.^(theta)).^(1./theta-1).*A.^(theta-1).*(1-B.^(theta));
