function q=ccdf_normal(u1,u2,paramhat)
%% ccdf_normal: Conditional gaussian copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_normal(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameter rho from the gaussian copula
%% OUTPUT:
%        q: Conditional distribution of the gaussian copula
%
%% Javier Ojea Ferreiro 20/06/2018
u2=min(u2,1-1e-5);
u1=min(u1,1-1e-5);
u2=max(u2,1e-5);
u1=max(u1,1e-5);
%%
q=normcdf((norminv(u2)-paramhat.*norminv(u1))./sqrt(1-paramhat.^2));
% u2=normcdf(norminv(q)*sqrt(1-paramhat^2)+paramhat.*norminv(u1));