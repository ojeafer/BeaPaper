function q = ccdf_normal3v(u1,u2,u3,paramhat)
%% ccdf_normal3v: Conditional gaussian copula cumulative distribution function for three variables
%% ccdf = dC(u1,u2,u3)/du1du2 = P(U3<u3 | U1=u1,U2=u2) = C_{3|1,2}(u3|u1,u2)
%
%% SYNTAX:
%        q = ccdf_normal3v(u1,u2,u3,paramhat)
%
%% INPUTS:
%        u1: quantile for the first conditioning asset
%        u2: quantile for the second conditioning asset
%        u3: quantile for the conditioned institution
%        paramhat: parameters rho from the gaussian copula
%           paramhat(1) = rho12
%           paramhat(2) = rho13
%           paramhat(3) = rho23
%
%% OUTPUT:
%        q: Conditional distribution of the gaussian copula
%
%%
u1 = min(u1,1-1e-5);
u2 = min(u2,1-1e-5);
u3 = min(u3,1-1e-5);
u1 = max(u1,1e-5);
u2 = max(u2,1e-5);
u3 = max(u3,1e-5);

%% Parameters
param12 = paramhat(1);
param13 = paramhat(2);
param23 = paramhat(3);

%% Conditional trivariate copula
q_int = norminv(u3) - param13*norminv(u1)...
    - (param23-param12*param13)/sqrt(1-param12^2) * norminv(u2);
q_int = q_int / sqrt(1 - param13^2 - (param23-param12*param13)^2/(1-param12^2));
q = normcdf(q_int);

% q=normcdf((norminv(u2)-paramhat.*norminv(u1))./sqrt(1-paramhat.^2));


end