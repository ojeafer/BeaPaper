function q=ccdf_plackett(u1,u2,paramhat)
%% ccdf_plackett: Conditional plackett copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_plackett(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameter theta
%% OUTPUT:
%         q : Conditional distribution of the plackett copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
B=(1+(theta-1).*(u1+u2));
C=4.*theta.*(theta-1).*u1.*u2;

if theta<1e-3;
    q=u2;
else
    q=1/2.*(1-(B-2.*theta.*u2)./((B.^2-C).^(1/2)));
end