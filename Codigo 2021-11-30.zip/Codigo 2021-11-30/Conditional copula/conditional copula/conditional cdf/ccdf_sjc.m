function q=ccdf_sjc(u1,u2,paramhat)
%% ccdf_sjc: Conditional sjc copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_sjc(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the sjc copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta=paramhat(:,1);
delta=paramhat(:,2);
q=0.5.*(ccdf_bb7(u1,u2,paramhat)-ccdf_bb7(1-u1,1-u2,paramhat)+1);