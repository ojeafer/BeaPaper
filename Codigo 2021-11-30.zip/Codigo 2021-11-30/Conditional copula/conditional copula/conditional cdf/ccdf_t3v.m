function q = ccdf_t3v(u1,u2,u3,nu,paramhat)
%% ccdf_t3v: Conditional Student t copula cumulative distribution function for three variables
%% ccdf = dC(u1,u2,u3)/du1du2 = P(U3<u3 | U1=u1,U2=u2) = C_{3|1,2}(u3|u1,u2)
%
%% SYNTAX:
%        q = ccdf_t3v(u1,u2,u3,nu,paramhat)
%
%% INPUTS:
%        u1: quantile for the first conditioning asset
%        u2: quantile for the second conditioning asset
%        u3: quantile for the conditioned institution
%        nu: degrees of freedom of the joint distribution
%        paramhat: parameters rho from the Student t copula (dcc)
%           paramhat(1) = rho12
%           paramhat(2) = rho13
%           paramhat(3) = rho23
%
%% OUTPUT:
%        q: Conditional distribution of the Student t copula
%
%%
u1 = min(u1,1-1e-5);
u2 = min(u2,1-1e-5);
u3 = min(u3,1-1e-5);
u1 = max(u1,1e-5);
u2 = max(u2,1e-5);
u3 = max(u3,1e-5);

%% Parameters
param12 = paramhat(1);
param13 = paramhat(2);
param23 = paramhat(3);

v = nu+2; % The DoF of the copula (v) is the DoF obtained in DCC-GARCH plus 
% the number of conditioning variables: v = nu + p1

%% Conditional trivariate copula
q_int = tinv(u3,v) - param13*tinv(u1,v)...
    - (param23-param12*param13)/sqrt(1-param12^2) * tinv(u2,v);
q_int = q_int / sqrt(1 - param13^2 - (param23-param12*param13)^2/(1-param12^2));

scal_fact = v ./ (v + (tinv(u1,v)).^2 + (tinv(u2,v)).^2); % Scaling factor
q_int = scal_fact .* q_int;

q = tcdf(q_int,v);


end