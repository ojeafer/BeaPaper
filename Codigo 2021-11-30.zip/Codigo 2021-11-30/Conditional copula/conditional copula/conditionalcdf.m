function q=conditionalcdf(copulatype,paramhat,u1,u2)
%% qquantile_curve: conditional probability (q) of  variable u2 given a 
%%                 quantile of variable u1 , a type of copula and its parameter. 
%% SYNTAX:
%        q=conditionalcdf(copulatype,paramhat,u1,u2)
%
%% INPUT:
%           copulatype = 
%                        Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%           theta : copula parameter
%           u1 : quantile of variable u1
%           u2 : value for u2 
%          
%% OUTPUT:
%           q: conditional probability of looking a value equal or
%           lower than u2 given u1
%% NOTES:
%C^{90R}(u1,u2)=u2-C(1-u1,u2)
% dC^{90R}(u1,u2)/du1=q-->C(u2|1-u1)=q
%C^{180R}(u1,u2)=u1+u2-1+C(1-u1,1-u2)
% dC^{180R}(u1,u2)/du1=q-->1-C(1-u2|1-u1)=q
%C^{270R}(u1,u2)=u1-C(u1,1-u2)
% dC^{270R}(u1,u2)/du1=q-->1-C(1-u2|u1)=q
% [T,k]=size(u1);

switch copulatype
    case 'Gaussian'
        q=normcdf((norminv(u2)-paramhat.*norminv(u1))./sqrt(1-paramhat.^2));
    case 'Student'
        if max(size(paramhat))==2 % constant copula
            rho=paramhat(1);
            nu=paramhat(2);
        else
            rho=paramhat(:,1); nu=paramhat(:,2);
        end
        q=tcdf(sqrt((nu+1)./(nu+(tinv(u1,nu)).^2)) .* (tinv(u2,nu)-rho.*tinv(u1,nu))./sqrt(1-rho.^2), nu+1);
    case 'Frank'
        q = ccdf_frank(u1,u2,paramhat);
    case 'Plackett'
        q = ccdf_plackett(u1,u2,paramhat);
    case 'Joe'
        q = ccdf_joe(u1,u2,paramhat);
    case '90Joe'
        q = ccdf_joe(1-u1,u2,paramhat);
    case '180Joe'
        q = (1-ccdf_joe(1-u1,1-u2,paramhat));
    case '270Joe'
        q = (1-ccdf_joe(u1,1-u2,paramhat));
    case 'Clayton'
         q = ccdf_clayton(u1,u2,paramhat);
    case '90Clayton'
        q = ccdf_clayton(1-u1,u2,paramhat);
    case '180Clayton'
        q = (1-ccdf_clayton(1-u1,1-u2,paramhat));
    case '270Clayton'
        q = (1-ccdf_clayton(u1,1-u2,paramhat));
   case 'Gumbel'
        q = ccdf_gumbel(u1,u2,paramhat);
   case '90Gumbel'
        q = ccdf_gumbel(1-u1,u2,paramhat);
    case '180Gumbel'
        q = (1-ccdf_gumbel(1-u1,1-u2,paramhat));
    case '270Gumbel'
        q = (1-ccdf_gumbel(u1,1-u2,paramhat));
    case 'BB1'
        q = ccdf_bb1(u1,u2,paramhat);
   case '90BB1'
        q = ccdf_bb1(1-u1,u2,paramhat);
    case '180BB1'
        q = (1-ccdf_bb1(1-u1,1-u2,paramhat));
    case '270BB1'
        q = (1-ccdf_bb1(u1,1-u2,paramhat));
    case 'BB2'
        q = ccdf_bb2(u1,u2,paramhat);
   case '90BB2'
        q = ccdf_bb2(1-u1,u2,paramhat);
    case '180BB2'
        q = (1-ccdf_bb2(1-u1,1-u2,paramhat));
    case '270BB2'
        q = (1-ccdf_bb2(u1,1-u2,paramhat));        
    case 'BB3'
        q = ccdf_bb3(u1,u2,paramhat);
   case '90BB3'
        q = ccdf_bb3(1-u1,u2,paramhat);
    case '180BB3'
        q = (1-ccdf_bb3(1-u1,1-u2,paramhat));
    case '270BB3'
        q = (1-ccdf_bb3(u1,1-u2,paramhat));
    case 'BB4'
        q = ccdf_bb4(u1,u2,paramhat);
   case '90BB4'
        q = ccdf_bb4(1-u1,u2,paramhat);
    case '180BB4'
        q = (1-ccdf_bb4(1-u1,1-u2,paramhat));
    case '270BB4'
        q = (1-ccdf_bb4(u1,1-u2,paramhat));    
    case 'BB5'
        q = ccdf_bb5(u1,u2,paramhat);
   case '90BB5'
        q = ccdf_bb5(1-u1,u2,paramhat);
    case '180BB5'
        q = (1-ccdf_bb5(1-u1,1-u2,paramhat));
    case '270BB5'
        q = (1-ccdf_bb5(u1,1-u2,paramhat));
    case 'BB6'
        q = ccdf_bb6(u1,u2,paramhat);
   case '90BB6'
        q = ccdf_bb6(1-u1,u2,paramhat);
    case '180BB6'
        q = (1-ccdf_bb6(1-u1,1-u2,paramhat));
    case '270BB6'
        q = (1-ccdf_bb6(u1,1-u2,paramhat));
    case 'BB7'
        q = ccdf_bb7(u1,u2,paramhat);
   case '90BB7'
        q = ccdf_bb7(1-u1,u2,paramhat);
    case '180RBB7'
        q = (1-ccdf_bb7(1-u1,1-u2,paramhat));
    case '270BB7'
        q = (1-ccdf_bb7(u1,1-u2,paramhat));
    case 'SJC'
        q = ccdf_sjc(u1,u2,paramhat);
   case '90SJC'
        q = ccdf_sjc(1-u1,u2,paramhat);
    case '180SJC'
        q = (1-ccdf_sjc(1-u1,1-u2,paramhat));
    case '270SJC'
        q = (1-ccdf_sjc(u1,1-u2,paramhat));
    case 'BB8'
        q = ccdf_bb8(u1,u2,paramhat);
   case '90BB8'
        q = ccdf_bb8(1-u1,u2,paramhat);
    case '180BB8'
        q = (1-ccdf_bb8(1-u1,1-u2,paramhat));
    case '270BB8'
        q = (1-ccdf_bb8(u1,1-u2,paramhat));
    case 'Independence'
        q = u2;
end