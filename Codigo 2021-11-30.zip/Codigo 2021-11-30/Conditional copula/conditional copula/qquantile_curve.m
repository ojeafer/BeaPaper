function u2=qquantile_curve(copulatype,paramhat,q,u1)
%% qquantile_curve: q-quantile curve (u2) given a quantile of variable, (u1)
%%                      a conditional probability  (q), a type of copula and its parameter. 
%% SYNTAX:
%        u2=qquantile_curve(copulatype,theta,q,u1)
%
%% INPUT:
%           copulatype = 
%                        Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%           theta : copula parameter
%           q : conditional probability
%           u1 : quantile of variable u1
%
%% OUTPUT:
%           u2: quantile of variable 2 that has a probability q conditioned 
%               that variable 1 is at its u1 quantile, i.e. q-quantile curve
%           
%% NOTES:
% C^{90R}(u1,u2)=u2-C(1-u1,u2)
%  dC^{90R}(u1,u2)/du1=q-->C(u2|1-u1)=q
% C^{180R}(u1,u2)=u1+u2-1+C(1-u1,1-u2)
%  dC^{180R}(u1,u2)/du1=q-->1-C(1-u2|1-u1)=q
% C^{270R}(u1,u2)=u1-C(u1,1-u2)
%  dC^{270R}(u1,u2)/du1=q-->1-C(1-u2|u1)=q
switch copulatype
    case 'Gaussian'
        u2=normcdf(norminv(q)*sqrt(1-paramhat.^2)+paramhat.*norminv(u1));
    case 'Student'
        rho=paramhat(:,1); nu=paramhat(:,2);
        u2=tcdf(rho.*tinv(u1,nu)+sqrt(1-rho.^2).*(nu+(tinv(u1,nu+1)).^2)/(nu+1).*tinv(q,nu+1),nu);
    case 'Frank'
        fun = @(x) ccdf_frank(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'Plackett'
        fun = @(x) ccdf_plackett(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'Joe'
        fun = @(x) ccdf_joe(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)), -log(1/q-1));
        u2=(1+exp(-utr)).^(-1);     
    case '90Joe'
        fun = @(x) ccdf_joe(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180Joe'
        fun = @(x) (1-ccdf_joe(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270Joe'
        fun = @(x) (1-ccdf_joe(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'Clayton'
%         fun = @(x) ccdf_clayton(u1,x,paramhat)-q;
%         utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
%         u2=(1+exp(-utr)).^(-1);
          u2=(1+u1.^(-paramhat).*(q.^(-paramhat./(1+paramhat))-1)).^(-1./paramhat);
    case '90Clayton'
        fun = @(x) ccdf_clayton(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180Clayton'
        fun = @(x) (1-ccdf_clayton(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270Clayton'
        fun = @(x) (1-ccdf_clayton(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'Gumbel'
        fun = @(x) ccdf_gumbel(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90Gumbel'
        fun = @(x) ccdf_gumbel(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180Gumbel'
        fun = @(x) (1-ccdf_gumbel(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270Gumbel'
        fun = @(x) (1-ccdf_gumbel(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB1'
        fun = @(x) ccdf_bb1(u1,x,paramhat)-q;
        utr=fzero(@(utr0) fun((1+exp(-utr0))^(-1)), -log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90BB1'
        paramhat(1) = max(1.0e-4, min(paramhat(1),100));
        paramhat(2) = max(1+1.0e-4, min(paramhat(2),100));
        
        fun = @(x) ccdf_bb1(1-u1,x,paramhat)-q;        
        options_solve = optimoptions('fsolve','StepTolerance',1e-4,'Display','off');
%         utr=fsolve(@(utr0) fun((1+exp(-utr0))^(-1)), -log(1/q-1), options_solve);
        utr=fzero(@(utr0) fun((1+exp(-utr0))^(-1)), -log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180BB1'
        fun = @(x) (1-ccdf_bb1(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0) fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270BB1'
        fun = @(x) (1-ccdf_bb1(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB2'
        fun = @(x) ccdf_bb2(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
   case '90RBB2'
        fun = @(x) ccdf_bb2(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB2'
        fun = @(x) (1-ccdf_bb2(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB2'
        fun = @(x) (1-ccdf_bb2(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB3'
        fun = @(x) ccdf_bb3(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90RBB3'
        fun = @(x) ccdf_bb3(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB3'
        fun = @(x) (1-ccdf_bb3(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB3'
        fun = @(x) (1-ccdf_bb3(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB4'
        fun = @(x) ccdf_bb4(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90RBB4'
        fun = @(x) ccdf_bb4(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB4'
        fun = @(x) (1-ccdf_bb4(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB4'
        fun = @(x) (1-ccdf_bb4(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB5'
        fun = @(x) ccdf_bb5(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90RBB5'
        fun = @(x) ccdf_bb5(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB5'
        fun = @(x) (1-ccdf_bb5(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB5'
        fun = @(x) (1-ccdf_bb5(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB6'
        fun = @(x) ccdf_bb6(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90RBB6'
        fun = @(x) ccdf_bb6(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB6'
        fun = @(x) (1-ccdf_bb6(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB6'
        fun = @(x) (1-ccdf_bb6(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB7'
        fun = @(x) ccdf_bb7(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90RBB7'
        fun = @(x) ccdf_bb7(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB7'
        fun = @(x) (1-ccdf_bb7(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB7'
        fun = @(x) (1-ccdf_bb7(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'SJC'
        fun = @(x) ccdf_sjc(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '90RSJC'
        fun = @(x) ccdf_sjc(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RSJC'
        fun = @(x) (1-ccdf_sjc(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RSJC'
        fun = @(x) (1-ccdf_sjc(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'BB8'
        fun = @(x) ccdf_bb8(u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);    
    case '90RBB8'
        fun = @(x) ccdf_bb8(1-u1,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);  
    case '180RBB8'
        fun = @(x) (1-ccdf_bb8(1-u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case '270RBB8'
        fun = @(x) (1-ccdf_bb8(u1,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        u2=(1+exp(-utr)).^(-1);
    case 'Independence'
        u2 = q;
end