function Fout=copula_cdf(x,y,copulatype,paramhat);
%% logpdf: copula pdf 
%
%% SYNTAX:
%        [Fout]=copulapdf(data,copulatype,paramhat)
%
%% INPUT:
%              data = matrix (Tx2)
%              copulatype = Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%              paramhat    =	parameter of the copula over time (length T)
%% OUTPUT:
%               CL : value of the logpdf at each point of the sample
%Javier Ojea Ferreiro 19/07/2018
%%
if strcmp(copulatype,'Gaussian')
%     if length(x)>1
%         for t=1:length(x)
%             [u(t,1)]=integral(@(u) ccdf_normal(u,x(t,1),paramhat(t,1)),0,y(t,1),'Array',true,'AbsTol',1e-5,'RelTol',1e-3);
%         end
%        Fout= u;
corr = paramhat(1);
if length(x)>1
    for t = 1 : length(x)
    Fout(t) = copulacdf('Gaussian',[x(t),y],corr);
    end
else
 Fout = copulacdf('Gaussian',[x,y],corr);
end
%     end
elseif strcmp(copulatype,'Student')
% [Fout]=integral(@(u) ccdf_t(u,x,paramhat),0,y,'Array',true, 'AbsTol',1e-5,'RelTol',1e-3); 
corr=paramhat(1,1);
nu=paramhat(1,2);
Fout = copulacdf('t',[x,y],corr,nu);
elseif strcmp(copulatype,'Frank')   
     [Fout]=frank_cdf(x,y,paramhat);
elseif strcmp(copulatype,'Plackett')
    [Fout]=plackett_cdf(x,y,paramhat);
elseif strcmp(copulatype,'Joe')
    [Fout] = joe_cdf(x,y,paramhat);
elseif strcmp(copulatype,'90Joe')
    [Fout] = y - joe_cdf(1-x,y,paramhat);
elseif strcmp(copulatype,'180Joe')
    [Fout] = x + y - 1 +joe_cdf(1-x,1-y,paramhat);
elseif strcmp(copulatype,'270Joe')
    [Fout] = x - joe_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'Clayton')
    [Fout] = clayton_cdf(x,y,paramhat);
elseif strcmp(copulatype,'90Clayton')
    [Fout] = y - clayton_cdf(1-x,y,paramhat);
elseif strcmp(copulatype,'180Clayton')
    [Fout] = x + y - 1 +clayton_cdf(1-x,1-y,paramhat);
elseif strcmp(copulatype,'270Clayton')
    [Fout] = x - clayton_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'Gumbel')
    [Fout] = gumbel_cdf(x,y,paramhat);
elseif strcmp(copulatype,'90Gumbel')
    [Fout] = y - gumbel_cdf(1-x,y,paramhat);
elseif strcmp(copulatype,'180Gumbel')
    [Fout] = x + y - 1 +gumbel_cdf(1-x,1-y,paramhat);
elseif strcmp(copulatype,'270Gumbel')
    [Fout] = x - gumbel_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'BB1') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB1_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB1') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB1_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB1') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB1_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB1') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB1_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'BB2') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB2_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB2') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB2_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB2') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB2_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB2') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB2_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'BB3') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB3_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB3') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB3_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB3') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB3_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB3') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB3_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'BB4') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB4_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB4') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB4_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB4') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB4_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB4') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB4_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'BB5') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB5_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB5') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB5_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB5') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB5_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB5') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB5_cdf(x,1-y,paramhat);    
elseif strcmp(copulatype,'BB6') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB6_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB6') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB6_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB6') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB6_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB6') 
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB6_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'BB7')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=BB7_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB7')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB7_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB7')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + BB7_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB7')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout]=x - BB7_cdf(x,1-y,paramhat);
elseif strcmp(copulatype,'SJC')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = SJC_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90RSJC')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - SJC_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180SJC')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x + y - 1 + SJC_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270SJC')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = x - SJC_cdf(x,1-y,theta,delta);
elseif strcmp(copulatype,'BB8')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = BB8_cdf(x,y,theta,delta);
elseif strcmp(copulatype,'90BB8')
    theta = paramhat(:,1);
    delta = paramhat(:,2);
    [Fout] = y - BB8_cdf(1-x,y,theta,delta);
elseif strcmp(copulatype,'180BB8')
    theta = paramhat(:,1);
    delta=paramhat(:,2);
    [Fout] = x + y - 1 + BB8_cdf(1-x,1-y,theta,delta);
elseif strcmp(copulatype,'270BB8')
    theta = paramhat(:,1);
    delta=paramhat(:,2);
    [Fout] = x - BB8_cdf(x,1-y,theta,delta);
elseif strcmp(copulatype,'Independence')
    Fout= x.*y;
end
