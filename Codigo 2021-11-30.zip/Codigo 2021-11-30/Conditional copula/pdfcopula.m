function [ff]=pdfcopula(data,copulatype,paramhat);
%% logpdf: minus sum of the log pdf (S) and the value at each point (CL)
%
%% SYNTAX:
%        [S,CL]=logpdf(data,copulatype,paramhat)
%
%% INPUT:
%              data = matrix (Tx2)
%              copulatype = Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%              paramhat    =	parameter of the copula over time (length T)
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               CL : value of the logpdf at each point of the sample
%Javier Ojea Ferreiro 19/07/2018
%%
if  strcmp(copulatype,'Gaussian')
    x = norminv(data(:,1),0,1);
    y = norminv(data(:,2),0,1);
elseif strcmp(copulatype,'Student')
        nu=paramhat(1,2);
        x = tinv(data(:,1),nu);
        y = tinv(data(:,2),nu);
else
    x = data(:,1);
    y = data(:,2);
end
if strncmpi(copulatype,'90',2)
    x = 1-x;
end
if strncmpi(copulatype,'180',3)
    x = 1-x;
    y = 1-y;
end
if strncmpi(copulatype,'270',3)
    y = 1-y;
end

if strcmp(copulatype,'Gaussian')
    [S,CL]=logpdf_norm(x,y,paramhat);
elseif strcmp(copulatype,'Student')
     [S,CL]=logpdf_t(x,y,paramhat);  
elseif strcmp(copulatype,'Frank')   
     [S,CL]=logpdf_frank(x,y,paramhat);
elseif strcmp(copulatype,'Plackett')
    [S,CL]=logpdf_plackett(x,y,paramhat);
elseif  strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe')|...
        strcmp(copulatype,'180Joe')| strcmp(copulatype,'270Joe')
    [S,CL]=logpdf_joe(x,y,paramhat);
elseif strcmp(copulatype,'Clayton') |strcmp(copulatype,'90Clayton')|...
        strcmp(copulatype,'180Clayton') |strcmp(copulatype,'270Clayton')
    [S,CL]=logpdf_clayton(x,y,paramhat);
elseif strcmp(copulatype,'Gumbel') | strcmp(copulatype,'90Gumbel') | ...
        strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel')
    [S,CL]=logpdf_gumbel(x,y,paramhat);
elseif strcmp(copulatype,'BB1') | strcmp(copulatype,'90BB1')|...
        strcmp(copulatype,'180BB1') | strcmp(copulatype,'270BB1')
    [S,CL]=logpdf_bb1(x,y,paramhat);
elseif strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2')|...
        strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2')
    [S,CL]=logpdf_bb2(x,y,paramhat);
elseif strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3')|...
        strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3')
    [S,CL]=logpdf_bb3(x,y,paramhat);
elseif strcmp(copulatype,'BB4') | strcmp(copulatype,'90BB4')|...
        strcmp(copulatype,'180BB4') | strcmp(copulatype,'270BB4')
    [S,CL]=logpdf_bb4(x,y,paramhat);
elseif strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5')|...
        strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5')
    [S,CL]=logpdf_bb5(x,y,paramhat);
elseif strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')|...
        strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')      
    [S,CL]=logpdf_bb6(x,y,paramhat);
elseif strcmp(copulatype,'BB7') | strcmp(copulatype,'90BB7')|...
        strcmp(copulatype,'180BB7') | strcmp(copulatype,'270BB7')
    [S,CL]=logpdf_bb7(x,y,paramhat);
elseif strcmp(copulatype,'SJC')|strcmp(copulatype,'90SJC')|...
        strcmp(copulatype,'180SJC')|strcmp(copulatype,'270SJC')
     [S,CL]=logpdf_sjc(x,y,paramhat);
elseif strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8')|...
        strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
    [S,CL]=logpdf_bb8(x,y,paramhat);
elseif strcmp(copulatype,'Independence')
    S=0;
    CL=log(ones(size(paramhat)));
end 
ff=exp(CL);
