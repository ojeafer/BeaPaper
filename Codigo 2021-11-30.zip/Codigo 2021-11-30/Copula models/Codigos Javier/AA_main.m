load('input')
%use weekly data
id=find(weekday(Date)==4)
r_CL=diff(log(CL(id)));
r_IT=diff(log(FTSEMIB(id)));
DateW=Date(id);
% * Estimate marginal model
% AR(1)-GARCH
Mdl = arima('ARLags',1,'Variance',garch(1,1))
EstMdl_CL = estimate(Mdl,r_CL);
EstMdl_IT = estimate(Mdl,r_IT);
% Obtain the residual series
[res_CL,v_CL]  = infer(EstMdl_CL,r_CL); % [residuals inferred, conditional variances inferred]
[res_IT,v_IT]  = infer(EstMdl_IT,r_IT);
mu_IT=r_IT-res_IT;
u_CL=normcdf(res_CL./sqrt(v_CL));
u_IT=normcdf(res_IT./sqrt(v_IT));
% * Dependence structure
%Initial values for the Markov Chain
p11=0.99; p22=0.99;
p0=[p11; p22];
% Transform the probabilities of staying in the same state between t and
% t+1 form (0,1) into the space (-Inf,Inf)
% x=1/(1+exp(-y)) where x is between (0,1) so
% y=-log(1/x-1)
p0tr=-log(1./p0-1);
%Uniform values of the residuals
u=[u_CL,u_IT];
%Optimization criterion
options = optimset('Display','Iter','TolFun',10^-10,'TolX',10^-10,'MaxFunEvals',1e6,'MaxIter',1e6);
% Compute initial values for the parameters (Gaussian-Clayton)
% estimate the Gaussian copula 
[param0(1),~,~,~,param0tr0(1)]=copula_estimation_constant(u,'Gaussian',options);
% estimate the Clayton copula 
[param0(2),~,~,~,param0tr0(2)]=copula_estimation_constant(u,'Clayton',options);
paramtr0=[p0tr;param0tr0(:)];
[Xt1t, Xtt, XtT, Mchain, theta, partrC, parC, LogLik]=CopML_SM2(u,{'Gaussian';'Clayton'},options,paramtr0);
% plot smoothed probabilities
figure
hAxes=axes()
hPlot=plot(DateW(2:end),XtT)
set(hAxes,'TickLabelInterpreter','Latex')
set(get(hAxes,'XLabel'),'string','time','interpreter','latex')
set(get(hAxes,'YLabel'),'string','$P(s_t|I_T)$','interpreter','latex')
txt1=sprintf('state 1: Gaussian ($\\rho$=%.2f)',parC(3))
txt2=sprintf('state 2: Clayton ($\\theta$=%.2f)',parC(4))
h_legend=legend(hPlot,{txt1,txt2})
set(h_legend,'interpreter','latex')
set(get(hAxes,'title'),'string','Smoothed probabilities of being at each state','interpreter','latex')
% Get the CoVaR of the FSTE MIB given a downward movement in
% the Chilean peso exchange rate against the EUR
p=0.05; % 5th percentile
% CoVaR under the definition of Adrian and Brunnermeier (2016)
% P(r_IT<CoVaR(0.05,0.05)|r_CL=VaR(0.05))=0.05
for t=1:length(XtT)
fun = @(x) XtT(t,1).*normcdf((norminv(x)-parC(3).*norminv(p))./sqrt(1-parC(3).^2))+...
XtT(t,2).*ccdf_clayton(p,x,parC(4)); % Conditional Gaussian copula
%Looking for the transformation of the uniform value in (-Inf,Inf) instead
%of (0,1) solves convergence problems in "fzero" function, i.e. instead of
%getting u we get utr=-log(1/u-1)
utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1))-p,-log(1/p-1));
% We undo the transformation of the uniform value to get a quantile, i.e.
% u=1/(1+exp(-utr))
u_AB(t,1)=(1+exp(-utr)).^(-1); 
end
% CoVaR under the definition of GIrardi and Ergun (2013)
% P(r_IT<CoVaR(0.05,0.05)|r_CL<VaR(0.05))=0.05
for t=1:length(XtT)
fun = @(x) XtT(t,1).*copulacdf('Gaussian',[x,p],parC(3))+...
XtT(t,2).*clayton_cdf(x,p,parC(4));
utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1))-p.^2,-log(1/p-1));
u_GE(t,1)=(1+exp(-utr)).^(-1); 
end
% Chart of the VaR
figure
hAxes=axes()
hPlot(1)=plot(DateW(2:end),(sqrt(v_IT).*norminv(u_AB)+mu_IT).*100,'r')
hold on
hPlot(2)=plot(DateW(2:end),(sqrt(v_IT).*norminv(u_GE)+mu_IT).*100,'b')
hPlot(3)=plot(DateW(2:end),(sqrt(v_IT).*norminv(p)+mu_IT).*100,'k')
set(get(hAxes,'XLabel'),'string','time','interpreter','latex')
set(get(hAxes,'YLabel'),'string','returns $(\%)$','interpreter','latex')
h_legend=legend(hPlot,{'$CoVaR_{AB}$','$CoVaR_{GE}$','VaR'})
set(h_legend,'interpreter','latex')
set(get(hAxes,'title'),'string','Condiational and unconditional Value at Risk at 5\%','interpreter','latex')
%References:
% Adrian, Tobias, and Markus K. Brunnermeier. 2016. "CoVaR." American Economic Review, 106 (7): 1705-41.
% Girardi, Giulio and Tolga Erg�n, A., (2013), Systemic risk measurement: Multivariate GARCH estimation of CoVaR, Journal of Banking & Finance, 37, issue 8, p. 3169-3180

%% Scatter plot (it can show some dependence pattern)
scatter(u_CL,u_IT);