function [S,CL]=logpdf_clayton(x,y,paramhat)
%% logpdf_clayton: Log pdf for the clayton distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_clayton(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 31/01/2020
thetahat = paramhat;
[T,~]=size(y);
if size(thetahat,1)<T
    thetahat=ones(T,1)*thetahat;
end
for t=1:T
    if thetahat(t,1)>1e-5
        CL(t,:) = log(x(t,:).*y(t,:)).*(-1-thetahat(t,:));
        CL(t,:) = CL(t,:) - (2+1/thetahat(t,:)).*log((x(t,:).^(-thetahat(t,:)))...
            + (y(t,:).^(-thetahat(t,:))) - 1);
        CL(t,:) = log(1+thetahat(t,:)) + CL(t,:);
    else
        CL(t,:) = 0;  % under independence the copula pdf=1, so the log-likelihood=0
    end
end
S = -sum(CL);
%
end