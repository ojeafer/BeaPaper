function [S,CL]=logpdf_norm(x,y,paramhat)
%% logpdf_norm: Log pdf for the normal distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_norm(x,y,paramhat)
%
%% INPUT:
%               x, y = N(0,1) vectors of length T
%               rho = correlation parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 31/01/2020
rho=paramhat;
CL = -1*(2*(1-rho.^2)).^(-1).*(x.^2+y.^2-2*rho.*x.*y);
CL = CL + 0.5*(x.^2+y.^2);  
CL = CL - 0.5*log(1-rho.^2);
S = -sum(CL);
end
