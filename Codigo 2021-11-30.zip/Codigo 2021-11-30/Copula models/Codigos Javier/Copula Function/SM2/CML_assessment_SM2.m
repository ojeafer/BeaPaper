function [LL_CL,xitt,xit1t,P,theta]=CML_assessment_SM2(paramtr,u,copulatype)
%%
%% CML_assessment_SM2: Full Maximum Likelihood assessment (called by CopML_SM2)
%
%% SYNTAX:
%        [LL_CL,xitt,xit1t,P,theta]=CML_assessment_SM2(paramtr,data,copulatype);
%
%% INPUT:
%               U = Data (uniform)
%               copulatype = copula to estimate
%                           Types:
%                               *'Gaussian'
%                               *'Clayton'
%               param0 = initial parameter
%% OUTPUT:
%               LL_CL: minus maximum likelihood of the dependence structure
%               xitt: inference about the state
%               xit1t: forecast about the state
%               P: transition matrix
%               theta: time series parameters
%%
%Javier Ojea Ferreiro 31/01/2020

[LL_CL, theta,xitt,xit1t,P] = biv_LogLike_SM2MX(paramtr(1:end),u, copulatype);
%
