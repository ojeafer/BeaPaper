function [Xt1t, Xtt, XtT, Mchain, theta, partrC, parC, LogLik]=CopML_SM2(data,copulatype,options,paramtr0)
%%
%% CopML_SM2: Copula Maximum Likelihood estimation in a Switching Markov with 2 states
%
%% SYNTAX:
%        [Xt1t, Xtt, XtT, Mchain, theta, partrC, parC, LogLik] =CopML_SM2(data,copulatype,options,copuparam0)
%
%% INPUT:
%              data = Data  (uniform)
%              copulatype = copula to estimate
%                           Types:
%                               *'Gaussian'
%                               *'Clayton' 
%               options = optimization criteria
%               paramtr0 = initial parameter 
%% OUTPUT:
%             Xt1t=xit1t forecast of the state probability for the next period
%             Xtt=xitt inference of teh state for the current period
%             XtT=xitT Smooth Kim's probabilities
%             Mchain=P Markov Chain (transition matrix)
%             theta=theta copula parameter
%             partrC=[copuparamtr;paramptr] transformed copula paramater and transition matrix
%             parC=[copuparam;paramp] copula paramater and transition matrix
%             LogLik=LL loglikelihood

%%
%Javier Ojea Ferreiro 31/01/2020
% Number of states
N=2;
% Estimate
[paramtr]=fminsearch('CML_assessment_SM2',paramtr0,options,data,copulatype);
% Get the output with the optimum parameters
[LL_CL,xitt,xit1t,P,theta]=CML_assessment_SM2(paramtr,data,copulatype);
%%
% Undo the transformation
copula_partr=[paramtr(1+2:end)];
for k=1:N
    if  strcmp(copulatype{k},'Gaussian')
            copula_par(k,1)=(1-exp(-copula_partr(k)))/(1+exp(-copula_partr(k)));
    elseif strcmp(copulatype{k},'Clayton') 
            copula_par(k,1)=100./(1+exp(-copula_partr(k)));
    end
end
    paramptr=paramtr(1:2);
    paramp=(1+exp(-paramptr)).^(-1);
%
%smoothing (Kim's algorithm)
T=size(xitt,1);
    xitT=zeros(T-1,N);
    xitT=[xitT; xitt(T,:)];
for t=1:T-1
    a=xitt(T-t,:)'.*(P'*(xitT(T-t+1,:)'./xit1t(T+1-t,:)'));
    xitT(T-t,:)=a';
end
Xt1t=xit1t(1:end,:);
Xtt=xitt;
XtT=xitT;
Mchain=P;
theta=theta;
partrC=paramtr;
parC=[paramp;copula_par];
LogLik=LL_CL;
%
