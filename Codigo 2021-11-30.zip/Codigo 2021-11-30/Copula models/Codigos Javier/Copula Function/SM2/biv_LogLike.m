function [S, paramhat,CL] = biv_LogLike(param,data,copulatype)
%% biv_LogLike: LogLike function
%
%% SYNTAX:
%        [S, paramhat, CL] = biv_LogLike(param,data,copulatype)
%
%% INPUT:
%              param    =	parameters
%              data = u (Tx2)
%              copulatype =  Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               paramhat : estimates of the copula
%               CL : logdensity at each point
%%
%Javier Ojea Ferreiro 20/10/2017
% Updated: 23/04/2018
%%
T = size(data,1);
if nargin<2
    error('You should enter at least uniform-distributed data and the parameter set')   
elseif nargin==2 
    copulatype='Gaussian';
end
%%
if  strcmp(copulatype,'Gaussian')
    x = norminv(data(:,1),0,1);
    y = norminv(data(:,2),0,1);
elseif strcmp(copulatype,'Student')
        nu=param(2);
        x = tinv(data(:,1),nu);
        y = tinv(data(:,2),nu);
else
    x = data(:,1);
    y = data(:,2);
end
    if  strcmp(copulatype,'Gaussian')
        %1. Gaussian copula
        paramhat=param(1)*ones(T+1,1);
    elseif strcmp(copulatype,'Student')
        %2. Student copula
        paramhat=ones(T+1,1)*[param(1), nu];
    elseif strcmp(copulatype,'Frank') |strcmp(copulatype,'Plackett') | ...
            strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
            strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')|...
            strcmp(copulatype,'Clayton') |strcmp(copulatype,'90Clayton') | ...
            strcmp(copulatype,'180Clayton') |strcmp(copulatype,'270Clayton') | ...
            strcmp(copulatype,'Gumbel') | strcmp(copulatype,'90Gumbel')|...
            strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel')
        paramhat=param(1)*ones(T+1,1);
    elseif strcmp(copulatype,'BB1') | strcmp(copulatype,'90BB1')|...
            strcmp(copulatype,'180BB1')|strcmp(copulatype,'270BB1')
        %8. BB1 copula
        paramhat(:,1) = ones(T+1,1)*-log2(2-param(2))/log2(param(1));
        paramhat(:,2) = ones(T+1,1)*1/log2(2-param(2));
    elseif strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
            strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2') | ...
            strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
            strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
            strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
            strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5') | ...
            strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
            strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')  | ...
            strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') |...
            strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
        paramhat(:,1) = ones(T+1,1)*param(1);
        paramhat(:,2) = ones(T+1,1)*param(2);
    elseif strcmp(copulatype,'BB4') | strcmp(copulatype,'90BB4')|...
        strcmp(copulatype,'180BB4') | strcmp(copulatype,'270BB4')
        %11. BB4 copula
        paramhat(:,1) = ones(T+1,1)*-log(2-param(2))/log(param(1));
        paramhat(:,2) = ones(T+1,1)*-1/log2(param(2));
    elseif strcmp(copulatype,'BB7') | strcmp(copulatype,'90BB7') |...
            strcmp(copulatype,'180BB7') | strcmp(copulatype,'270BB7') |...
            strcmp(copulatype,'SJC') | strcmp(copulatype,'90SJC') |...
            strcmp(copulatype,'180SJC') | strcmp(copulatype,'270SJC')
        paramhat(:,1) = ones(T+1,1)*1/log2(2-param(2));
        paramhat(:,2) = ones(T+1,1)*-1/log2(param(1));
    elseif strcmp(copulatype,'Independence')
        paramhat(:,1) = NaN(T+1,1);
    end
[S,CL]=logpdf([x,y],copulatype,paramhat(1:end-1,:));
    
     
