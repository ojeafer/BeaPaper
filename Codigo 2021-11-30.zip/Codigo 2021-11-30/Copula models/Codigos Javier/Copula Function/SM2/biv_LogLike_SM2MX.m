function [S, paramhat,xitt,xit1t,P] = biv_LogLike_SM2MX(param,u,copulaeset)
%% biv_LogLike_SM: Switching Markov LogLike function
%
%% SYNTAX:
%        [S, paramhat,CL] = biv_LogLike_SM(param,data,copulatype)
%
%% INPUT:
%              param    =	 Switching Markov chains probabilities 
%                               and copula parameters 
%              u = data (Tx2)
%              copulatype =  Types:
%                               *'Gaussian'
%                               *'Clayton'
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               paramhat : constant/ time-varying values of the parameters
%               CL : logdensity at each point
%%
%Javier Ojea Ferreiro 31/01/2020
%%
%%
p11=1./(1+exp(-param(1)));
p22=1./(1+exp(-param(2)));
N=2;% N of regimes
T = size(u,1);
%%
%% Markov Chain
% Two regimes
P=[p11, 1-p22;
   1-p11, p22];
for k=1:N
    if  strcmp(copulaeset{k},'Gaussian')
        x(:,k) = norminv(u(:,1),0,1);
        y(:,k) = norminv(u(:,2),0,1);
    else
        x(:,k) = u(:,1);
        y(:,k) = u(:,2);
    end
    %number of parameters
    n_c(1)=0;
    n_c(k+1)=1;
%%get the parameters
if  strcmp(copulaeset{k},'Gaussian')
    %1. Gaussian copula
    rho=(1-exp(-param(2+1+n_c(k))))/(1+exp(-param(2+1+n_c(k))));
    paramhat(:,1+n_c(k))=rho*ones(T+1,1);
elseif  strcmp(copulaeset{k},'Clayton') 
        theta=100./(1+exp(-param(2+1+n_c(k))));
    paramhat(:,1+n_c(k))=ones(T+1,1)*theta;
end
[~,CL]=logpdf([x(:,k),y(:,k)],copulaeset{k},paramhat(1:end-1,sum(n_c(k))+1:sum(n_c(1:k+1))));
%Likelihood
eta(:,k)=exp(CL);
end
% Initial values for the Markov process
A=[eye(N)-P; ones(1,N)];
    eN1=[zeros(N,1);
        1];
    ppi=inv(A'*A)*A'*eN1;   
    xi10=ppi';
    xitt=zeros(T,N);
    xit1t=zeros(T,N);
    for t=1:T
        xitt(t,:)=(xi10.*eta(t,:))/((xi10.*eta(t,:))*ones(N,1));
        xit1t(t,:)=xitt(t,:)*P';
        xi10=xit1t(t,:);
    end
    xit1t=[xi10;xit1t];
    %Joint density
    f=(xit1t(1:T,:).*eta)*ones(N,1);
    lf=log(f);
	S=-ones(1,T)*lf;    
     
