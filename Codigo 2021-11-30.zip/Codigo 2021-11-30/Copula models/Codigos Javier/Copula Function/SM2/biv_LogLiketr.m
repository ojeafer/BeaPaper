function [S, paramhat,CL] = biv_LogLiketr(param,data,copulatype)
%% biv_LogLike:  LogLike function
%
%% SYNTAX:
%        [S, paramhat,CL] = biv_LogLiketr(param,data,copulatype)
%
%% INPUT:
%              param    =	parameters
%              data = u (Tx2)
%              copulatype =  Types:
%                           *'Gaussian'
%                           *'Clayton'
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               paramhat : values of the estimates
%               CL : logdensity at each point
%%
%Javier Ojea Ferreiro 31/01/2020
%%
T = size(data,1);
%%
    if  strcmp(copulatype,'Gaussian')
        x = norminv(data(:,1),0,1);
        y = norminv(data(:,2),0,1);
        %1. Gaussian copula
            rho=(1-exp(-param(1)))/(1+exp(-param(1)));
            paramhat=rho*ones(T+1,1);
    elseif strcmp(copulatype,'Clayton')
        x = data(:,1);
        y = data(:,2);
        theta=100/(1+exp(-param(1)));
        paramhat=theta*ones(T+1,1);
    end
[S,CL]=logpdf([x,y],copulatype,paramhat(1:end-1,:));
end
     
