function [paramout,paramhat,S,CL,paramtrout]=copula_estimation_constant(data,copula,options)
%% copula_estimation_constant: Estimation of the copula model using a constant parameter
%
%% SYNTAX:
%        [paramout,paramhat,S,CL]=copula_estimation_constant(data,copula)
%
%% INPUT:
%              data = u (Tx2)
%              copula =  Types:
%                           *'Gaussian'
%                           *'Clayton'
%% OUTPUT:
%               paramout =	estimates of the copula
%               paramhat = estimates of the copula (Tx1)
%               S : Value of the Maximum Likelihood function
%               CL : logdensity at each point
%%
%Javier Ojea Ferreiro 31/01/2020
if nargin<3
    options = optimset('Display','iter','MaxIter',1e6,'MaxFunEvals',1e6,'TolFun',1e-8,'TolX',1e-8);
elseif nargin<2
    error('need data input and a copula choice')
end
 if strcmpi(copula,'Gaussian')
     %Initial guess
     param0=corr(norminv(data(:,1)),norminv(data(:,2)));
     % Tranformation of the data from the range (-1,1) into (-Inf,Inf)
     % x=(1-exp(-y))/(1+exp(-y)) where x is between (-1,1) then
     % y=-log((1-x)/(1+x)) is between (-Inf,Inf)
     param0tr=-log((1-param0)/(1+param0));
 elseif strcmp(copula,'Clayton') 
     % Initial guess
     param0= 0.1;
     % Tranformation of the data from the range (0,Inf) into (-Inf,Inf)
     % x=100/(1+exp(-y)) where x is between (0,100) then
     % y=-log(100/x-1) is between (-Inf,Inf)
     param0tr=-log(100/param0-1)
     % P.S. Although the range of feasible values for the Clayton copula is
     % (0,Inf), adding an upper bound, e.g. 100, help to the convergence of
     % the algorithm. In finanacial data is strange to have theta value
     % higher than 4...
 end
 % % Estimation
 paramtrout=fminsearch('biv_LogLiketr',param0tr,options,data,copula);
 % % Undo the trasnformation
 if strcmpi(copula,'Gaussian')
     paramout=(1-exp(-paramtrout(1)))/(1+exp(-paramtrout(1)));
 elseif strcmp(copula,'Clayton')
     paramout= 100/(1+exp(-paramtrout(1)));
 end
 [S, paramhat,CL] = biv_LogLiketr(paramtrout,data,copula);
end
 
 
 
 