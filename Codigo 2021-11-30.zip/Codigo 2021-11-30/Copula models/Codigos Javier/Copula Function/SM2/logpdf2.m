function [S,CL]=logpdf2(data,copulatype,paramhat);
%% logpdf: minus sum of the log pdf (S) and the value at each point (CL)
%
%% SYNTAX:
%        [S,CL]=logpdf(data,copulatype,paramhat)
%
%% INPUT:
%              data = matrix (Tx2)
%              copulatype = Types:
%                           *'Gaussian'
%                           *'Clayton'
%              paramhat    =	parameter of the copula over time (length T)
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               CL : value of the logpdf at each point of the sample
%Javier Ojea Ferreiro 31/12/2020
%%
x=data(:,1);
y=data(:,2);
if strcmp(copulatype,'Gaussian')
    [S,CL]=logpdf_norm(x,y,paramhat);
elseif strcmp(copulatype,'Clayton') 
    [S,CL]=logpdf_clayton(x,y,paramhat);
end                
