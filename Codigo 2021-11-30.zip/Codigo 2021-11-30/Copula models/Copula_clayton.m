function C_clayton = Copula_clayton(u,v,alpha)

% We need to maximize ln c(u,v,theta) with the aim to find the optim
% paramether hat{theta} (or minimize -ln c(u,v,theta))


C_clayton = -(2+1/alpha)*log(u.^(-alpha)+v.^(-alpha)+1);
C_clayton = C_clayton - (alpha+1)*log(u.*v);
C_clayton = log(alpha+1) + sum(C_clayton);

C_clayton = - C_clayton;


end