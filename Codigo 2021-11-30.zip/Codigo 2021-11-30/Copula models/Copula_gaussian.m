function C_normal = Copula_gaussian(u,v,rho)

% We need to maximize ln c(u,v,theta) with the aim to find the optim
% paramether hat{theta} (or minimize -ln c(u,v,theta))

x = norminv(u,0,1);
y = norminv(v,0,1);

C_normal = - (x.^2+y.^2-2*rho*x.*y) / (2*(1-rho^2));
C_normal = sum(C_normal) + 1/(2*log(1-rho^2));

C_normal = - C_normal;


end