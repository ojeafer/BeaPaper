function C_gumble = Copula_gumble(u,v,theta)

% We need to maximize ln c(u,v,theta) with the aim to find the optim
% paramether hat{theta} (or minimize -ln c(u,v,theta))

A = ((-log(u)).^theta+(-log(v)).^theta) .^ (1/theta);

C_gumble = log(A+theta-1) + (1-2*theta)*log(A) - A;
C_gumble = C_gumble - log(u) - log(v);
C_gumble = C_gumble + (theta-1)*log(-log(u)) + (theta-1)*log(-log(v));
C_gumble = sum(C_gumble);

C_gumble = - C_gumble;


end