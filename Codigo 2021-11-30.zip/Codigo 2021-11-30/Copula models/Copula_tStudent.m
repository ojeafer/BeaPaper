function C_tStudent = Copula_tStudent(u,v,params)

x = norminv(u,0,1);
y = norminv(v,0,1);

rho = params(1);
nu = params(2);

C_tStudent = (-(nu+2)*0.5) * log(1 + (x.^2+y.^2-2*rho*x.*y)/(nu*(1-rho^2)));
C_tStudent = C_tStudent + ((nu+1)*0.5)*((1+x.^2/nu).*(1+y.^2/nu));

K = gamma(nu/2) * gamma(nu/2+0.5)^(-2) * gamma(nu/2+1);
C_tStudent = sum(C_tStudent) + K * 1/(2*log(1-rho^2));

C_tStudent = - C_tStudent;


end