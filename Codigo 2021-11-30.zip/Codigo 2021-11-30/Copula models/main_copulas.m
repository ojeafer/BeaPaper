%% Copulas
u = u_st;
v = u_golde;

% Gaussian copula
rho_ini = 0.4;
[rho_opt, lnL_gauss] = fminsearch(@(rho) Copula_gaussian(u,v,rho),rho_ini,options);
[aic_gauss, bic_gauss] = aicbic(lnL_gauss,1,Tp);

% Student's t copula
rhot_ini = 0.4;
nu_ini = 5;
[theta_opt, lnL_t] = fminsearch(@(params) Copula_tStudent(u,v,params),[rhot_ini,nu_ini],options);
rhot_opt = theta_opt(1);  nu_opt = theta_opt(2);
[aic_t, bic_t] = aicbic(lnL_t,2,Tp);

% Clayton copula
alpha_ini = 1.2;
[alpha_opt, lnL_clayton] = fminsearch(@(alpha) Copula_clayton(u,v,alpha),alpha_ini,options);
[aic_clayton, bic_clayton] = aicbic(lnL_clayton,1,Tp);

% Gumble copula
theta_ini = 1.0;
[theta_opt, lnL_gumble] = fminsearch(@(theta) Copula_gumble(u,v,theta),theta_ini,options);
[aic_gumble, bic_gumble] = aicbic(lnL_gumble,1,Tp);

%
names_cop = {'Gaussian   ';
             'Student t';
             'Clayton    ';
             'Gumble     '};
Akaike_copula = [aic_gauss; aic_t; aic_clayton; aic_gumble];   
Schwartz_copula = [bic_gauss; bic_t; bic_clayton; bic_gumble];   
Loglikelihood_copula = [lnL_gauss; lnL_t; lnL_clayton; lnL_gumble];
Optim_params = [rho_opt; rhot_opt; alpha_opt; theta_opt];
Degrees_of_Freedom = [0; nu_opt; 0; 0];

TABLE_COP = table(Akaike_copula, Schwartz_copula, Loglikelihood_copula,...
    Optim_params, Degrees_of_Freedom, 'RowNames', names_cop)

