function [S,DCC,xitt,xit1t] = EllipticMixture(param) 
%% EllipticMixture: Mixture of elliptic copulas where the weight of the mixture changes over time.
%% according to a Markov Chain of first order
%
%% SYNTAX: [lnL,DCC,xitt,xit1t] =  EllipticMixture(param) 
%
%% INPUTS:
%   param: vector of the parameters of the model [1x9]
%           rho_12gauss : correlation between asset 1 and 2 (transformed)
%           rho_13gauss : correlation between asset 1 and 3 (transformed)
%           rho_23gauss : correlation between asset 3 and 2 (transformed)
%           nu : number of degrees of freedom in the Student t copula
%           rho_12t : correlation between asset 1 and 2 (transformed)
%           rho_13t : correlation between asset 1 and 3 (transformed)
%           rho_23t : correlation between asset 3 and 2 (transformed)
%           p11 : probability of having a Gaussian dependence at t+1 
%                   given that we have a Gaussian dependence at t (transformed)
%           p22 : probability of having a Student dependence at t+1 
%                   given that we have a Student dependence at t (transformed)
%       IMPORTANT!!: the probability integral transformation (uni) is
%       introduced as a global variable.
%
%% OUTPUTS:
%   S: loglikelihood 
%   DCC: correlation matrix where the third dimension indicates if we have
%   the Gaussian correlation structure (1) or the Student correlation
%   structure (2)
%   xitt: inference probabilities
%   xit1t: forecast probabilities

global uni 

dcc12n =(1-exp(-param(1)))/(1+exp(-param(1)));
dcc13n = (1-exp(-param(2)))/(1+exp(-param(2)));
dcc23n = (1-exp(-param(3)))/(1+exp(-param(3)));

nu = 4+96./(1+exp(-param(4)));
dcc12t = (1-exp(-param(5)))/(1+exp(-param(5)));
dcc13t = (1-exp(-param(6)))/(1+exp(-param(6)));
dcc23t = (1-exp(-param(7)))/(1+exp(-param(7)));

p11 =  1./(1+exp(-param(8)));
p22=  1./(1+exp(-param(9)));

N = size(uni,1);

%Gaussian state
xn = norminv(uni(:,1));
yn = norminv(uni(:,2));
zn = norminv(uni(:,3));

xn2 = xn.^2;
yn2 = yn.^2;
zn2 = zn.^2;

cross1n = xn.*yn;
cross2n = xn.*zn;
cross3n = yn.*zn;

%Student state
xt = tinv(uni(:,1),nu).*sqrt((nu-2)/nu);
yt = tinv(uni(:,2),nu).*sqrt((nu-2)/nu);
zt = tinv(uni(:,3),nu).*sqrt((nu-2)/nu);

xt2 = xt.^2;
yt2 = yt.^2;
zt2 = zt.^2;

% State Student
cross1t = xt.*yt;
cross2t = xt.*zt;
cross3t = yt.*zt;
v12t = real((dcc12t-dcc23t.*dcc13t));
v13t = real((dcc12t.*dcc23t-dcc13t));
v23t = real((dcc23t-dcc12t.*dcc13t));
v1t = (1-dcc23t.^2);
v2t = (1-dcc13t.^2);
v3t = (1-dcc12t.^2);
% State Gaussian
v1n = (1-dcc23n.^2);
v2n = (1-dcc13n.^2);
v3n = (1-dcc12n.^2);
v12n = real((dcc12n-dcc23n.*dcc13n));
v13n = real((dcc12n.*dcc23n-dcc13n));
v23n = real((dcc23n-dcc12n.*dcc13n));
% Gather the correlation
DCC(:,:,1)=[1,dcc12n,dcc13n;...
    dcc12n,1,dcc23n;...
    dcc13n,dcc23n,1];
DCC(:,:,2)=[1,dcc12t,dcc13t;...
    dcc12t,1,dcc23t;...
    dcc13t,dcc23t,1];
%
% Loglikelihood
% Gaussian state
lnL(:,1) = -0.5.*log(1+2.*dcc12n.*dcc13n.*dcc23n-dcc12n.^2-dcc13n.^2-dcc23n.^2)...
    -0.5.*(xn2.*v1n+yn2.*v2n+zn2.*v3n-2.*v12n.*cross1n+2.*v13n.*cross2n-2.*v23n.*cross3n)...
    ./(1+2.*dcc12n.*dcc13n.*dcc23n-dcc12n.^2-dcc13n.^2-dcc23n.^2)...
    +0.5.*xn2+0.5.*yn2+0.5.*zn2;
% Student state
lnL(:,2) = - 0.5.*log(1 + 2*dcc12t.*dcc23t.*dcc13t - dcc12t.^2 - dcc13t.^2 - dcc23t.^2)...
    - ((nu+3)*0.5) * log(1 + 1/(nu-2) * 1./(1+2*dcc12t.*dcc23t.*dcc13t-dcc12t.^2-dcc13t.^2-dcc23t.^2) ...
    .* (xt2.*v1t+yt2.*v2t+zt2.*v3t-2.*v12t.*cross1t+2.*v13t.*cross2t-2.*v23t.*cross3t))...
    +((nu+1).*0.5)*log((1+xt2./(nu-2)).*(1+yt2./(nu-2)).*(1+zt2./(nu-2)))+gammaln((nu+3)/2)...
    -3.*gammaln((nu+1)/2)+2.*gammaln(nu/2);

% Now we set the Markov Switching approach
eta=exp(lnL);
% Markov Chain
P=[p11, 1-p22;...
   1-p11, p22];
%Compute initial probabilities - unconditional probabilities of being at
%each regime
A=[eye(2)-P; ones(1,2)];
eN1=[zeros(2,1);
    1];
ppi=inv(A'*A)*A'*eN1;
xi10=ppi';
xitt=zeros(N-1,2);
xit1t=zeros(N-1,2);
% Start the iteration
for t=1:N
    xitt(t,:)=(xi10.*eta(t,:))/((xi10.*eta(t,:))*ones(2,1));
    xit1t(t,:)=xitt(t,:)*P';
    xi10=xit1t(t,:);
end
xit1t=[ppi';xit1t];

% Compute the likelihood
f=(log(sum(xit1t(1:end-1,:).*eta,2)));
if any(isreal(f)==0)
    S=1e6;
else
S = -sum(f);
end
