function [S,DCC,xitt,xit1t] = dcc_swarch(param) 

global uni 

q12(1,1) =(1-exp(-param(1)))/(1+exp(-param(1)));
q13(1,1) = (1-exp(-param(2)))/(1+exp(-param(2)));
q23(1,1) =(1-exp(-param(3)))/(1+exp(-param(3)));
nu = 4+96./(1+exp(-param(4)));
q12(1,2) =(1-exp(-param(5)))/(1+exp(-param(5)));
q13(1,2) =(1-exp(-param(6)))/(1+exp(-param(6)));
q23(1,2) = (1-exp(-param(7)))/(1+exp(-param(7)));
p11 =  1./(1+exp(-param(8)));
p22=  1./(1+exp(-param(9)));
alpha = 1./(1+exp(-param(10)));
N = size(uni,1);

%Gaussian state
xn = norminv(uni(:,1));
yn = norminv(uni(:,2));
zn = norminv(uni(:,3));

xn2 = xn.^2;
yn2 = yn.^2;
zn2 = zn.^2;

cross1n = xn.*yn;
cross2n = xn.*zn;
cross3n = yn.*zn;

%Student state
xt = tinv(uni(:,1),nu).*sqrt((nu-2)/nu);
yt = tinv(uni(:,2),nu).*sqrt((nu-2)/nu);
zt = tinv(uni(:,3),nu).*sqrt((nu-2)/nu);

xt2 = xt.^2;
yt2 = yt.^2;
zt2 = zt.^2;

cross1t = xt.*yt;
cross2t = xt.*zt;
cross3t = yt.*zt;
q11(1,1:2) = 1.0;
q22(1,1:2) = 1.0;
q33(1,1:2) = 1.0;
for i=2:N
    % State Gaussian
   q11(i,1) = q11(1,1)+alpha*(xn(i-1,1).^2-q11(1,1));
   q12(i,1) = q12(1,1)+alpha*(cross1n(i-1,1)-q12(1,1));  
   q22(i,1) = q22(1,1)+alpha*(yn(i-1,1).^2-q22(1,1));    
   q33(i,1) = q33(1,1)+alpha*(zn(i-1,1).^2-q33(1,1));
   q13(i,1) = q13(1,1)+alpha*(cross2n(i-1,1)-q13(1,1));  
   q23(i,1) = q23(1,1)+alpha*(cross3n(i-1,1)-q23(1,1));    
    %State Student
   q11(i,2) = q11(1,2)+alpha*(xt(i-1,1).^2-q11(1,2));
   q12(i,2) = q12(1,2)+alpha*(cross1t(i-1,1)-q12(1,2));  
   q22(i,2) = q22(1,2)+alpha*(yt(i-1,1).^2-q22(1,2));    
   q33(i,2) = q33(1,2)+alpha*(zt(i-1,1).^2-q33(1,2));
   q13(i,2) = q13(1,2)+alpha*(cross2t(i-1,1)-q13(1,2));  
   q23(i,2) = q23(1,2)+alpha*(cross3t(i-1,1)-q23(1,2));  
end
%
dcc12n = q12(:,1)./sqrt(q11(:,1).*q22(:,1));
dcc13n = q13(:,1)./sqrt(q11(:,1).*q33(:,1));
dcc23n = q23(:,1)./sqrt(q33(:,1).*q22(:,1));
%
dcc12t = q12(:,2)./sqrt(q11(:,2).*q22(:,2));
dcc13t = q13(:,2)./sqrt(q11(:,2).*q33(:,2));
dcc23t = q23(:,2)./sqrt(q33(:,2).*q22(:,2));
%
v12t = real((dcc12t-dcc23t.*dcc13t));
v13t = real((dcc12t.*dcc23t-dcc13t));
v23t = real((dcc23t-dcc12t.*dcc13t));
v1t = (1-dcc23t.^2);
v2t = (1-dcc13t.^2);
v3t = (1-dcc12t.^2);
%State Gaussian
v1n = (1-dcc23n.^2);
v2n = (1-dcc13n.^2);
v3n = (1-dcc12n.^2);
v12n = real((dcc12n-dcc23n.*dcc13n));
v13n = real((dcc12n.*dcc23n-dcc13n));
v23n = real((dcc23n-dcc12n.*dcc13n));
%

% Gather the correlation
DCC.Gaussian.dcc12=dcc12n;
DCC.Gaussian.dcc13=dcc13n;
DCC.Gaussian.dcc23=dcc23n;
%
DCC.Student.dcc12=dcc12t;
DCC.Student.dcc13=dcc13t;
DCC.Student.dcc23=dcc23t;
%
%
% Loglikelihood
%Gaussian state
lnL(:,1) = -0.5.*log(1+2.*dcc12n.*dcc13n.*dcc23n-dcc12n.^2-dcc13n.^2-dcc23n.^2)...
    -0.5.*(xn2.*v1n+yn2.*v2n+zn2.*v3n-2.*v12n.*cross1n+2.*v13n.*cross2n-2.*v23n.*cross3n)...
    ./(1+2.*dcc12n.*dcc13n.*dcc23n-dcc12n.^2-dcc13n.^2-dcc23n.^2)...
    +0.5.*xn2+0.5.*yn2+0.5.*zn2;
% Student state
lnL(:,2) = - 0.5.*log(1 + 2*dcc12t.*dcc23t.*dcc13t - dcc12t.^2 - dcc13t.^2 - dcc23t.^2)...
    - ((nu+3)*0.5) * log(1 + 1/(nu-2) * 1./(1+2*dcc12t.*dcc23t.*dcc13t-dcc12t.^2-dcc13t.^2-dcc23t.^2) ...
    .* (xt2.*v1t+yt2.*v2t+zt2.*v3t-2.*v12t.*cross1t+2.*v13t.*cross2t-2.*v23t.*cross3t))...
    +((nu+1).*0.5)*log((1+xt2./(nu-2)).*(1+yt2./(nu-2)).*(1+zt2./(nu-2)))+gammaln((nu+3)/2)...
    -3.*gammaln((nu+1)/2)+2.*gammaln(nu/2);
% Now we set the Markov Switching approach
eta=exp(lnL);
P=[p11, 1-p22;...
   1-p11, p22];
A=[eye(2)-P; ones(1,2)];
eN1=[zeros(2,1);
    1];
ppi=inv(A'*A)*A'*eN1;
xi10=ppi';
xitt=zeros(N-1,2);
xit1t=zeros(N-1,2);
%
for t=1:N
    xitt(t,:)=(xi10.*eta(t,:))/((xi10.*eta(t,:))*ones(2,1));
    xit1t(t,:)=xitt(t,:)*P';
    xi10=xit1t(t,:);
end
xit1t=[xi10;xit1t];
%
f=(log(sum(xit1t(1:end-1,:).*eta,2)));
if any(isreal(f)==0)
    S=1e6;
else
S = -sum(f);
end

end