clear all;
clc;

%% Import series
[prices,Date] = xlsread('datos completo',3,'A10:D5179'); 
    % Sheet 4: UK; Sheet 5: Japan; Sheet 6: Brazil
% Weekly data
DayNumber = weekday(datestr(Date)); %get the day of the week of each day
% Check that we have weekly data and not biweekly data
vec = DayNumber==6; % vector de fechas que coinciden en viernes
idx = find(vec==1) ;
iwant = diff(idx)-1;
clear iwant idx vec

DateW = Date((DayNumber==6)); % Friday quote
datewt = datetime(DateW, 'InputFormat', 'MM/dd/yyyy');
Tp = length(DateW);
exc_rate = prices((DayNumber==6),1); % Exchange rate EUR/USD
eurostoxx = prices((DayNumber==6),2); % EUROSTOXX
gold = prices((DayNumber==6),3); % Gold
pricesw = [exc_rate, eurostoxx, gold]; 

% Calculate logaritmic returns
returns = log(pricesw(2:end,:)./pricesw(1:end-1,:));
r_fx = returns(:,1); % Variations of exchange rate USD/EUR
r_st = returns(:,2); % Logaritmic returns of EUROSTOXX
r_gold = returns(:,3); % Logaritmic returns of gold
returns = [r_fx, r_st, r_gold];
T = length(returns);

% Calculate correlations (Kendall)
corr_K_fxgold = corr(r_fx,r_gold,'Type','Kendall');
corr_K_fxst = corr(r_fx,r_st,'Type','Kendall');
corr_K_stgold = corr(r_st,r_gold,'Type','Kendall');

totalcorr_fx_K = abs(corr_K_fxgold) + abs(corr_K_fxst);
totalcorr_st_K = abs(corr_K_stgold) + abs(corr_K_fxst);
totalcorr_gold_K = abs(corr_K_fxgold) + abs(corr_K_stgold);
% Highest correlation with other assets: exchange rate


%% Marginal models
%garchtype = [{'GARCH'},{'GJR'},{'EWMA'},{'APARCH'},{'GARCHM'}];
%errortype = [{'Gaussian'}, {'t'}, {'Skewedt'}];

P = 1; % AR lags
Q = 0; % MA lags

options = optimset('Display','iter','MaxFunEvals',1.0e6,'MaxIter',1.0e6,'TolFun',1.0e-5);

% Exchange rate (EUR/USD)
[params_fx,u_fx,mu_fx,sigma2_fx,z_fx,LLF_fx,pd_fx] = ...
            EstimateModel(r_fx,P,Q,'APARCH','Skewedt',options);
[aic_fx,bic_fx] = aicbic(LLF_fx,length(params_fx),T);

% Stock (EUROSTOXX)
[params_st,u_st,mu_st,sigma2_st,z_st,LLF_st,pd_st] = ...
            EstimateModel(r_st,P,Q,'APARCH','Skewedt',options);
[aic_st,bic_st] = aicbic(LLF_st,length(params_st),T);        
% Gold
[params_gold,u_gold,mu_gold,sigma2_gold,z_gold,LLF_gold,pd_gold] = ...
            EstimateModel(r_gold,P,Q,'APARCH','Skewedt',options);
[aic_gold,bic_gold] = aicbic(LLF_gold,length(params_gold),T);      


%%
global uni 
uni = [u_fx, u_st, u_gold];
% % % % % % % % % % % % % % % % % % % % % % % % % % Parte agregada por Javier
%
% Anhade un analisis temporal de las correlaciones a lo largo del tiempo
% para motivar la dinamica
for t=1:size(uni,1)-52*5
    Sigma(:,:,t)=corr(norminv(uni(t:t+52*5,:)));
end
figure
hAxes=axes()
    hP(1)=plot(datewt(4:end-52*5),permute(Sigma(1,2,:),[3,2,1]))
    hold on
    hP(2)=plot(datewt(4:end-52*5),permute(Sigma(1,3,:),[3,2,1]))
    hP(3)=plot(datewt(4:end-52*5),permute(Sigma(2,3,:),[3,2,1]))
 h_legend=legend(hP,'FX- Stock', 'FX - Gold','Stock-Gold')
set(h_legend,'interpreter','latex')
set(hAxes,'TickLabelInterpreter','latex')
set(get(hAxes,'Title'),'string','Time-varying correlation obtained from a rolling windows approach','interpreter','latex')
set(get(hAxes,'xlabel'),'string','Time','interpreter','latex')
set(get(hAxes,'ylabel'),'string','$\rho$','interpreter','latex')

% Highest positive correlation between stock and gold --> No crisis period
rho0=Sigma(:,:,find(max(permute(Sigma(2,3,:),[3,2,1]))==permute(Sigma(2,3,:),[3,2,1])))
% Highest negative correlation between stock and gold --> Crisis period!!
rho00=Sigma(:,:,find(min(permute(Sigma(2,3,:),[3,2,1]))==permute(Sigma(2,3,:),[3,2,1])))
% Compute a mixture of elliptic copulas : Gaussiana in state 1 and Student in state 2
param_opt3t = fminsearch('EllipticMixture',[-log((1-rho0(1,2))./(1+rho0(1,2))),-log((1-rho0(1,3))./(1+rho0(1,3))),-log((1-rho0(3,2))./(1+rho0(3,2))),...
 -log(96/(7-4)-1),...
    -log((1-rho00(1,2))./(1+rho00(1,2))),-log((1-rho00(1,3))./(1+rho00(1,3))),-log((1-rho00(3,2))./(1+rho00(3,2))),-log(1./0.99-1),-log(1./0.99-1)],options)
%
[S,DCC,xitt,xit1t] = EllipticMixture(param_opt3t) 
% Kim's algorithm to get smoothed probabilities
N=size(xitt,2);
T=size(xitt,1);
xitT=zeros(T-1,2);
xitT=[xitT; xitt(T,:)];
P=[1./(1+exp(-param_opt3t(end-1))), 1-1./(1+exp(-param_opt3t(end)));...
   1-1./(1+exp(-param_opt3t(end-1))), 1./(1+exp(-param_opt3t(end)))];
for t=1:T-1
	a=xitt(T-t,:)'.*(P'*(xitT(T-t+1,:)'./xit1t(T+1-t,:)'));
	xitT(T-t,:)=a';
end
%Plot the probabilities of being at each state
figure
hAxes=axes()
hP2=plot(datewt(4:end),xitT.*100,'LineWidth',1.5)
h_legend=legend(hP2,'Gaussian state', 'Student state')
set(h_legend,'interpreter','latex')
set(hAxes,'TickLabelInterpreter','latex')
set(get(hAxes,'Title'),'string','Smoothed probabilities','interpreter','latex')
set(get(hAxes,'xlabel'),'string','Time','interpreter','latex')
set(get(hAxes,'ylabel'),'string','$\%$','interpreter','latex')
grid on
dcc12n =(1-exp(-param_opt3t(1)))/(1+exp(-param_opt3t(1)));
dcc13n = (1-exp(-param_opt3t(2)))/(1+exp(-param_opt3t(2)));
dcc23n = (1-exp(-param_opt3t(3)))/(1+exp(-param_opt3t(3)));
nu = 4+96./(1+exp(-param_opt3t(4)));
dcc12t = (1-exp(-param_opt3t(5)))/(1+exp(-param_opt3t(5)));
dcc13t = (1-exp(-param_opt3t(6)))/(1+exp(-param_opt3t(6)));
dcc23t = (1-exp(-param_opt3t(7)))/(1+exp(-param_opt3t(7)));
p11 =  1./(1+exp(-param_opt3t(8)));
p22=  1./(1+exp(-param_opt3t(9)));
% %
[1,dcc12n,dcc13n;...
    dcc12n,1,dcc23n;...
    dcc13n,dcc23n,1]
[1,dcc12t,dcc13t;...
    dcc12t,1,dcc23t;...
    dcc13t,dcc23t,1]
% Calculo del SWARCH-DCC
param_opt4t = fminsearch('dcc_swarch',[param_opt3t,-log(1./0.2-1)],options)
%
[S,DCC,xitt,xit1t] = dcc_swarch(param_opt4t)
%
dcc12nSW =(1-exp(-param_opt4t(1)))/(1+exp(-param_opt4t(1)));
dcc13nSW = (1-exp(-param_opt4t(2)))/(1+exp(-param_opt4t(2)));
dcc23nSW = (1-exp(-param_opt4t(3)))/(1+exp(-param_opt4t(3)));
nuSW = 4+96./(1+exp(-param_opt4t(4)));
dcc12tSW = (1-exp(-param_opt4t(5)))/(1+exp(-param_opt4t(5)));
dcc13tSW = (1-exp(-param_opt4t(6)))/(1+exp(-param_opt4t(6)));
dcc23tSW = (1-exp(-param_opt4t(7)))/(1+exp(-param_opt4t(7)));
p11SW =  1./(1+exp(-param_opt4t(8)));
p22SW =  1./(1+exp(-param_opt4t(9)));
alphaSW = 1./(1+exp(-param_opt4t(10)));
%
% Kim's algorithm to get smoothed probabilities
N=size(xitt,2);
T=size(xitt,1);
xitT=zeros(T-1,2);
xitT=[xitT; xitt(T,:)];
P=[p11SW, 1-p22SW;...
   1-p11SW, p22SW];
for t=1:T-1
	a=xitt(T-t,:)'.*(P'*(xitT(T-t+1,:)'./xit1t(T+1-t,:)'));
	xitT(T-t,:)=a';
end
figure(98)
plot(DCC.Gaussian.dcc23)
hold on
plot(DCC.Student.dcc23)
plot(sum([DCC.Gaussian.dcc23, DCC.Student.dcc23].*xitT,2))
% Calculo del SWARCH-DCC permitiendo dos pares de estados dependiendo de t y de
% t-1 --> resultados muy similares
param_opt5t = fminsearch('dcc_swarch_v1',param_opt4t,options)
%
[S,DCC,xitt,xit1t] = dcc_swarch_v1(param_opt5t)
