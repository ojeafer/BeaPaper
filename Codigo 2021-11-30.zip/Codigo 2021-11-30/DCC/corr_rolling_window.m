function Sigma_rw = corr_rolling_window(unif,date,param_opt,dist)
if dist == 1 % Normal
    for t = 1:size(unif,1)-52*5
        Sigma_rw(:,:,t) = corr(norminv(unif(t:t+52*5,:)));
    end
elseif dist == 2 % Student t
    nu = param_opt(end);
    for t = 1:size(unif,1)-52*5
        Sigma_rw(:,:,t) = corr(tinv(unif(t:t+52*5,:),nu));
    end
else
    disp('dist must take values 1 or 2')
end

% Plots
figure(dist)
hAxes=axes();
    hP(1)=plot(date(1:end-52*5),permute(Sigma_rw(1,2,:),[3,2,1]));
    hold on
    hP(2)=plot(date(1:end-52*5),permute(Sigma_rw(1,3,:),[3,2,1]));
    hP(3)=plot(date(1:end-52*5),permute(Sigma_rw(2,3,:),[3,2,1]));
    hP(4)=plot(date(1:end-52*5),zeros(1,length(date(1:end-52*5))));
h_legend=legend(hP,'EUR/USD - EUROSTOXX50', 'EUR/USD - Gold','EUROSTOXX50 - Gold');
set(h_legend,'interpreter','latex')
set(hAxes,'TickLabelInterpreter','latex')
set(get(hAxes,'Title'),'string','Time-varying correlation obtained from a rolling windows approach','interpreter','latex')
set(get(hAxes,'xlabel'),'string','Time','interpreter','latex')
set(get(hAxes,'ylabel'),'string','$\rho$','interpreter','latex')
