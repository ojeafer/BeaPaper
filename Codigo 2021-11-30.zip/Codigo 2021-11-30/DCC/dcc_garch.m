function [lnL_dcc,dcc12,dcc13,dcc23,param_opt] = dcc_garch(unif,param0,date,dist)

global uni 
uni = [unif(:,1), unif(:,2), unif(:,3)];

alpha0 = param0(1);
beta0 = param0(2);
if dist == 2 % Student t
    nu0 = param0(end);
end

options = optimset('Display','notify','MaxFunEvals',1.0e6,'MaxIter',1.0e6,'TolFun',1.0e-5);

if dist == 1 % Normal
    param_opt = fminsearch('dcc_garch3v_normal',param0,options);
    [lnL_dcc,dcc12,dcc13,dcc23] = dcc_garch3v_normal(param_opt);

elseif dist == 2 % Student t     
    alphatr0 = -log(1/alpha0 - 1);
    betatr0 = log(beta0/(1-alpha0-beta0));
    nutr0 = log(nu0) + 3;
    param0t = [alphatr0 betatr0 nutr0];

    paramtr_optt = fminsearch('dcc_garch3v_t',param0t,options);
    [lnL_dcc,dcc12,dcc13,dcc23] = dcc_garch3v_t(paramtr_optt);
    param_opt = [(1+exp(-paramtr_optt(1)))^(-1)
                  exp(paramtr_optt(2))/(1+exp(paramtr_optt(1))+exp(paramtr_optt(2)))
                  exp(paramtr_optt(3)-3)];

else
    disp('dist must take values 1 or 2')
end


% Plots
zero_line = zeros(length(dcc12),1);
createfigure_dcc(date, [dcc12, dcc13, dcc23, zero_line], dist)
