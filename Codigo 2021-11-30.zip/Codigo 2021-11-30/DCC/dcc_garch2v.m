function [lnL, dcc] = dcc_garch2v(params)

global x y 
N = length(x);
alpha = params(1); beta = params(2);
cross = x.*y;

x2 = x.^2; y2 = y.^2;
Z_prod = vertcat(x2, cross, y2);
Qbar = [1; mean(cross); 1];
Q = zeros(3,N);
Q(:,1) = Qbar;

q11(1) = 1; 
q12(1) = mean(cross);
q22(1) = 1;

dcc = zeros(N,1);
lnL = zeros(N,1);

for n = 2:N
    Q(:,n) = (1-alpha-beta)*Qbar + alpha*Z_prod(:,n-1) + beta*Q(:,n-1);
%     q11(n) = (1-alpha-beta)*q11(1) + alpha*(x(n-1).^2) + beta*q11(n-1);  
%     q12(n) = (1-alpha-beta)*q12(1) + alpha*(cross(n-1)) + beta*q12(n-1);
%     q22(n) = (1-alpha-beta)*q22(1) + alpha*(y(n-1).^2) + beta*q22(n-1);         
end


dcc = Q(2,:) ./ sqrt(Q(1,:).*Q(3,:));
% dcc = q12 ./ sqrt(q11.*q22);

% Loglikelihood
lnL = -0.5*log(1-dcc.^2)-0.5*(x.^2+y.^2-2*dcc.*cross)./(1-dcc.^2);
lnL = - sum(lnL);


end
