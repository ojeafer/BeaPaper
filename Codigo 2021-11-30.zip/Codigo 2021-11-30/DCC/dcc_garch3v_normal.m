function [lnL,dcc12,dcc13,dcc23] = dcc_garch3v_normal(param)
% Dynamic conditional correlation with GARCH standard model. Normal
% distribution for innovations
%
% SYNTAX: [lnL,dcc12,dcc13,dcc23] = dGARCHtri2(param)
%
% INPUTS:
%   param: parameters of GARCH model and innovations distribution
%       alpha, beta: parameters of GARCH(1,1) (standard) model
%
% OUTPUTS:
%   lnL: loglikelihood 
%   dcc12: dynamic correlation between innovations 1 and 2
%   dcc13: dynamic correlation between innovations 1 and 3
%   dcc23: dynamic correlation between innovations 2 and 3

global uni 

alpha = param(1);
beta = param(2);
n = size(uni,1);

eps(:,1) = norminv(uni(:,1));
eps(:,2) = norminv(uni(:,2));
eps(:,3) = norminv(uni(:,3));
innovax = eps(:,1);
innovay = eps(:,2);
innovaz = eps(:,3);
cross1 = innovax.*innovay;
cross2 = innovax.*innovaz;
cross3 = innovay.*innovaz;

q11(1,1) = 1.0;
q22(1,1) = 1.0;
q33(1,1) = 1.0;
q12(1,1) = mean(cross1);
q13(1,1) = mean(cross2);
q23(1,1) = mean(cross3);

for i=2:n
   q11(i,1) = q11(1,1)+beta*(q11(i-1,1)-q11(1,1))+alpha*(innovax(i-1,1).^2-q11(1,1));
   q12(i,1) = q12(1,1)+beta*(q12(i-1,1)-q12(1,1))+alpha*(cross1(i-1,1)-q12(1,1));  
   q22(i,1) = q22(1,1)+beta*(q22(i-1,1)-q22(1,1))+alpha*(innovay(i-1,1).^2-q22(1,1));    
   q33(i,1) = q33(1,1)+beta*(q33(i-1,1)-q33(1,1))+alpha*(innovaz(i-1,1).^2-q33(1,1));
   q13(i,1) = q13(1,1)+beta*(q13(i-1,1)-q13(1,1))+alpha*(cross2(i-1,1)-q13(1,1));  
   q23(i,1) = q23(1,1)+beta*(q23(i-1,1)-q23(1,1))+alpha*(cross3(i-1,1)-q23(1,1));  
end

dcc12 = q12./sqrt(q11.*q22);
dcc13 = q13./sqrt(q11.*q33);
dcc23 = q23./sqrt(q33.*q22);

x1 = (1-dcc23.^2); x2 = (1-dcc13.^2); x3 = (1-dcc12.^2); x12 = real((dcc12-dcc23.*dcc13));
x13 = real((dcc12.*dcc23-dcc13)); x23 = real((dcc23-dcc12.*dcc13));


% Loglikelihood function
lnL = -0.5.*log(1+2.*dcc12.*dcc13.*dcc23-dcc12.^2-dcc13.^2-dcc23.^2)...
    -0.5.*(innovax.^2.*x1+innovay.^2.*x2+innovaz.^2.*x3-2.*x12.*cross1+2.*x13.*cross2-2.*x23.*cross3)...
    ./(1+2.*dcc12.*dcc13.*dcc23-dcc12.^2-dcc13.^2-dcc23.^2);
lnL = -sum(lnL);
