function [lnL,dcc12,dcc13,dcc23] = dcc_garch3v_t(param) 
%% Dynamic conditional correlation with GARCH standard model. Student t
% distribution for innovations
%
%% SYNTAX: [lnL,dcc12,dcc13,dcc23] = dcc_garch3v_t(param)
%
%% INPUTS:
%   param: parameters of GARCH model and innovations distribution
%       alpha, beta: parameters of GARCH(1,1) (standard) model
%       nu: degrees of freedom of Student t distribution
%
%% OUTPUTS:
%   lnL: loglikelihood 
%   dcc12: dynamic correlation between innovations 1 and 2
%   dcc13: dynamic correlation between innovations 1 and 3
%   dcc23: dynamic correlation between innovations 2 and 3
%
%%
global uni 

alphatr = param(1);
betatr = param(2);
nutr = param(3);
N = size(uni,1);

alpha = (1+exp(-alphatr))^(-1);
beta = exp(betatr) / (1+exp(alphatr)+exp(betatr));
nu = exp(nutr-3);

eps(:,1) = tinv(uni(:,1),nu)*sqrt((nu-2)/nu); % Standardized innovations
eps(:,2) = tinv(uni(:,2),nu)*sqrt((nu-2)/nu);
eps(:,3) = tinv(uni(:,3),nu)*sqrt((nu-2)/nu);

x = eps(:,1);
y = eps(:,2);
z = eps(:,3);

x2 = x.^2;
y2 = y.^2;
z2 = z.^2;
cross1 = x.*y;
cross2 = x.*z;
cross3 = y.*z;

q11(1,1) = 1.0;
q22(1,1) = 1.0;
q33(1,1) = 1.0;
q12(1,1) = mean(cross1);
q13(1,1) = mean(cross2);
q23(1,1) = mean(cross3);

for i = 2:N
   q11(i,1) = q11(1,1) + beta*(q11(i-1,1)-q11(1,1)) + alpha*(x(i-1,1).^2-q11(1,1));
   q12(i,1) = q12(1,1) + beta*(q12(i-1,1)-q12(1,1)) + alpha*(cross1(i-1,1)-q12(1,1));  
   q22(i,1) = q22(1,1) + beta*(q22(i-1,1)-q22(1,1)) + alpha*(y(i-1,1).^2-q22(1,1));    
   q33(i,1) = q33(1,1) + beta*(q33(i-1,1)-q33(1,1)) + alpha*(z(i-1,1).^2-q33(1,1));
   q13(i,1) = q13(1,1) + beta*(q13(i-1,1)-q13(1,1)) + alpha*(cross2(i-1,1)-q13(1,1));  
   q23(i,1) = q23(1,1) + beta*(q23(i-1,1)-q23(1,1)) + alpha*(cross3(i-1,1)-q23(1,1));  
end

dcc12 = q12./sqrt(q11.*q22);
dcc13 = q13./sqrt(q11.*q33);
dcc23 = q23./sqrt(q33.*q22);
dcc12 = real(dcc12);
dcc13 = real(dcc13);
dcc23 = real(dcc23);

v12 = real((dcc12-dcc23.*dcc13));
v13 = real((dcc12.*dcc23-dcc13));
v23 = real((dcc23-dcc12.*dcc13));
v1 = (1-dcc23.^2);
v2 = (1-dcc13.^2);
v3 = (1-dcc12.^2);


% Loglikelihood
lnL = - 0.5.*log(1 + 2*dcc12.*dcc23.*dcc13 - dcc12.^2 - dcc13.^2 - dcc23.^2)...
    - ((nu+3)*0.5) * log(1 + 1/(nu-2) * 1./(1+2*dcc12.*dcc23.*dcc13-dcc12.^2-dcc13.^2-dcc23.^2) ...
    .* (x2.*v1+y2.*v2+z2.*v3-2.*v12.*cross1+2.*v13.*cross2-2.*v23.*cross3))...
    +((nu+1).*0.5)*log((1+x2./(nu-2)).*(1+y2./(nu-2)).*(1+z2./(nu-2)))+gammaln((nu+3)/2)...
    -3.*gammaln((nu+1)/2)+2.*gammaln(nu/2);
lnL = -sum(lnL);

% lnL = log(gamma((nu+1)*0.5) / (gamma(nu*0.5)*sqrt((nu-2)*pi))) ...
%     - log(1 + 2*dcc12.*dcc23.*dcc13 - dcc12.^2 - dcc13.^2 - dcc23.^2)...
%     - ((nu+1)*0.5) * log(1 + 1/(nu-2) * 1./(1+2*dcc12.*dcc23.*dcc13-dcc12.^2-dcc13.^2-dcc23.^2) ...
%     .* (x2 + y2 + z2 - 2*dcc12.*cross1 - 2*dcc13.*cross2 - 2*dcc23.*cross3));
% lnL = -sum(lnL);