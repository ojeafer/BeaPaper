clear
clc

load('ForecastVine_Japan')
    r_fx_forecast = returns_forecast(:,1);
        r_fx_f = returns_forecast(1:size(w_mES2_week,2),1);
    r_st_forecast = returns_forecast(:,2);
        r_st_f = returns_forecast(1:size(w_mES2_week,2),2);
    r_gold_forecast = returns_forecast(:,3);
        r_g_f = returns_forecast(1:size(w_mES2_week,2),3); 


%% codeGraph
qU = 1-sqrt(0.01);
qD = sqrt(0.01);

r_2a_port0 = (r_fx_f+r_g_f)'.*w_mES2_week(1,:) + r_st_f'.*w_mES2_week(2,:); r_2a_port = r_2a_port0';
r_3a_port0 = r_fx_f'.*w_mES3_week(1,:) + r_st_f'.*w_mES3_week(2,:) + r_g_f'.*w_mES3_week(3,:); r_3a_port = r_3a_port0';
r_ge_f = r_g_f + r_fx_f;

x = [r_st_f; % stock real returns in the out-of-sample period
     r_st_f;
     r_st_f;
     r_st_f]; 
y = [r_fx_f; % FX real returns in the out-of-sample period
     r_ge_f; % gold in local currency real returns in the out-of-sample period
     r_2a_port; % 2-assets portfolio real returns in the out-of-sample period
     r_3a_port]; % 3-assets portfolio real returns in the out-of-sample period 

for i = 1:length(x) 
    if i<=length(r_st_f)
        type{i}='Exchange rate'           ;
    elseif i>length(r_st_f) & i<=length(r_st_f)*2
        type{i}='Gold (in local currency)';
    elseif i>length(r_st_f)*2 & i<=length(r_st_f)*3
        type{i}='Two-assets portfolio'    ;
    else
        type{i}='Three-assets portfolio'  ;
    end
end


%
xD = [r_st_f(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1); % rendimientos por debajo del cuantil 10% (VaR)
      r_st_f(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1);
      r_st_f(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1);
      r_st_f(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1)];
yD = [r_fx_f(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1); % rendimientos de FX cuando stock esta en su cola izq
      r_ge_f(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1);
      r_2a_port(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1);
      r_3a_port(r_st_f(:,1)<prctile(r_st_f(:,1),qD*100),1)];

clear type2 
for i=1:sum(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1))*4
    if i<=sum(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1))
        type2{i}='Exchange rate'           ;
    elseif i>sum(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1)) & ...
           i<=sum(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1))*2
        type2{i}='Gold (in local currency)';
    elseif i>sum(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1))*2 & ...
           i<=sum(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1))*3
        type2{i}='Two-assets portfolio'    ;
    else
        type2{i}='Three-assets portfolio'  ;  
    end
end


%% Plot
Fig1=figure(1);
hScatter1=scatterhist(x,y,'Group',type','Kernel','on','Location','SouthEast',...
                          'Direction','out',...
                          'Color',[[0.619607865810394 0.823529422283173 0.886274516582489];...
                                  [0.929411768913269 0.694117665290833 0.125490203499794];...
                                  [0.635294139385223 0.0784313753247261 0.184313729405403];...
                                  [0.0784313753247261 0.168627455830574 0.549019634723663]],...
                         'LineStyle',{'-','-.',':','--'},...
                         'LineWidth',[2,2,2,2],'Marker','+odx','MarkerSize',[8,6,6,8]);

% Fig2=figure(2);
% hScatter2=scatterhist(xD,yD,'Group',type2','Kernel','on','Location','SouthEast',...
%     'Direction','out','Color','kbrg','LineStyle',{'-','-.',':','--'},...
%     'LineWidth',[2,2,2,2],'Marker','+odx','MarkerSize',[4,5,6,4]);

Children=get(Fig1,'Children')
set(Children(3),'FontSize',20,'TickLabelInterpreter','LateX')
ChildX=get(Children(1),'Children')
% delete(ChildX(2))
% delete(ChildX(3))
set(get(Children(2),'XLabel'),'String','stock returns','interpreter','latex','Visible','off')
set(get(Children(2),'YLabel'),'String','portfolio returns','interpreter','latex')
set(Children(4),'FontSize',20,'Interpreter','LateX')
set(get(Children(5),'Title'),'string','Returns distribution out-of-sample','FontSize',28,'interpreter','latex')

ylim=get(Children(2),'YLim');
xlim=get(Children(2),'XLim');
ChildS=get(Children(4),'Children');
ChildS(4,1)=line([prctile(r_st_f(:,1),qD*100),prctile(r_st_f(:,1),qD*100)],ylim) % representa el VaR (linea vertical)
set(ChildS(4,1),'Color',[0,0,0],'LineWidth',1.5,'LineStyle',':','Display','$VaR(0.1)$ stock')
st=get(Children(4),'String')
st{1,4}='$VaR(0.1)$ stock'
set(Children(4),'String',st)
ChildY=get(Children(2),'Children')
delete(ChildY(2:4))
% set(Children(2),'NextPlot','add')
% 
% hold on
% set(get(hScatter1(3),'Children'),'Parent',Children(2))
% % set(Children(2),'ylim',[-0.2215 28])

% Hacer yellow box 
ancho = prctile(r_st_f(:,1),qD*100) - xlim(1);
hBoxVaR= annotation('rectangle',[0.35,0.35,ancho,0.55],...
                    'LineStyle', '--',...
                    'Color','r',...
                    'LineWidth', 1)
set(hBoxVaR,'Position',[0.100 0.3500 0.2450 0.5500])
set(hBoxVaR,'FaceColor','yellow','FaceAlpha',.2,'LineStyle','none')

% Representar los CoVaR (lineas y valores)
ChildS(6,1)=line(xlim,[mean(r_fx_f(r_fx_f(:,1)<prctile(r_fx_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1)),... % rendimientos del stock por debajo del CoVaR
    mean(r_fx_f(r_fx_f(:,1)<prctile(r_fx_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))],...
    'Color',[0.619607865810394 0.823529422283173 0.886274516582489],'LineStyle','-','LineWidth',1.5);  
ChildS(7,1)=line(xlim,[mean(r_ge_f(r_ge_f(:,1)<prctile(r_ge_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1)),...
    mean(r_ge_f(r_ge_f(:,1)<prctile(r_ge_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))],...
    'Color',[0.929411768913269 0.694117665290833 0.125490203499794],'LineStyle','-.','LineWidth',1.5);  
ChildS(8,1)=line(xlim,[mean(r_2a_port(r_2a_port<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1)),...
    mean(r_2a_port(r_2a_port<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))],...
    'Color',[0.635294139385223 0.0784313753247261 0.184313729405403],'LineStyle',':','LineWidth',1.5);
ChildS(9,1)=line(xlim,[mean(r_3a_port(r_3a_port<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1)),...
    mean(r_3a_port(r_3a_port<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))],...
    'Color',[0.0784313753247261 0.168627455830574 0.549019634723663],'LineStyle','--','LineWidth',1.5);
st=get(Children(4),'String');
st{1,6}='$CoES_{p|s}$ exchange rate'
st{1,7}='$CoES_{p|s}$ gold'
st{1,8}='$CoES_{p|s}$ two-assets portfolio'
st{1,9}='$CoES_{p|s}$ three-assets portfolio'
set(Children(4),'String',st);

hT1=text(xlim(2)-0.07,mean(r_fx_f(r_fx_f(:,1)<prctile(r_fx_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))-0.01,...
    sprintf('%0.2f \\%%',mean(r_fx_f(r_fx_f<prctile(r_fx_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))*100),...
    'Color',[0.619607865810394 0.823529422283173 0.886274516582489],'FontSize',16,'interpreter','latex')
hT2=text(xlim(2)-0.04,mean(r_ge_f(r_ge_f(:,1)<prctile(r_ge_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))-0.01,...
    sprintf('%0.2f \\%%',mean(r_ge_f(r_ge_f(:,1)<prctile(r_ge_f(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))*100),...
    'Color',[0.929411768913269 0.694117665290833 0.125490203499794],'FontSize',16,'interpreter','latex')
hT3=text(xlim(2)-0.04,mean(r_2a_port(r_2a_port(:,1)<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))+0.01,...
    sprintf('%0.2f \\%%',mean(r_2a_port(r_2a_port<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100)))*100),...
    'Color',[0.635294139385223 0.0784313753247261 0.184313729405403],'FontSize',16,'interpreter','latex')
hT4=text(xlim(2)-0.03,mean(r_3a_port(r_3a_port(:,1)<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))+0.01,...
    sprintf('%0.2f \\%%',mean(r_3a_port(r_3a_port<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100)))*100),...
    'Color',[0.0784313753247261 0.168627455830574 0.549019634723663],'FontSize',16,'interpreter','latex')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot (only two portfolios)
stock = x;
portfolio_returns = y;
Fig1=figure(1);
hScatter1=scatterhist(stock,portfolio_returns,'Group',type','Kernel','on','Location','SouthEast',...
                          'Direction','out',...
                          'Color',[[0.635294139385223 0.0784313753247261 0.184313729405403];...
                                  [0.0784313753247261 0.168627455830574 0.549019634723663]],...
                         'LineStyle',{':','--'},...
                         'LineWidth',[2,2],'Marker','ox','MarkerSize',[6,8]);

Children=get(Fig1,'Children')
set(Children(3),'FontSize',20,'TickLabelInterpreter','LateX')
ChildX=get(Children(1),'Children')
% delete(ChildX(2))
% delete(ChildX(3))
set(get(Children(2),'XLabel'),'String','stock returns','interpreter','latex','Visible','off')
set(get(Children(2),'YLabel'),'String','portfolio returns','interpreter','latex')
set(Children(4),'FontSize',20,'Interpreter','LateX')
set(get(Children(5),'Title'),'string','Returns distribution out-of-sample','FontSize',28,'interpreter','latex')

ylim=get(Children(2),'YLim');
xlim=get(Children(2),'XLim');
ChildS=get(Children(4),'Children');
ChildS(4,1)=line([prctile(r_st_f(:,1),qD*100),prctile(r_st_f(:,1),qD*100)],ylim) % representa el VaR (linea vertical)
set(ChildS(4,1),'Color',[0,0,0],'LineWidth',1.5,'LineStyle','-.','Display','$VaR(0.1)$ stock')
st=get(Children(4),'String')
st{1,4}='$VaR(0.1)$ stock'
set(Children(4),'String',st)
ChildY=get(Children(2),'Children')
delete(ChildY(3))

% Hacer yellow box 
ancho = prctile(r_st_f(:,1),qD*100) - xlim(1);
hBoxVaR= annotation('rectangle',[0.35,0.35,ancho,0.55],...
                    'LineStyle', '--',...
                    'Color','r',...
                    'LineWidth', 1)
set(hBoxVaR,'Position',[0.100 0.3500 0.2450 0.5500])
set(hBoxVaR,'FaceColor','yellow','FaceAlpha',.2,'LineStyle','none')

% Representar los CoVaR (lineas y valores)
ChildS(4,1)=line(xlim,[mean(r_2a_port(r_2a_port<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1)),...
    mean(r_2a_port(r_2a_port<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))],...
    'Color',[0.635294139385223 0.0784313753247261 0.184313729405403],'LineStyle',':','LineWidth',1.5);
ChildS(5,1)=line(xlim,[mean(r_3a_port(r_3a_port<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1)),...
    mean(r_3a_port(r_3a_port<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))],...
    'Color',[0.0784313753247261 0.168627455830574 0.549019634723663],'LineStyle','--','LineWidth',1.5);
st=get(Children(4),'String');
st{1,4}='$CoES_{p|s}$ two-asset portfolio'
st{1,5}='$CoES_{p|s}$ three-asset portfolio'
set(Children(4),'String',st);

hT1=text(xlim(2)-0.04,mean(r_2a_port(r_2a_port(:,1)<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))+0.01,...
    sprintf('%0.2f \\%%',mean(r_2a_port(r_2a_port<prctile(r_2a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100)))*100),...
    'Color',[0.635294139385223 0.0784313753247261 0.184313729405403],'FontSize',16,'interpreter','latex')
hT2=text(xlim(2)-0.03,mean(r_3a_port(r_3a_port(:,1)<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100),1))+0.01,...
    sprintf('%0.2f \\%%',mean(r_3a_port(r_3a_port<prctile(r_3a_port(prctile(r_st_f(:,1),qD*100)>r_st_f(:,1),1),qD*100)))*100),...
    'Color',[0.0784313753247261 0.168627455830574 0.549019634723663],'FontSize',16,'interpreter','latex')
