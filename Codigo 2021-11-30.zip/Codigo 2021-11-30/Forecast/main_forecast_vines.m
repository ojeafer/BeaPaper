clear all
clc

load('Main_Japan')
load('Vines_Japan_nuevo')

%% Forecast for returns (from 01/01/2020 to 01/06/2021)
Date_forecast = Date_total(5218:end);
datenumer=datetime(Date_forecast, 'InputFormat', 'dd/MM/yyyy');
DayNumber = weekday(datenumer); %get the day of the week of each day

% Check that we have weekly data and not biweekly data
vec = DayNumber==6; % vector de fechas que coinciden en viernes
idx = find(vec==1) ;
iwant = diff(idx)-1;
clear iwant idx vec

DateWF = Date_forecast((DayNumber==6)); % Friday quote
datef = datetime(DateWF, 'InputFormat', 'dd/MM/yyyy');

prices_forecast = prices_total(5215:end,:);
    exc_rate_forecast = prices_forecast((DayNumber==6),1); % Exchange rate EUR/USD
    stock_forecast = prices_forecast((DayNumber==6),2); % EUROSTOXX
    gold_forecast = prices_forecast((DayNumber==6),3); % Gold
pricesw_forecast = [exc_rate_forecast, stock_forecast, gold_forecast]; 
returns_forecast = log(pricesw_forecast(2:end,:)./pricesw_forecast(1:end-1,:));
    r_fx_forecast = returns_forecast(:,1);
    r_st_forecast = returns_forecast(:,2);
    r_gold_forecast = returns_forecast(:,3);
datef2 = datef(2:end);


%% Simulate returns 
structure_dependence.CopulaStructure = optim_model.copula_best;
structure_dependence.CopulaDynamic = [optim_model.Dynamics{1,1}(1), ...
                                      optim_model.Dynamics{1,2}(1), ...
                                      optim_model.Dynamics{1,3}(1)];

T_f = size(returns_forecast,1);
W = 1e4;

options = optimset('Display','Iter','MaxFunEvals',1.0e5,'MaxIter',1.0e5,'TolFun',1.0e-8,'TolX',1.0e-8);

% Simulate vine copula
R_week0 = zeros(1,W,3);
R_month0 = zeros(1,W,3);

tic
for i = 1:round(size(returns_forecast,1)/4) - 1 % Simulamos los rendimientos de cada mes de la muestra 
    i
    if i == 1
        r = returns;
%         params_st2 = [params_st(1:6); 0.0; 2.0; params_st(end-1:end)]; % for Japan
        params_st2 = [params_st(1:7); 2.0; params_st(end-1:end)]; % for Brazil
        params_marg = [params_fx, params_st2, params_gold];

        structure_dependence.output = output_best;
        structure_dependence.paramtr = optim_model.params{1,3};
            param0 = structure_dependence.paramtr;
        structure_dependence.output.theta = output_best.theta;
            theta12 = structure_dependence.output.theta{1,1};
            theta13 = structure_dependence.output.theta{1,2};
            theta23_1 = structure_dependence.output.theta{1,3};
        structure_dependence.output.uu = output_best.uu;
        
    else
        r_new(:,:) = mean(output_forecast{i-1,1}.R_sim,2);
        r = [r; r_new];
        
        % Optim marginal
        clear uni
        [params_marg(:,1),uni(:,1)] = EstimateModel(r(:,1),P(1),Q(1),'APARCH','Skewedt',options);
        [params_marg2,uni0] = EstimateModel(r(:,2),P(2),Q(2),'GARCH','Skewedt',options);
            uni(:,2) = uni0; % for Japan
            params_marg(:,2) = [params_marg2(1:6); 0.0; 2.0; params_marg2(end-1:end)];                
%            uni(:,2) = [uni0(1); uni0]; % for Brazil
%            params_marg(:,2) = [params_marg2(1:7); 2.0; params_marg2(end-1:end)];
        [params_marg(:,3),uni(:,3)] = EstimateModel(r(:,3),P(3),Q(3),'APARCH','Skewedt',options);

        % Optim vine model
        param0_2 = fminsearch('JointDependence_CVine',param0,options,uni,...
                    structure_dependence.CopulaStructure',structure_dependence.CopulaDynamic');
            clear param0
            param0 = param0_2; clear param0_2
        [~,output1] = JointDependence_CVine(param0,uni,...
                       structure_dependence.CopulaStructure',structure_dependence.CopulaDynamic');
        structure_dependence.output = output1;
        structure_dependence.paramtr = param0;
        
        theta12_new = output_forecast{i-1,1}.theta_avg{1,1};
        theta12 = [theta12; theta12_new];
        theta13_new = output_forecast{i-1,1}.theta_avg{1,2};
        theta13 = [theta13; theta13_new];
        theta23_1_new = output_forecast{i-1,1}.theta_avg{1,3};
        theta23_1 = [theta23_1; theta23_1_new];
        structure_dependence.output.theta{1,1} = theta12;
        structure_dependence.output.theta{1,2} = theta13;
        structure_dependence.output.theta{1,3} = theta23_1;
        
%         structure_dependence.output.uu = output_forecast{i-1,1}.uu;
        
%         if (i == 2) | (i == 3) | (i == 4)
%             structure_dependence.output.uu{2,2} = [structure_dependence.output.uu{2,2}; 
%                                                    mean(output_forecast{i-1,1}.uu{2,2},3)];
%             structure_dependence.output.uu{3,2} = [structure_dependence.output.uu{3,2}; 
%                                                    mean(output_forecast{i-1,1}.uu{3,2},3)];
%             structure_dependence.output.uu{3,3} = [structure_dependence.output.uu{3,3}; 
%                                                    mean(output_forecast{i-1,1}.uu{3,3},3)];
%         elseif i == 5
%             structure_dependence.output.uu{2,2} = [output_forecast{i-2,1}.uu{2,2};
%                                                    output_forecast{i-1,1}.uu{2,2}];
%             structure_dependence.output.uu{3,2} = [output_forecast{i-2,1}.uu{3,2};
%                                                    output_forecast{i-1,1}.uu{3,2}];
%             structure_dependence.output.uu{3,3} = [output_forecast{i-2,1}.uu{3,3};
%                                                    output_forecast{i-1,1}.uu{3,3}];
%         else
%             structure_dependence.output.uu{2,2} = [structure_dependence.output.uu{2,2}; 
%                                                    output_forecast{i-1,1}.uu{2,2}];
%            structure_dependence.output.uu{3,2} = [structure_dependence.output.uu{3,2}; 
%                                                   output_forecast{i-1,1}.uu{3,2}];
%            structure_dependence.output.uu{3,3} = [structure_dependence.output.uu{3,3}; 
%                                                   output_forecast{i-1,1}.uu{3,3}];
%         end
%         for f = 1:size(uni,2)
%             structure_dependence.output.uu{f,1} = uni(:,f);
%         end
    end
    
    [R_sim,u_sim,vv,sigma,mu,theta] = ...
            SimulVines_OutofSample(r,params_marg,P,Q,structure_dependence,W,round(T_f/18));
            %round(T_f/18) is the number of weeks in a month of the
            %out-of-sample period, i.e. 4
    
    output_forecast{i,1}.R_sim = R_sim;
    output_forecast{i,1}.u_sim = u_sim;
    output_forecast{i,1}.uu = vv;
    output_forecast{i,1}.theta = theta;
    output_forecast{i,1}.theta_avg{1,1} = mean(theta{1,1}(2:end,:,:),3);
          % las dimensiones theta{1,1} son tx1xW, donde t=5=round(T_f/18)+1
          % -> para que el parametro simulado tenga la misma dimension
          % que los rendimientos simulados, cogemos solo los 4 ultimos valores
    output_forecast{i,1}.theta_avg{1,2} = mean(theta{1,2}(2:end,:,:),3);
    output_forecast{i,1}.theta_avg{1,3} = mean(theta{1,3}(2:end,:,:),3);
    output_forecast{i,1}.sigma = sigma;
    output_forecast{i,1}.mu = mu;
    
    R_week0 = [R_week0; R_sim];
    R_month0 = [R_month0; sum(R_sim,1)];

end
toc
%%
Rw = R_week0(2:end,:,:); clear R_week0
R_month = R_month0(2:end,:,:); clear R_month0

% Use aritmetic returns instead logaritmic returns
R_arit_week = exp(Rw)-1;
R_arit_month = exp(R_month)-1;
% * Usamos rendimientos aritméticos para explicar mejor la performance de la
% cartera y ver los resultados

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Construct portfolios 
%% Weekly returns
Rw = permute(R_arit_week(2:end,:,:),[2,3,1]); 

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Week.w2.W_mES, Portfolios_Forecast.Week.w2.ES_min] = ...
    weights_minES(Rw,size(Rw,3),2);

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Week.w3.W_mES, Portfolios_Forecast.Week.w3.ES_min] = ...
    weights_minES(Rw,size(Rw,3),3);


% Monthly returns
Rm = permute(R_arit_month,[2,3,1]); 

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Month.w2.W_mES, Portfolios_Forecast.Month.w2.ES_min] = ...
    weights_minES(Rm,size(Rm,3),2);

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Month.w3.W_mES, Portfolios_Forecast.Month.w3.ES_min] = ...
    weights_minES(Rm,size(Rm,3),3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% For the plot
% a) Expected Shortfall (model)
ESw_min2 = Portfolios_Forecast.Week.w2.ES_min;
ESw_min3 = Portfolios_Forecast.Week.w3.ES_min;

ESm_min2 = Portfolios_Forecast.Month.w2.ES_min;
ESm_min3 = Portfolios_Forecast.Month.w3.ES_min;


% b) Evolution of the weights
w_mES2_week = Portfolios_Forecast.Week.w2.W_mES;
w_mES3_week = Portfolios_Forecast.Week.w3.W_mES;
w_mES2_month = Portfolios_Forecast.Month.w2.W_mES;
w_mES3_month = Portfolios_Forecast.Month.w3.W_mES;


% c) Real returns
price_2019Q4 = prices(end,:); % Ultimo precio de la muestra hasta 2019
price_2020 = pricesw_forecast(1:size(w_mES2_week,2)+1,:); % Primer precio de la muestra out-of-sample
pricem_2020_ini(1,:) = price_2019Q4; % Ponemos como primer valor el último dato de 2019 para
% luego utilizarlo al calcular los rendimientos (ratio_price)
d = 3:4:size(w_mES2_week,2);
pricem_2020 = [pricem_2020_ini; price_2020(d,:)];  % size = TxN


t0 = 2:size(price_2020,1);
ratio_price1w = price_2020(t0,:)./price_2020(t0-1,:) - 1;
    ratio_pricew = ratio_price1w';  % size = NxT
t = 2:size(pricem_2020,1);
ratio_price1m = pricem_2020(t,:)./pricem_2020(t-1,:) - 1;
    ratio_pricem = ratio_price1m';  % size = NxT

Rreal_week2 = sum((ratio_pricew .* w_mES2_week),1);
Rreal_week3 = sum((ratio_pricew .* w_mES3_week),1);
Rreal_month2 = sum((ratio_pricem .* w_mES2_month),1);
Rreal_month3 = sum((ratio_pricem .* w_mES3_month),1);


%%
save('ForecastVine_Japan','Date_forecast','Date_total','datef','prices','prices_forecast',...
     'pricesw','pricesw_forecast','returns_forecast','returns','datef2',...
     'P','Q','params_marg','structure_dependence','T_f','W','R_week','R_month',...
     'R_arit_week','R_arit_month','output_forecast','theta12','theta13','theta23_1',...
     'ESw_min2','ESw_min3','ESm_min2','ESm_min3','w_mES2_week','w_mES3_week',...
     'w_mES2_month','w_mES3_month','price_2019Q4','price_2020','pricem_2020',...
     'ratio_pricew','ratio_pricem','Rreal_week2','Rreal_week3',...
     'Rreal_month2','Rreal_month3','Portfolios_Forecast')
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Risk measures
Rw = permute(R_arit_week,[2,3,1]);
alpha = 0.1; beta = alpha;
weights(:,:,1) = w_mES2_week;
weights(:,:,2) = w_mES3_week;

for t = 1:size(w_mES2_week,2)
    for i = 1:size(weights,3)
       R_p(:,t) = Rw(:,:,t) * weights(:,t,i);
       
       VaR(t,i) = prctile(R_p(:,t),alpha*100);
       ES(t,i) = mean(R_p(R_p(:,t)<=VaR(t,i),t));
       
       CoVaR(t,i) = prctile(R_p(Rw(:,2,t)<prctile(Rw(:,2,t),alpha*100),t),beta*100);
       CoES(t,i) = mean(R_p(R_p(:,t)<=CoVaR(t,i),t));
       
       CoVaR_med(t,i) = prctile(R_p(Rw(:,2,t)<prctile(Rw(:,2,t),50),t),beta*100);
       DeltaCoVaR(t,i) = CoVaR(t,i) - CoVaR_med(t,i);
       DeltaCoES(t,i) = mean(R_p(R_p(:,t)<=DeltaCoVaR(t,i),t));
    end   
end
    
%%
CoESsn = CoES;
if isnan(CoES(1,:))
    CoESsn(1,:) = 0;
end
for t = 2:size(w_mES2_week,2)
    for i = 1:2
        if isnan(CoES(t,i))
            CoESsn(t,i) = CoESsn(t-1,i);
        else
            CoESsn(t,i) = CoESsn(t,i);
        end
    end
end

%
DeltaCoESsn = DeltaCoES;
if isnan(DeltaCoES(1,:))
    DeltaCoESsn(1,:) = 0;
end
for t = 2:size(w_mES2_week,2)
    for i = 1:2
        if isnan(DeltaCoES(t,i))
            DeltaCoESsn(t,i) = DeltaCoESsn(t-1,i);
        else
            DeltaCoESsn(t,i) = DeltaCoESsn(t,i);
        end
    end
end

table_risk = [mean(ES); mean(CoESsn); mean(DeltaCoESsn)];
number_nan = [sum(isnan(ES)); sum(isnan(CoES)); sum(isnan(DeltaCoES))]
