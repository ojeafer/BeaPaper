function [R,unif_dep] = SimulGrid_DCC(dist,dcc,params_marg,mu,sigma2,T)
%% Simulate pseudo-returns using a grid and a given DCC model (Normal or Student t) 
%% SYNTAX: [R,unif_dep] = SimulGrid_DCC(dist,dcc,params_marg,mu,sigma2,T)
%
%% INPUTS:
%   dist: distribution of the residuals (DCC model)
%       dist==1: DCC-Normal
%       dist==2: DCC-T
%   dcc: dynamic correlation between assets (NxT)
%   params_marg: optim parameters of each marginal distribution
%   mu: matrix of means (NxT)
%   sigma: matrix of variances (NxT)
%   T: length of the path
%
%% OUTPUTS:
%   R: simulated returns
%   unif_dep: simulated dependents U(0,1)
%
%% 
lambda = params_marg(end-1,:); % Skewness 
nu = params_marg(end,:); % Degrees of freedom 


%% Create a grid [0,1]^3
x = [0.01:0.025:0.99]; 
y = [0.01:0.025:0.99];
z = [0.01:0.025:0.99];
[X,Y,V] = meshgrid(x,y,z); 
u_grid = [X(:),Y(:),V(:)]; % 64000x3

if dist==1
    Z = norminv(u_grid);
elseif dist==2
    Z = tinv(u_grid,nuC);
end

%% Simulation of returns
count = [size(dcc,2)-1:-1:0];

tic
for t = 1:size(dcc,2) 
    % Apply dependence structure (Cholesky)                           
    x1(t,:) = Z(:,1);
    x2(t,:) = dcc(1,t).*Z(:,1) + real(sqrt(1-dcc(1,t).^2)).*Z(:,2);
    x3(t,:) = dcc(2,t).*Z(:,1) + ...
          (dcc(3,t)-dcc(1,t).*dcc(2,t))./real(sqrt(1-dcc(1,t).^2)).*Z(:,2) + ...
          real(sqrt(1-dcc(2,t).^2-((dcc(3,t)-dcc(1,t).*dcc(2,t)).^2)/(1-dcc(1,t).^2))).*Z(:,3);
      
      if dist==1 % Gaussian copula
          unif_dep(:,:,t) = [normcdf(x1(t,:)); normcdf(x2(t,:)); normcdf(x3(t,:))];
      
      elseif dist==2 % Student t copula
          scaling_factor(t,:) = (nuC+2) ./ (nuC + Z(:,1).^2 + Z(:,2).^2);
          x3(t,:) = scaling_factor(t,:) .* x3(t,:);
          unif_dep(:,:,t) = [tcdf(x1(t,:),nuC); tcdf(x2(t,:),nuC); tcdf(x3(t,:),nuC)];
      end
      
      % Marginal distributions
      R(:,1,t) = skewtdis_inv(unif_dep(1,:,t),nu(1),lambda(1)).*sqrt(sigma2(end-count(t),1)) + mu(end-count(t),1); %R = WxNxT
      R(:,2,t) = skewtdis_inv(unif_dep(2,:,t),nu(2),lambda(2)).*sqrt(sigma2(end-count(t),2)) + mu(end-count(t),2);
      R(:,3,t) = skewtdis_inv(unif_dep(3,:,t),nu(3),lambda(3)).*sqrt(sigma2(end-count(t),3)) + mu(end-count(t),3);

      R1(:,t) = R(:,1,t);
      R2(:,t) = R(:,2,t);
      R3(:,t) = R(:,3,t);
      
      sprintf('%.2f %%',t/T*100)
end
toc

unif_dep = permute(unif_dep,[2,1,3]); % WxNxT
