function [R,unif_dep] = SimulGrid_Vines(copulatype,theta,params_marg,mu,sigma2,T)
%% Simulate pseudo-returns using a grid and a given vine structure 
%% SYNTAX: [R,unif_dep] = SimulGrid_Vines(copulatype,theta,T)
%
%% INPUTS:
%   copulatype: pair-copula models of the vine structure (1xN)
%   theta: parameters of the vine structure
%   T: length of the path
%
%% OUTPUTS:
%   R: simulated returns
%   unif_dep: simulated dependents U(0,1)
%
%%
lambda = params_marg(end-1,:); % Skewness 
nu = params_marg(end,:); % Degrees of freedom 


%% Create a grid [0,1]^3
x = [0.01:0.025:0.99]; 
y = [0.01:0.025:0.99];
z = [0.01:0.025:0.99];
[X,Y,V] = meshgrid(x,y,z); 
u_grid = [X(:),Y(:),V(:)]; % 64000x3

Z1 = u_grid(:,1)'; % u1 = u_fx
Z2 = u_grid(:,2)'; % u2|1 = u_st|u_fx
Z3 = u_grid(:,3)'; % u3|1,2 = u_g|(u_st|u_fx)

%% Simulation of returns
count = [T-1:-1:0];
W = size(u_grid,1); % Number of paths

tic
for t = 1:T
    t
    
    % Apply dependence structure                            
    u1(t,:) = Z1; % u_fx

    if strcmp(copulatype{1,1},'Gaussian') | strcmp(copulatype{1,1},'Student')
        u2(t,:) = qquantile_curve(copulatype{1,1},theta{1,1}(t,:),Z2,u1(t,:)); % u_st = C^{-1}(u_st|u_fx, u_fx)
    else
        for w = 1:W
            u2(t,w) = qquantile_curve(copulatype{1,1},theta{1,1}(t,:),Z2(w),u1(t,w)); % u_st = C^{-1}(u_st|u_fx, u_fx)
        end
    end
    
    if strcmp(copulatype{1,3},'Gaussian') | strcmp(copulatype{1,3},'Student')
        u3_1(t,:) = qquantile_curve(copulatype{1,3},theta{1,3}(t,:),Z3,Z2); % u_g|fx = C^{-1}(u_g|(u_st|u_fx), u_st|u_fx)
    else
        for w = 1:W
            u3_1(t,w) = qquantile_curve(copulatype{1,3},theta{1,3}(t,:),Z3(w),Z2(w)); % u_g|fx = C^{-1}(u_g|(u_st|u_fx), u_st|u_fx)
        end
    end

    if strcmp(copulatype{1,2},'Gaussian') | strcmp(copulatype{1,2},'Student')
        u3(t,:) = qquantile_curve(copulatype{1,2},theta{1,2}(t,:),u3_1(t,:),u1(t,:)); % u_g = C^{-1}(u_g|u_fx, u_st|u_fx)
    else
        for w = 1:W
            u3(t,w) = qquantile_curve(copulatype{1,2},theta{1,2}(t,:),u3_1(t,w),u1(t,w)); % u_g = C^{-1}(u_g|u_fx, u_st|u_fx)
        end
    end
    
    unif_dep(:,:,t) = [u1(t,:); u2(t,:); u3(t,:)];
      
    % Marginal distributions
    R(:,1,t) = skewtdis_inv(unif_dep(1,:,t),nu(1),lambda(1)).*sqrt(sigma2(end-count(t),1)) + mu(end-count(t),1); %R = WxNxT
    R(:,2,t) = skewtdis_inv(unif_dep(2,:,t),nu(2),lambda(2)).*sqrt(sigma2(end-count(t),2)) + mu(end-count(t),2);
    R(:,3,t) = skewtdis_inv(unif_dep(3,:,t),nu(3),lambda(3)).*sqrt(sigma2(end-count(t),3)) + mu(end-count(t),3);
end
toc

unif_dep = permute(unif_dep,[2,1,3]);
