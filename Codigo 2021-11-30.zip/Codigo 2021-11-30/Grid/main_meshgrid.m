clear all
clc

load('Main_Brazil2') 

%% MESHGRID
dist = 2;
    % dist == 1: the dependence is given by a conditional Gaussian copula
    % dist == 2: the dependence is given by a conditional Student t copula
    
% Correlation
if dist==1
    dcc = [dcc12, dcc13, dcc23]';
elseif dist==2
    dcc = [dcc12t, dcc13t, dcc23t]';
end


% Innovations distribution (Skewed Student t)
% params_st2 = zeros(10,1); % for UK
%     params_st2(1:7) = params_st(1:7); 
%     params_st2(8) = 2.0; 
%     params_st2(9) = params_st(end-1); 
%     params_st2(10) = params_st(end);
params_marg = [params_fx,params_st,params_gold];
lambda = params_marg(end-1,:); % Skewness 
nu = params_marg(end,:); % Degrees of freedom 
nuC = param_optt(3);


% Crear una rejilla [0,1]^3
% x = linspace(5e-3, 1-5e-3, 10);
x = [0.01:0.025:0.99]; 
y = [0.01:0.025:0.99];
z = [0.01:0.025:0.99];
[X,Y,V] = meshgrid(x,y,z); 
u_grid = [X(:),Y(:),V(:)]; % 64000x3

if dist==1
    Z = norminv(u_grid);
elseif dist==2
    Z = tinv(u_grid,nuC);
end


%% Simulation of returns
count = [length(dcc12)-1:-1:0];

tic
for t = 1:length(dcc12) 
    t
           
    % Apply dependence structure (Cholesky)                           
    x1(t,:) = Z(:,1);
    x2(t,:) = dcc(1,t).*Z(:,1) + real(sqrt(1-dcc(1,t).^2)).*Z(:,2);
    x3(t,:) = dcc(2,t).*Z(:,1) + ...
          (dcc(3,t)-dcc(1,t).*dcc(2,t))./real(sqrt(1-dcc(1,t).^2)).*Z(:,2) + ...
          real(sqrt(1-dcc(2,t).^2-((dcc(3,t)-dcc(1,t).*dcc(2,t)).^2)/(1-dcc(1,t).^2))).*Z(:,3);
      
      if dist==1 % Gaussian copula
          unif_dep(:,:,t) = [normcdf(x1(t,:)); normcdf(x2(t,:)); normcdf(x3(t,:))];
      
      elseif dist==2 % Student t copula
          scaling_factor(t,:) = (nuC+2) ./ (nuC + Z(:,1).^2 + Z(:,2).^2);
          x3(t,:) = scaling_factor(t,:) .* x3(t,:);
          unif_dep(:,:,t) = [tcdf(x1(t,:),nuC); tcdf(x2(t,:),nuC); tcdf(x3(t,:),nuC)];
      end
      
      % Marginal distributions
      R(:,1,t) = skewtdis_inv(unif_dep(1,:,t),nu(1),lambda(1)).*sqrt(sigma2_fx(end-count(t))) + mu_fx(end-count(t)); %R = 1000x3x742
      R(:,2,t) = skewtdis_inv(unif_dep(2,:,t),nu(2),lambda(2)).*sqrt(sigma2_st(end-count(t))) + mu_st(end-count(t));
      R(:,3,t) = skewtdis_inv(unif_dep(3,:,t),nu(3),lambda(3)).*sqrt(sigma2_gold(end-count(t))) + mu_gold(end-count(t));

      R1(:,t) = R(:,1,t);
      R2(:,t) = R(:,2,t);
      R3(:,t) = R(:,3,t);
end
toc



%%
load('SimulatedReturns2')

%%
SimulatedReturns2.Brazil.Student.u_grid = u_grid;
SimulatedReturns2.Brazil.Student.Z = Z;
SimulatedReturns2.Brazil.Student.unif_dep = unif_dep;
SimulatedReturns2.Brazil.Student.R = R;

%%
tic
save('SimulatedReturns2','SimulatedReturns2','datewt2','T2', '-v7.3')
toc
