clear all
clc

load('Main_Europe2') 
load('Vines_Europe')

%% MESHGRID
% Innovations distribution (Skewed Student t)
% params_st2 = zeros(10,1); % for UK
%     params_st2(1:7) = params_st(1:7); 
%     params_st2(8) = 2.0; 
%     params_st2(9) = params_st(end-1); 
%     params_st2(10) = params_st(end);
params_marg = [params_fx,params_st,params_gold];
lambda = params_marg(end-1,:); % Skewness 
nu = params_marg(end,:); % Degrees of freedom 


% Crear una rejilla [0,1]^3
x = [0.01:0.025:0.99]; 
y = [0.01:0.025:0.99];
z = [0.01:0.025:0.99];
[X,Y,V] = meshgrid(x,y,z); 
u_grid = [X(:),Y(:),V(:)]; % 64000x3

Z1 = u_grid(:,1)'; % u1 = u_fx
Z2 = u_grid(:,2)'; % u2|1 = u_st|u_fx
Z3 = u_grid(:,3)'; % u3|1,2 = u_g|(u_st|u_fx)

copulatype = optim_model.copula_best;
theta = output_best.theta;

%% Simulation of returns
count = [T2-1:-1:0];
W = size(u_grid,1);

tic
for t = 1:T2 
    t
    
    % Apply dependence structure                            
    u1(t,:) = Z1; % u_fx
    u3_1(t,:) = qquantile_curve(copulatype{1,3},theta{1,3}(t,:),Z3,Z2); % u_g|fx = C^{-1}(u_g|(u_st|u_fx), u_st|u_fx)
    
%     for w = 1:W
        u2(t,:) = qquantile_curve(copulatype{1,1},theta{1,1}(t,:),Z2,u1(t,:)); % u_st = C^{-1}(u_st|u_fx, u_fx)
        u3(t,:) = qquantile_curve(copulatype{1,2},theta{1,2}(t,:),u3_1(t,:),u1(t,:)); % u_g = C^{-1}(u_g|u_fx, u_st|u_fx)
%         sprintf('%.6f %%',(w+W*(t-1))/(W*T2)*100)
%     end
    
    unif_dep(:,:,t) = [u1(t,:); u2(t,:); u3(t,:)];
      
      % Marginal distributions
      R(:,1,t) = skewtdis_inv(unif_dep(1,:,t),nu(1),lambda(1)).*sqrt(sigma2_fx(end-count(t))) + mu_fx(end-count(t)); %R = 1000x3x742
      R(:,2,t) = skewtdis_inv(unif_dep(2,:,t),nu(2),lambda(2)).*sqrt(sigma2_st(end-count(t))) + mu_st(end-count(t));
      R(:,3,t) = skewtdis_inv(unif_dep(3,:,t),nu(3),lambda(3)).*sqrt(sigma2_gold(end-count(t))) + mu_gold(end-count(t));
end
toc



%%
save('SimulatedReturns_Vine_Brazil','params_marg','lambda','nu','u_grid',...
     'Z1','Z2','Z3','unif_dep','R','datewt2','T2','optim_model','output_best', '-v7.3')
