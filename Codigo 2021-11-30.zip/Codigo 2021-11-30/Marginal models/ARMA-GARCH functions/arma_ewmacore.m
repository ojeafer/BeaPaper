function [mu,h,epsilon] = arma_ewmacore(parameters, data, p, q)
%%
%% arma_ewmacore: conditional mean and variance for the ARMA(p,x,q)-EWMA model
%
%% SYNTAX
% [mu,h] = arma_ewmacore(parameters, data, p, q)
%% INPUT:
%               parameters : parameters for the ARMA-EWMA model
%               data: input
%               p : lags for the AR model
%               q : lags for the MA model
%% OUTPUT:
%              mu : conditional mean
%              h : conditional variance
%              epsilon : standardized residuals
%%
if isempty(p)
    maxp=0;
else
    maxp=max(p);
end
%
if isempty(q)
    maxq=0;
else
    maxq=max(q);
end
np = length(p);
nq = length(q);
T = length(data);
errors = zeros(T-maxp,1);
y=data;
% Initial parameters
mu = [];
h = [];
    %% AR
for t=1:T+1
    mu(t,1)=parameters(1);
    if t>maxp
        for i=1:np
            mu(t,1) = mu(t,1) + parameters(1+i)*y(t-p(i));
        end
    end
end
    %% MA
errors = data(1:end,1)-mu(1:end-1); %mu goes from maxp+1 to T+1
for t=1:T+1 %we have deleted one observation due to the AR model
    if t>maxq
        for i=1:nq
            pseudo_mu(t,1) = parameters(1+np+i)*errors(t-q(i),1);
        end
        if t<T+1
            if nq~=0
                errors(t,1)=errors(t,1)-pseudo_mu(t,1);
            end
        end
    end
end
if nq~=0
    mu = mu + pseudo_mu;
end
    %% EWMA
T=size(errors,1);
h(1,1)=var(errors);
beta=parameters(1+np+nq+1);
for t = 2:T+1 
    h(t,1) = (1-beta)*errors(t-1).^2+beta*h(t-1,1);
end
epsilon=errors(1+np+nq+1:end)./sqrt(h(1+np+nq+1:end-1));