function [mu,h,epsilon] = arma_garchcore(parameters, data, p,q)
%%
%% garchcore: conditional mean and variance for the AR(p)-GARCH model
%
%% SYNTAX
% [mu,h] = garchcore(parameters, data, p)
%% INPUT:
%               parameters : parameters for the AR-GARCH model
%               data: input
%               p : lags for the AR model
%               q : lags for the MA model
%% OUTPUT:
%              mu : conditional mean
%              h : conditional variance
%              epsilon : standardized residuals
%% Reference:
% Bollerslev, 1986

%%
if isempty(p)
    maxp=0;
else
    maxp=max(p);
end
%
if isempty(q)
    maxq=0;
else
    maxq=max(q);
end
np = length(p);
nq = length(q);
T = length(data);
y=data;
% Initial parameters
mu = [];
h = [];
    %% AR
for t=1:T+1
    mu(t,1)=parameters(1);
    if t>maxp
        for i=1:np
            mu(t,1) = mu(t,1) + parameters(1+i)*y(t-p(i));
        end
    end
end
    %% MA
errors = data(1:end,1)-mu(1:end-1); %mu goes from maxp+1 to T+1
for t=1:T+1 %we have deleted one observation due to the AR model
    if t>maxq
        for i=1:nq
            pseudo_mu(t,1) = parameters(1+np+i)*errors(t-q(i),1);
        end
        if t<T+1
            if nq~=0
                errors(t,1)=errors(t,1)-pseudo_mu(t,1);
            end
        end
    end
end
if nq~=0
    mu = mu + pseudo_mu;
end
%% GARCH
T=size(errors,1);
h(1:max(maxq,maxp)+2,1)=var(errors(1+max(maxq,maxp):T,1));
omega=parameters(1+np+nq+1);
alpha=parameters(1+np+nq+2);
beta=parameters(1+np+nq+3);
for t = 2+max(maxq,maxp):T+1 
    h(t,1) = omega+alpha*errors(t-1).^2+beta*h(t-1,1);
end
epsilon=errors(1+np+nq+1:end)./sqrt(h(1+np+nq+1:end-1));
