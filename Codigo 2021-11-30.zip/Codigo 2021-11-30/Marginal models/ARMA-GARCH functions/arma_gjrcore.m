function [mu,h,epsilon] = arma_gjrcore(parameters, data, p, q)
%%
%% arma_gjrcore: conditional mean and variance for the ARMA(p,q)-GARCH-GJR model
%
%% SYNTAX
% [mu,h] = gjrcore(parameters, data, p, q)
%% INPUT:
%               parameters : parameters for the ARMA-EWMA model
%               data: input
%               p : lags for the AR model
%               q : lags for the MA model
%% OUTPUT:
%              mu : conditional mean
%              h : conditional variance
%              epsilon : standardized residuals
%% Reference:
% Glosten, Jagannathan and Runkle (1993)

%%
if isempty(p)
    maxp=0;
else
    maxp=max(p);
end
%
if isempty(q)
    maxq=0;
else
    maxq=max(q);
end
np = length(p);
nq = length(q);
T = length(data);
y=data;
% Initial parameters
mu = [];
h = [];
    %% AR
for t=1+maxp:T+1
    mu(t-maxp,1)=parameters(1);
    for i=1:np
        mu(t-maxp,1) = mu(t-maxp,1) + parameters(1+i)*y(t-p(i));
    end
end
    %% MA
errors = data(1+maxp:end,1)-mu(1:end-1); %mu goes from maxp+1 to T+1
for t=1+maxq:T-maxp %we have deleted one observation due to the AR model
    for i=1:nq
        pseudo_mu(t,1) = parameters(1+np+i)*errors(t-q(i),1);
    end
    if nq~=0
        errors(t,1)=errors(t,1)-pseudo_mu(t-maxq,1);
    end
end
        % Forecast
for i=1:nq
    pseudo_mu(T-maxp+1,1) = parameters(1+np+i)*errors(end-q(i),1);
end
if nq~=0
    mu = mu + pseudo_mu;
end
    %% GJR-GARCH
T=size(errors,1);
h(1,1)=var(errors);
omega=parameters(1+np+nq+1);
alpha=parameters(1+np+nq+2);
beta=parameters(1+np+nq+3);
gamma=parameters(1+np+nq+4);
for t = 2:T+1 
    h(t,1) = omega+alpha*errors(t-1).^2+beta*h(t-1,1)+(errors(t-1)<0)*gamma*errors(t-1).^2;
end
epsilon=errors(1+np+nq+1:end)./sqrt(h(1+np+nq+1:end-1));