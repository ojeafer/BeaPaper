function [table_corr,max_tau] = correlations(returns,names)
%% Pearson, Spearman and Kendall's correlation coefficients
%% SYNTAX: [table_corr,max_tau] = correlations(returns,names)
%
%% INPUTS:
%   returns: matrix of (logaritmic) returns
%   names: vector that contains the names of the series (for the table)
%          For example: names = {'EUR/USD', 'EUROSTOXX', 'Gold'}
%
%% OUTPUTS:
%   table_corr: table with the total correlation of each variable with the others
%               For example: total correlation of gold with stock and
%               exchange rate
%   max_tau: maximum value of the Kendall's tau
%
%%
% Returns
r_fx = returns(:,1);
r_st = returns(:,2);
r_gold = returns(:,3);

% Pearson
corr_P_fxgold = corr(r_fx,r_gold,'Type','Pearson');
corr_P_fxst = corr(r_fx,r_st,'Type','Pearson');
corr_P_stgold = corr(r_st,r_gold,'Type','Pearson');

% Spearman
corr_S_fxgold = corr(r_fx,r_gold,'Type','Spearman');
corr_S_fxst = corr(r_fx,r_st,'Type','Spearman');
corr_S_stgold = corr(r_st,r_gold,'Type','Spearman');

% Kendall
corr_K_fxgold = corr(r_fx,r_gold,'Type','Kendall');
corr_K_fxst = corr(r_fx,r_st,'Type','Kendall');
corr_K_stgold = corr(r_st,r_gold,'Type','Kendall');

% Sum
totalcorr_fx_P = abs(corr_P_fxgold) + abs(corr_P_fxst);
totalcorr_st_P = abs(corr_P_stgold) + abs(corr_P_fxst);
totalcorr_gold_P = abs(corr_P_fxgold) + abs(corr_P_stgold);

totalcorr_fx_S = abs(corr_S_fxgold) + abs(corr_S_fxst);
totalcorr_st_S = abs(corr_S_stgold) + abs(corr_S_fxst);
totalcorr_gold_S = abs(corr_S_fxgold) + abs(corr_S_stgold);

totalcorr_fx_K = abs(corr_K_fxgold) + abs(corr_K_fxst);
totalcorr_st_K = abs(corr_K_stgold) + abs(corr_K_fxst);
totalcorr_gold_K = abs(corr_K_fxgold) + abs(corr_K_stgold);

% Table
Pearson = [totalcorr_fx_P; totalcorr_st_P; totalcorr_gold_P];
Spearman = [totalcorr_fx_S; totalcorr_st_S; totalcorr_gold_S];
Kendall = [totalcorr_fx_K; totalcorr_st_K; totalcorr_gold_K];

table_corr = table(Pearson, Spearman, Kendall, 'RowNames',names);

% Maximum Kendall's tau 
max_tau = max(Kendall);

end
