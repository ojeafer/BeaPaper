function desc_analysis = descriptive_analysis(returns,n_obs,names)
%% Descriptive analysis for a dataset
%% SYNTAX: danalysis = desc_analysis(returns,n_obs,names)
%
%% INPUTS:
%   returns: vector or matrix of (logaritmic) returns
%   n_obs: length of the sample
%   names: vector that contains the names of the series (for the table)
%          For example: names = {'EUR/USD', 'EUROSTOXX', 'Gold'}
%
%% OUTPUT:
%   desc_analysis: table with the following stats:
%       Mean
%       Standard deviation
%       Median
%       Maximum
%       Minimum
%       Skewness
%       Kurtosis
%       Value of the Jarque Bera test
%
%% 
% Stats
mean_v = mean(returns); Mean = mean_v';
std_v = std(returns); St_deviation = std_v';

max_v = max(returns); Max = max_v';
min_v = min(returns); Min = min_v';
median_v = median(returns); Median = median_v';

q01 = quantile(returns,0.01); Quantile_01 = q01';
q25 = quantile(returns,0.25); Quantile_25 = q25';
q75 = quantile(returns,0.75); Quantile_75 = q75';
q99 = quantile(returns,0.99); Quantile_99 = q99';

Sk_v = skewness(returns); Skewness = Sk_v';
K_v = kurtosis(returns); Kurtosis = K_v'; 

JBtest = n_obs/6 * (Sk_v.*Sk_v + 0.25*(K_v-3).*(K_v-3)); JarqueBera_test = JBtest';
[~,p_value1] = jbtest(returns(:,1)); 
[~,p_value2] = jbtest(returns(:,2)); 
[~,p_value3] = jbtest(returns(:,3)); 
JB_pvalue = [p_value1; p_value2; p_value3];

% Table
desc_analysis = table(Mean, St_deviation, Max, Min,...
                Quantile_01, Quantile_25, Median, Quantile_75, Quantile_99, ...
                Skewness, Kurtosis, JarqueBera_test,JB_pvalue, ...
                'RowNames', names);

end
