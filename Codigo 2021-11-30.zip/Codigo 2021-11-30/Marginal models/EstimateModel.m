function [parameters,u,mu,sigma2,epsilon,LLF_marginal]=EstimateModel(data,P,Q,garchtype,errortype,options)
%% EstimateModel: ARMA(P,Q) model considering heteroscedasticity
%
%% SYNTAX
% [parameters,LLF_marginal,u,mu,sigma2,epsilon]=EstimateModel(data,P,Q,garchtype,options)
%
%% INPUT:
%               data : input
%               P : lags for the AR model
%               Q : lags for the MA model
%               garchtype : 'GARCH'/'GJR'/'EWMA'/'APARCH'
%               errortype : 'Gaussian'/'t'/'Skewedt'/'kernelGDP'
%                       *Note: Skewedt --> skewed t student , Hansel(1994)
%
%% OUTPUT:
%              parameters : parameters for the ARMA model with
%                           heteroscedasticity
%              LLF_marginal : maximum loglikelihood
%              u : cumulative distribution function of the data
%              mu : conditional mean given by the ARMA(P,Q) model
%              sigma2 : conditional variance
%              epsilon : standardized residual of the model
%
%%
if nargin==5
    options = optimset('Display','iter','TolCon',10^-6,'TolFun',10^-12,'TolX',10^-12,'MaxFunEvals',1e6,'MaxIter',1e6);
end
%% First stage of the IFM procedure
%% * 1st--> transform data
T= length(data); %  length of the input
if any(P==0)    %   if P has any value zero is deleted
    P(P==0)=[];
end
if any(Q==0)    %   if Q has any value zero is deleted
    Q(Q==0)=[];
end
np = length(P); %   number of lags in the AR model
nq = length(Q); %   number of lags in the MA model
maxp = max(P);  %   older lag in the AR model
if isempty(P) % no AR features
    maxp=0;
    np=0;
end
if isempty(Q)   %   no MA features
    nq=0;
end
[beta,e]=armodel(data,P);    %   initial values of the AR model
temptr_ar=-log((1-beta(1:1+np))./(1+beta(1:1+np))); %	transformation in order to keep the coefficients in feasible values
if nq~=0
    ma = aryule(e,max(Q)); % aryule: AR parameter estimation via Yule-Walker method
      % OUTPUT: [parameters,errors]
    temp_ma=ma(1+Q);
else
    temp_ma=[];
end
temptr=[temptr_ar;-log((1-temp_ma(:))./(1+temp_ma(:)))];   %   set of transformed initial values
%
switch garchtype    %   heteroscedasticity models
    case 'GARCH'
        temptr=[temptr; log(1e-4); -log(1/0.05-1); -log(1/0.92-1)]; % [ARMA params, omega, alpha, beta]
    case 'GJR'
        temptr=[temptr; log(1e-4); -log(1/0.05-1); -log(1/0.92-1); -log(1/1e-4-1)]; % [ARMA params, omega, alpha, beta, gamma]
    case 'EWMA'
        temptr=[temptr; -log(1/0.9-1)]; % [ARMA params, lambda]
    case 'APARCH'
        temptr=[temptr; log(1e-4); -log(1/0.05-1); -log(1/0.92-1); -log((1-0)./(1+0)); log(2)]; % [ARMA params, omega, alpha, beta, gamma, delta]
    case 'GARCHM'
        temptr=[temptr; log(1e-4); -log(1/0.05-1); -log(1/0.92-1); 0]; % [ARMA params, omega, alpha, beta, c]

end
%
switch errortype    %   assumption about the innovation distribution
    case 't'	%	the number of degrees of freedom is between 2 and 100
        nu0=10;
        temptr=[temptr;-log(97.9/(nu0-2.1)-1)]; % [ARMA-GARCH params, DoF]
    case 'Skewedt'	%	the number of degrees of freedom is between 2 and 100
        %   the skewness parameter is between -1 and 1
        nu0=10; lambda0=-0.1;
        temptr=[temptr;-log((1-lambda0)./(1+lambda0));-log(97.9/(nu0-2.1)-1)];
end


%% * 2nd --> Estimate equation
[param_tr] =  fminsearch('MarginalModel',temptr, options, data, garchtype, errortype, P, Q);
[LLF_marginal,mu,sigma2,epsilon,u,likeMarg] = MarginalModel(param_tr, data, garchtype, errortype, P, Q);


%% 3rd--> Undo the transformation
parameters=[(1-exp(-param_tr(1:1+np)))./(1+exp(-param_tr(1:1+np)))];
parameters=[parameters;param_tr(1+np+1:1+np)];
parameters=[parameters;(1-exp(-param_tr(1+np+1:1+np+nq)))./(1+exp(-param_tr(1+np+1:1+np+nq)))];

switch garchtype
    case 'GARCH'
        parameters=[parameters; exp(param_tr(1+np+nq+1));(1+exp(-param_tr(1+np+nq+2)))^(-1);(1+exp(-param_tr(1+np+nq+3)))^(-1)];
    case 'GJR'
        parameters=[parameters; exp(param_tr(1+np+nq+1));(1+exp(-param_tr(1+np+nq+2)))^(-1);(1+exp(-param_tr(1+np+nq+3)))^(-1);... % GARCH (standard) params
                    (1+exp(-param_tr(1+np+nq+4)))^(-1)]; % GJR specific param
    case 'EWMA'
        parameters=[parameters;(1+exp(-param_tr(1+np+nq+1)))^(-1)];
    case 'APARCH'
        parameters=[parameters; exp(param_tr(1+np+nq+1));(1+exp(-param_tr(1+np+nq+2)))^(-1);(1+exp(-param_tr(1+np+nq+3)))^(-1);... % GARCH (standard) params
            (1-exp(-param_tr(1+np+nq+4)))./(1+exp(-param_tr(1+np+nq+4)));exp(param_tr(1+np+nq+5))]; % APARCH specific params
    case 'GARCHM'
        parameters=[parameters; exp(param_tr(1+np+nq+1));(1+exp(-param_tr(1+np+nq+2)))^(-1);(1+exp(-param_tr(1+np+nq+3)))^(-1); ... % GARCH (standard) params
                    param_tr(1+np+nq+4)]; % GARCH-M specific param      
end

switch errortype
    case 't'
        parameters=[parameters;...
                    97.9*(1+exp(-param_tr(end)))^(-1)+2.1]; % Degrees of freedom
    case 'Skewedt'
        parameters=[parameters;...
                    (1-exp(-param_tr(end-1)))./(1+exp(-param_tr(end-1)));... % Skewness
                    97.9*(1+exp(-param_tr(end)))^(-1)+2.1]; % Degrees of freedom
end


end
