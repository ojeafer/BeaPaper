function [LLF_marginal,mu,sigma2,epsilon,u,likeMarg,parammarg]=MarginalModel(trparameters,data,garchtype,errortype,P,Q)
%% MarginalModel: ARMA(P,Q) model considering heteroscedasticity assessment
% it is called by margmodel
%% SYNTAX
% [LLF_marginal,mu,sigma2,epsilon]=MarginalModel(trparameters,data,garchtype,errortype,P,Q)
%% INPUT:
%               trparameters : transformed parameters
%               data : input
%               garchtype : 'GARCH'/'GJR'/'EWMA'/'APARCH'
%               errortype : 'Gaussian'/'t'/'Skewedt'
%               P : lags for the AR model
%               Q : lags for the MA model
%               
%% OUTPUT:
%              LLF_marginal : maximum loglikelihood
%              mu : conditional mean given by the ARMA(P,Q) model
%              sigma2 : conditional variance
%              stdresid : standardized residual of the model
%%
%% Function for the marginal structure: stage 2
np = length(P);	%   number of lags in the AR model
nq = length(Q); %   number of lags in the MA model

%% Undo transformation
temp_paramar=(1-exp(-trparameters(1:1+np)))./(1+exp(-trparameters(1:1+np)));
temp_paramma=(1-exp(-trparameters(1+1+np:1+np+nq)))./(1+exp(-trparameters(1+1+np:1+np+nq)));
switch garchtype
    case 'GARCH'
        temp_paramgarchtype=[exp(trparameters(1+np+nq+1));...
                            (1+exp(-trparameters(1+np+nq+2)))^(-1);...
                            (1+exp(-trparameters(1+np+nq+3)))^(-1)];
    case 'GJR'
        temp_paramgarchtype=[exp(trparameters(1+np+nq+1));...
                            (1+exp(-trparameters(1+np+nq+2)))^(-1);...
                            (1+exp(-trparameters(1+np+nq+3)))^(-1);...
                            (exp(-trparameters(1+np+nq+4)))^(-1)];
    case 'EWMA'
        temp_paramgarchtype=(1+exp(-trparameters(1+np+nq+1)))^(-1);
    case 'APARCH'
        temp_paramgarchtype=[exp(trparameters(1+np+nq+1));...
                            (1+exp(-trparameters(1+np+nq+2)))^(-1);...
                            (1+exp(-trparameters(1+np+nq+3)))^(-1);...
                            (1-exp(-trparameters(1+np+nq+4)))./(1+exp(-trparameters(1+np+nq+4)));...
                            exp(trparameters(1+np+nq+5))];
    case 'GARCHM'
        temp_paramgarchtype=[exp(trparameters(1+np+nq+1));...
                            (1+exp(-trparameters(1+np+nq+2)))^(-1);...
                            (1+exp(-trparameters(1+np+nq+3)))^(-1);...
                            trparameters(1+np+nq+4)];
end
temp_param=[temp_paramar;temp_paramma;temp_paramgarchtype]; % [AR params, MA params, GARCH params]
%
switch errortype
    case 't'
        temp_param=[temp_param;97.9./(1+exp(-trparameters(end)))+2.1];
    case 'Skewedt'
        temp_param=[temp_param;(1-exp(-trparameters(end-1)))./(1+exp(-trparameters(end-1)));97.9./(1+exp(-trparameters(end)))+2.1];
end
parammarg=temp_param;

%% arma_heterolik-->assessment of the ARMA model
[LLF_marginal,u,likeMarg,mu,sigma2,epsilon] = arma_heterolik(parammarg, data, garchtype, errortype, P, Q);

%%  Constrains
switch garchtype    % Constrains in the GARCH model
    case 'GARCH'
       if sum(temp_paramgarchtype(2:3))>1
           LLF_marginal=1e6;
       end
    case 'GJR'
        if strcmpi(errortype,'Skewedt')
            if (sum(temp_paramgarchtype(2:3))+ skewtdis_cdf(0, temp_param(end), temp_param(end-1))*temp_paramgarchtype(4))>1
                LLF_marginal=1e6;
            end
        else
            if (sum(temp_paramgarchtype(2:3))+0.5*temp_paramgarchtype(4))>1
                LLF_marginal=1e6;
            end
        end
    case 'APARCH'
       if sum(temp_paramgarchtype(2:3))>1
           LLF_marginal=1e6;
       end
    case 'GARCHM'
       if sum(temp_paramgarchtype(2:3))>1
           LLF_marginal=1e6;
       end       
end
