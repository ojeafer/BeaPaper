function [LLF_marginal,u,likelihoods,mu,sigma2,epsilon] = arma_heterolik(parameters, data, garchtype, errortype, P, Q)
%% arma_heterolik:  ARMA model with stochastic volatility (heterokedasticity)
%
%% SYNTAX
% [LLF_marginal,likelihoods,mu,sigma2,resid,epsilon] = arma_heterolik(parameters, data, garchtype, errortype, P, Q)
%
%% INPUT:
%               parameters : parameters for the AR model, GARCH and
%               distribution
%               data: input
%               garchtype: 'GARCH', 'GJR', 'EWMA' 
%               errortype : 'Gaussian', 't', 'Skewedt'
%               P : lags for the AR model
%               Q : lags for the MA model
%
%% OUTPUT:
%              u : uniform vector
%              LLF_marginal : sum of minus loglikelihood
%              likelihoods : likelihoods for each data
%              mu : conditional mean
%              sigma2 : conditional variance
%              epsilon : standardized residual
%
%%
if any(P==0)
    P(P==0)=[];
end
if any(Q==0)
    Q(Q==0)=[];
end
if isempty(P)
    maxp=0;
else
    maxp=max(P);
end
%
if isempty(Q)
    maxp=0;
else
    maxp=max(Q);
end

T = length(data);

if strcmp(errortype,'t') 
    nu = parameters(end);
elseif strcmp(errortype,'Skewedt')
    lamda = parameters(end-1);
    nu = parameters(end);
    c = gamma((nu+1)/2)/(sqrt(pi*(nu-2))*gamma(nu/2));
    a = 4*lamda*c*((nu-2)/(nu-1));
    b = 1 + 3*lamda^2 - a^2;
end

%% Estimation of conditional mean and variance of various specifications 
% given a set of parameters
switch garchtype
    case 'GARCH' % GARCH
        [mut,h,epsilon] = arma_garchcore(parameters,data,P,Q);
    case 'GJR' % GJR
        [mut,h,epsilon] = arma_gjrcore(parameters,data,P,Q); % 7 parameters
    case 'EWMA' % EWMA
        [mut,h,epsilon] = arma_ewmacore(parameters,data,P,Q);
    case 'APARCH' % APARCH
        [mut,h,epsilon] = arma_aparchcore(parameters,data,P,Q);
    case 'GARCHM' % EGARCH
        [mut,h,epsilon] = arma_garchmcore(parameters,data,P,Q); 
end

%% Estimation of the Log-Likelihood Function for the various distributions
likelihoods = [];
t = 1:size(epsilon,1);

mu=mut;
sigma2=h;
    
switch errortype
    case 'Gaussian' % GAUSSIAN
        likelihoods = -0.5*((log(h(t))) + epsilon.^2 + log(2*pi));
        u = normcdf(epsilon);
        %   bounds due to computational reasons
        u = max(u,1e-10);
        u = min(u,1-1e-10);
    case 't' % STUDENT's t-Distribution
        likelihoods = +gammaln(0.5*(nu+1)) - gammaln(nu/2) - 0.5*log(pi*(nu-2)) - 0.5*(log(h(t))) - ((nu+1)/2)*log(1 + epsilon.^2./(nu-2));
        u = tcdf(epsilon*sqrt((nu-2)/nu),nu);
        %   bounds due to computational reasons
        u = max(u,1e-10);
        u = min(u,1-1e-10);
    case 'Skewedt' % Hansen's Skew t-Distribution
        indicator1 = (epsilon<-a./b);
        indicator2 = (epsilon>=-a./b);
        likelihoods1 = log(b) + log(c) - ((nu+1)./2).*log(1+1./(nu-2).*((b.*indicator1.*epsilon+a)./(1-lamda)).^2);
        likelihoods2 = log(b) + log(c) - ((nu+1)./2).*log(1+1./(nu-2).*((b.*indicator2.*epsilon+a)./(1+lamda)).^2); 
        likelihoods = - 0.5*log(h(t)) + indicator1.*likelihoods1 + indicator2.*likelihoods2; 
        %%
        y1 = (b.*epsilon+a)./(1-lamda).*sqrt(nu./(nu-2));		
        y2 = (b.*epsilon+a)./(1+lamda).*sqrt(nu./(nu-2));
        cdf = (1-lamda).*tcdf(y1,nu).*(epsilon<-a./b);
        cdf = cdf + (epsilon>=-a./b).*((1+lamda).*tcdf(y2,nu)-lamda);
        u = cdf;
        %   bounds due to computational reasons
        u = max(u,1e-10);
        u = min(u,1-1e-10);
end

LLF_marginal=-sum(likelihoods); 

%
if isnan(LLF_marginal) | isinf(LLF_marginal)
    LLF_marginal=1e06;
end
end