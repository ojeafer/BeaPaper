function [beta,u]=armodel(Y,NLAGS)
%% arxmodel: Obtain the dependant variable and regressors for the AR model
%% 
%
%% SYNTAX:
%         [beta,u]=arxmodel(Y,NLAGS,x)
%
%% INPUT: 
%       Y : data column vector
%       NLAGS : row vector with the lags
%       x : exogenous variables (optional)
%% OUTPUT:
%       beta: coefficients
%       u : residual
%%
if isempty(NLAGS)   %   no lag considered
    NLAGS=0;
end
p=NLAGS;    %   lags of the AR
maxp=max(p);    %   older lag
if any(p==0)    %   if p has any value zero is deleted 
    p(p==0)=[];
end
np=length(p);   %   number of lags in the AR model
T=length(Y);    %	length of the data
Xlag=[ones(T-maxp,1)];  %   constant value
for ii=1:np
    Xlag=[Xlag,Y(1+maxp-p(ii):end-p(ii),1)];    %   adding lags of the endogenous variable to the set of explanatory variables
end
X=Xlag;
beta=X\Y(1+maxp:end,1); %   coefficients
u=Y(1+maxp:end,1)-X*beta;   %	residuals