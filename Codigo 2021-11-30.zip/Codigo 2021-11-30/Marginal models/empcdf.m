function f=empcdf(x);
%% empcdf: Assess the empirical cumulative distribution of x 
%
%% SYNTAX:
%        f=empcdf(x) 
%
%% INPUT:
%        x= sample
%       
%% OUTPUT:
%        f : value of the empirical cdf
%
%%
T=size(x,1);
x_sort=sort(x);
for s=1:T
    f(s,1)=sum(double(ge(x(s),x_sort)))/(T);
end
%%