clear all;
clc;

%% Import series
[prices_tot,Date_tot] = xlsread('datos datastream',3,'A2:D5588'); 
    % Sheet 1: Europe; Sheet 2: Japan; Sheet 3: Brazil; Sheet 4: UK
    prices = prices_tot(1:5218,:); % 2000-2019
    Date = Date_tot(1:5218,:);
    
% Weekly data
datenumer=datetime(Date, 'InputFormat', 'dd/MM/yyyy');
DayNumber = weekday(datenumer); %get the day of the week of each day
% Check that we have weekly data and not biweekly data
vec = DayNumber==6; % vector de fechas que coinciden en viernes
idx = find(vec==1) ;
iwant = diff(idx)-1;
clear iwant idx vec

DateW = Date((DayNumber==6)); % Friday quote
datewt = datetime(DateW, 'InputFormat', 'dd/MM/yyyy');
Tp = length(DateW);
dt2 = linspace(1,Tp+1,Tp);
exc_rate = prices((DayNumber==6),1); 
stock = prices((DayNumber==6),2); 
gold = prices((DayNumber==6),3); 
pricesw = [exc_rate, stock, gold]; 

% Calculate logaritmic returns
returns = log(pricesw(2:end,:)./pricesw(1:end-1,:));
r_fx = returns(:,1); % Variations of exchange rate 
r_st = returns(:,2); % Logaritmic returns of stock index
r_gold = returns(:,3); % Logaritmic returns of gold

T = length(returns);


%% Descriptive analysis 
names = {'Exchange rate    ';
         'Stock index      ';
         'Gold             '};
table_da = desc_analysis(returns,Tp,names)

% Plot empirical cdf
% [h,stats] = cdfplot(r_fx);
returns_low = [r_fx(r_st<prctile(r_st,5)),...
               r_st(r_st<prctile(r_st,5)),...
               r_gold(r_st<prctile(r_st,5))];
corr(returns_low,'type','kendall')

perc = 10;
corr_low = [(corr(r_fx(r_st<prctile(r_st,perc)), r_fx(r_st<prctile(r_st,perc)))),...
            (corr(r_fx(r_st<prctile(r_st,perc)), r_st(r_st<prctile(r_st,perc)))),...
            (corr(r_fx(r_st<prctile(r_st,perc)), r_gold(r_st<prctile(r_st,perc))));
            (corr(r_st(r_st<prctile(r_st,perc)), r_fx(r_st<prctile(r_st,perc)))),...
            (corr(r_st(r_st<prctile(r_st,perc)), r_st(r_st<prctile(r_st,perc)))),...
            (corr(r_st(r_st<prctile(r_st,perc)), r_gold(r_st<prctile(r_st,perc))));
            (corr(r_gold(r_st<prctile(r_st,perc)), r_fx(r_st<prctile(r_st,perc)))),...
            (corr(r_gold(r_st<prctile(r_st,perc)), r_st(r_st<prctile(r_st,perc)))),...
            (corr(r_gold(r_st<prctile(r_st,perc)), r_gold(r_st<prctile(r_st,perc))))]

% Calculate correlations
names_corr = {'Total correlation exchange rate';
              'Total correlation stock        ';
              'Total correlation gold         '};
[table_corr, max_tauK] = correlations(returns,names_corr)

%% Plots
% Prices
createfigure_prices(datewt,exc_rate,gold,stock,'Europe')


% Histograms
bins = 40;
figure (2);
subplot(1,3,1)
histfit(r_fx,bins,'normal') % Histogram of exchange rate returns vs Gaussian density
title('Histogram of EUR/USD returns','FontSize',14,'interpreter','latex')
legend('Returns','Gaussian fit','FontSize',13,'interpreter','latex')
subplot(1,3,2)
histfit(r_st,bins,'normal') % Histogram of stock returns vs Gaussian density
title('Histogram of EUROSTOXX 50 returns','FontSize',14,'interpreter','latex')
legend('Returns','Gaussian fit','FontSize',13,'interpreter','latex')
subplot(1,3,3)
histfit(r_gold,bins,'normal') % Histogram of gold returns vs Gaussian density
title('Histogram of gold returns','FontSize',14,'interpreter','latex')
legend('Returns','Gaussian fit','FontSize',13,'interpreter','latex')


% Scatter plot matrix
X = [r_fx, r_st, r_gold];
figure(3);
[S,Ax,BigAx,H,HAx] = plotmatrix(X);
    % S: graficos (ordenados por columnas)
    % AX: nombre de los ejes principales (matriz)
    % BigAx: titulo (escalar)
    % H: graficos de la diagonal (histogramas)
    % HAx: nombre de los ejes de los histogramas

H(1).EdgeColor = 'k'; H(1).FaceColor = 'r';  
H(2).EdgeColor = 'k'; H(2).FaceColor = 'r';  
H(3).EdgeColor = 'k'; H(3).FaceColor = 'r';  

title(BigAx,'Returns of GBP/USD, FTSE 100 and Gold', 'FontSize',15, 'interpreter','latex')
set(Ax,'FontSize',14,'TickLabelInterpreter','latex')


%% Marginal models
P_vec = [4, 1, 1]; % AR lags
    % Europe: P_vec = [4, 1, 1]; UK: P_vec = [1, 1, 1]; 
    % Japan: P_vec = [1, 1, 1]; Brazil: P_vec = [1, 1, 1];
Q_vec = [11, 13, 1]; % MA lags
    % Europe: Q_vec = [11, 13, 1]; UK: Q_vec = [1, 13, 1]; 
    % Japan: Q_vec = [1, 1, 1]; Brazil: Q_vec = [1, 1, 1];

garchtype = [{'GARCH'},{'GJR'},{'EWMA'},{'APARCH'},{'GARCHM'}];
errortype = [{'Gaussian'}, {'t'}, {'Skewedt'}];

options = optimset('Display','notify','MaxFunEvals',1.0e6,'MaxIter',1.0e6,'TolFun',1.0e-4);
[~,s] = size(returns);

for j = 1:s % for each asset
    r = returns(:,j);
    Q = Q_vec(j);
    P = P_vec(j);
    
    for e = 1:length(errortype) % for each innovations' distribution
        e
        for g = 1:length(garchtype) % for each garch model
            g
            i = (length(garchtype)*e + g) - length(garchtype);

            [parameters,u,mu,sigma2,epsilon,LLF_marginal] = ...
                EstimateModel(r,P,Q,garchtype{g},errortype{e},options);

            params_opt(1:length(parameters),i,j) = parameters;
            u_matrix(1:length(u),i,j) = u;
            mu_matrix(1:length(mu),i,j) = mu;
            sigma2_matrix(1:length(sigma2),i,j) = sigma2;
            epsilon_matrix(1:length(epsilon),i,j) = epsilon;
            LLF_mg(i,j) = LLF_marginal;

            [aic(g,e,j),bic(g,e,j)] = aicbic(LLF_marginal,length(parameters),T);
        end
    end

    % Volatility (std extrapolated h=52 periods)
    % https://www.ucm.es/data/cont/media/www/pag-41460/VOLATILIDAD.pdf pag.34
    for t = 1:T
        sigma2_matrix2(t,:,j) = sigma2_matrix(t,:,j) .* ...
            (52 + 2*params_opt(2,:,j)./(1-params_opt(2,:,j)).^2 .* ...
            ((52-1)*(1-params_opt(2,:,j))-params_opt(2,:,j).*(1-params_opt(2,:,j).^(52-1))));   
    end
    
    % Plot
    createfigure_garch_volatility(datewt(2:end), ...
    [sigma2_matrix2(:,1,j), sigma2_matrix2(:,2,j), ...
         sigma2_matrix2(:,3,j), sigma2_matrix2(:,4,j), sigma2_matrix2(:,5,j)]*100,...
    [sigma2_matrix2(:,6,j), sigma2_matrix2(:,7,j), ...
         sigma2_matrix2(:,8,j), sigma2_matrix2(:,9,j), sigma2_matrix2(:,10,j)]*100,...
    [sigma2_matrix2(:,11,j),sigma2_matrix2(:,12,j), ...
         sigma2_matrix2(:,13,j), sigma2_matrix2(:,14,j), sigma2_matrix2(:,15,j)]*100)
end


%%
mu_fx = mu_matrix(T-length(epsilon):T,:,1);
res_fx = epsilon_matrix(:,:,1);
sigma2_fx = sigma2_matrix(:,:,1);
u_fx = u_matrix(:,:,1);
z_fx = epsilon_matrix(:,:,1);

mu_st = mu_matrix(T-length(epsilon):T,:,2);
res_st = epsilon_matrix(:,:,2);
sigma2_st = sigma2_matrix(:,:,2);
u_st = u_matrix(:,:,2);
z_st = epsilon_matrix(:,:,2);

mu_gold = mu_matrix(T-length(epsilon):T,:,3);
res_gold = epsilon_matrix(:,:,3);
sigma2_gold = sigma2_matrix(:,:,3);
u_gold = u_matrix(:,:,3);
z_gold = epsilon_matrix(:,:,3);


%% Optimal parameters
params_fx_tot = params_opt(:,:,1)';
params_st_tot = params_opt(:,:,2)';
params_gold_tot = params_opt(:,:,3)';

% Akaike and Schwartz information criteria and Max loglikelihood function value
[TABLA_GARCH_FX, TABLA_GARCH_ST, TABLA_GARCH_GOLD] = selection_criteria(aic,bic,abs(LLF_mg));


%% Rename variables
difobs = length(sigma2_fx) - length(mu_fx) + 1;

z_fx_orig = z_fx; 
mu_fx_orig = mu_fx; 
sigma_fx_orig = sigma2_fx;
res_fx_orig = res_fx;
u_fx_orig = u_fx;
nu_t_fx = [params_opt(7,6,1), params_opt(8,7,1), params_opt(5,8,1), params_opt(9,9,1), params_opt(8,10,1)];
nu_St_fx = [params_opt(8,11,1), params_opt(9,12,1), params_opt(6,13,1), params_opt(10,14,1), params_opt(9,15,1)];
lambda_St_fx = [params_opt(7,11,1), params_opt(8,12,1), params_opt(5,13,1), params_opt(9,14,1), params_opt(8,15,1)];

z_st_orig = z_st; 
mu_st_orig = mu_st; 
sigma_st_orig = sigma2_st;
res_st_orig = res_st;
u_st_orig = u_st;
nu_t_st = [params_opt(7,6,2), params_opt(8,7,2), params_opt(5,8,2), params_opt(9,9,2), params_opt(8,10,2)];
nu_St_st = [params_opt(8,11,2), params_opt(9,12,2), params_opt(6,13,2), params_opt(10,14,2), params_opt(9,15,2)];
lambda_St_st = [params_opt(7,11,2), params_opt(8,12,2), params_opt(5,13,2), params_opt(9,14,2), params_opt(8,15,2)];

z_gold_orig = z_gold; 
mu_gold_orig = mu_gold;
sigma_gold_orig = sigma2_gold;
res_gold_orig = res_gold;
u_gold_orig = u_gold;
nu_t_gold = [params_opt(7,6,3), params_opt(8,7,3), params_opt(5,8,3), params_opt(9,9,3), params_opt(8,10,3)];
nu_St_gold = [params_opt(8,11,3), params_opt(9,12,3), params_opt(6,13,3), params_opt(10,14,3), params_opt(9,15,3)];
lambda_St_gold = [params_opt(7,11,3), params_opt(8,12,3), params_opt(5,13,3), params_opt(9,14,3), params_opt(8,15,3)];


%% Optimal model
z_fx = z_fx_orig(:,14);
res_fx = res_fx_orig(:,14);
mu_fx = mu_fx_orig(:,14);
u_fx = u_fx_orig(:,14);
sigma2_fx = sigma_fx_orig(difobs:end,14);
params_fx = params_fx_tot(14,:);
params_fx(params_fx==0) = [];

z_st = z_st_orig(:,14);
res_st = res_st_orig(:,14);
mu_st = mu_st_orig(:,14);
u_st = u_st_orig(:,14);
sigma2_st = sigma_st_orig(difobs:end,14);
params_st = params_st_tot(14,:);
params_st(params_st==0) = [];

z_gold = z_gold_orig(:,14);
res_gold = res_gold_orig(:,14);
mu_gold = mu_gold_orig(:,14);
u_gold = u_gold_orig(:,14);
sigma2_gold = sigma_gold_orig(difobs:end,14);
params_gold = params_gold_tot(14,:);
params_gold(params_gold==0) = [];


%% Plots of standardized residuals
% Resid acf and pacf (white noise)
figure(4);
subplot(2,3,1);
autocorr(res_fx,15);
title('ACF: residuals EUR/USD','FontSize',15,'interpreter','latex');
subplot(2,3,4);
parcorr(res_fx,15);
title('PACF: residuals EUR/USD','FontSize',15,'interpreter','latex');

subplot(2,3,2);
autocorr(res_st,15);
title('ACF: residuals EUROSTOXX 50','FontSize',15,'interpreter','latex');
subplot(2,3,5);
parcorr(res_st,15);
title('PACF: residuals EUROSTOXX 50','FontSize',15,'interpreter','latex');

subplot(2,3,3);
autocorr(res_gold,15);
title('ACF: residuals Gold','FontSize',15,'interpreter','latex');
subplot(2,3,6);
parcorr(res_gold,15);
title('PACF: residuals Gold','FontSize',15,'interpreter','latex');


% Scatter plots for pairs of data
figure(5);
subplot(1,3,1)
scatter(u_fx,u_gold)
title('EUR/USD vs Gold','interpreter','latex')
xlabel('EUR/USD','interpreter','latex')
ylabel('Gold','interpreter','latex')

subplot(1,3,2)
scatter(u_st,u_gold)
title('EUROSTOXX50 vs Gold','interpreter','latex')
xlabel('EUROSTOXX50','interpreter','latex')
ylabel('Gold','interpreter','latex')

subplot(1,3,3)
scatter(u_fx,u_st)
title('EUR/USD vs EUROSTOXX50','interpreter','latex')
xlabel('EUR/USD','interpreter','latex')
ylabel('EUROSTOXX50','interpreter','latex')


% Scatter plot for 3 variables
figure(6);
haxes = axes();
scatter3(u_fx,u_st,u_gold)
set(haxes,'TickLabelInterpreter','latex')
title('Scatter plot of GBP/USD, FTSE100 and Gold','interpreter','latex')
xlabel('Exchange rate','interpreter','latex')
ylabel('Stock index','interpreter','latex')
zlabel('Gold','interpreter','latex')


%% Backtesting
%% Distribution backtesting
[pValue,h0,table_tests] = test_distribution(z_st,nu_t_st(4),nu_St_st(4),lambda_St_st(4),[0.01,0.05,0.1]);


%% VaR backtesting
nu_vec = [params_fx(end), params_st(end), params_gold(end)];
lambda_vec = [params_fx(end-1), params_st(end-1), params_gold(end-1)];
mu = [mu_fx, mu_st, mu_gold];
sigma = [sqrt(sigma2_fx), sqrt(sigma2_st), sqrt(sigma2_gold)];

TT = min(length(mu_gold),min(length(mu_fx),length(mu_st)));
quant = [0.005:0.005:0.5]; % cuantil para el VaR 
for i = 1:2
for n = 1:size(mu,2) % numero activos
    for k = 1:length(quant)
%         % VaR parametrico
%         if n == 2 % for UK 
%             VaR(:,k,n) = tinv(quant(k),nu_vec(n))*sigma(end-TT+1:end,n) + mu(end-TT+1:end,n);
%         else 
            VaR(:,k,n) = skewtdis_inv(quant(k),nu_vec(n),lambda_vec(n))*sigma(1:TT,n) + mu(1:TT,n);
%         end
                
        % Backtesting
        if i==1
            cond = 0;
        elseif i == 2
            cond = 1;
        end
        
        [p_value(k,n),add5(:,k,n)] = Backtesting(cond,returns(3:end,n),VaR(:,k,n),quant(k), 0.05); % umbral para el 5%
        [~,add10(:,k,n)] = Backtesting(cond,returns(3:end,n),VaR(:,k,n),quant(k), 0.1); % umbral para el 10%
        [~,add1(:,k,n)] = Backtesting(cond,returns(3:end,n),VaR(:,k,n),quant(k), 0.01); % umbral para el 1%
        end
    end
    
    percentage_exc(:,n,i) = add10(3,:,n) ./ TT * 100; % Is the same for any alpha
    p_value2(:,:,i) = [p_value(2,:);p_value(5,:);p_value(10,:);p_value(20,:)]; % q = 1, 2.5, 5, 10%
end

pVal_Kupiec(:,:) = p_value2(:,:,1);
pVal_Christoff(:,:) = p_value2(:,:,2);

%% Plot
for n = 1:3
    hFig=figure(n)
    yyaxis left
        hLineL(1)=plot(fliplr(quant),fliplr(add5(1,:,n)),'r.-','LineWidth',1.2) % fliplr es para dar la vuelta al vector
        hold on
        hLineL(2)=plot(fliplr(quant),fliplr(add1(1,:,n)),'r--','LineWidth',1.2)
        hLineL(3)=plot(fliplr(quant),fliplr(add10(1,:,n)),'r:','LineWidth',1.2)
        hLineL(4)=plot(fliplr(quant),fliplr(add5(2,:,n)),'r.-','LineWidth',1.2)
        hLineL(5)=plot(fliplr(quant),fliplr(add1(2,:,n)),'r--','LineWidth',1.2)
        hLineL(6)=plot(fliplr(quant),fliplr(add10(2,:,n)),'r:','LineWidth',1.2)
        hLineL(7)=plot(fliplr(quant),fliplr(add1(3,:,n)),'k','LineWidth',1.2) 
    yyaxis right
        hLineR(1)=plot(fliplr(quant),fliplr(p_value(:,n)'),'b','LineWidth',1.7) 
        hold on
        hLineR(2)=plot([0.01,0.5],[0.1,0.1],'b:')
        hLineR(3)=plot([0.01,0.5],[0.05,0.05],'b:')
        hLineR(4)=plot([0.01,0.5],[0.01,0.01],'b:') 
    ChildFig=get(hFig,'Children')
    set(ChildFig,'YColor',[0 0 1]) % cambiar color ejes
    set(ChildFig,'FontSize',13,'TickLabelInterpreter','LateX') % formato para los numeros igual que latex
    set(get(ChildFig,'YLabel'),'string','p-value Kupiec''s POF test','FontSize',14,'interpreter','latex')
    yyaxis left
    set(ChildFig,'YColor',[1 0 0])
    set(get(ChildFig,'YLabel'),'string','Number of exceedances','FontSize',14,'interpreter','latex')
    h_lengend=legend([hLineL(3),hLineL(1),hLineL(2),hLineL(7),hLineR(1)],...
        'Limit exceedences to fail to refuse $H_0$ at $10\%$',...
        'Limit exceedences to fail to refuse $H_0$ at $5\%$',...
        'Limit exceedences to fail to refuse $H_0$ at $1\%$',...
        'Number of exceedances',...
        'p-value')
    set(h_lengend,'FontSize',14,'interpreter','latex')
    set(get(ChildFig,'XLabel'),'string','Percentile $\alpha$','FontSize',14,'interpreter','latex')
    if n==1
        set(get(ChildFig,'Title'),'string','Kupiec''s POF test for EUR/USD returns','FontSize',15,'interpreter','latex')
    elseif n==2
        set(get(ChildFig,'Title'),'string','Kupiec''s POF test for EUROSTOXX 50 returns','FontSize',15,'interpreter','latex')
    elseif n==3
       set(get(ChildFig,'Title'),'string','Kupiec''s POF test for Gold returns','FontSize',15,'interpreter','latex')
    end
end


%%
%%%%%%%%%%%%%%%%%%%%%%%%%  Christoffersen  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%       test       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for n=1:3
    for k=1:length(quant)
        [p_valChris(k,n),addChris(:,k,n)] = Backtesting(1,returns(3:end,n),VaR(:,k,n),quant(k),0.05);
    end
end

% Plot
for n=1:3
    hFig=figure(n+9)
    yyaxis left
        hLineL(1)=plot(fliplr(quant),fliplr(addChris(1,:,n)),'r.-')
        hold on
        hLineL(2)=plot(fliplr(quant),fliplr(addChris(2,:,n)),'r--')
        hLineL(3)=plot(fliplr(quant),fliplr(addChris(3,:,n)),'k:')
        hLineL(4)=plot(fliplr(quant),fliplr(addChris(4,:,n)),'r.')
    yyaxis right
        hLineR(1)=plot(fliplr(quant),fliplr(p_valChris(:,n)'),'b')
        hold on
        hLineR(2)=plot([0.01,0.5],[0.1,0.1],'b:')
        hLineR(3)=plot([0.01,0.5],[0.05,0.05],'b:')
        hLineR(4)=plot([0.01,0.5],[0.01,0.01],'b:')
    ChildFig=get(hFig,'Children')
    set(ChildFig,'YColor',[0 0 1])
    set(ChildFig,'TickLabelInterpreter','LateX')
    set(get(ChildFig,'YLabel'),'string','p-value Christoffersen''s backtesting test','interpreter','latex')
    yyaxis left
    set(ChildFig,'YColor',[1 0 0])
    set(get(ChildFig,'YLabel'),'string','\# observations','interpreter','latex')
    h_lengend=legend([hLineL(1),hLineL(2),hLineL(3),hLineL(4),hLineR(1)],...
        '\# observation without exceedances at $t$ nor $t-1$',...
        '\# observation with exceedances at $t-1$ but without at $t$',...
        '\# observation with exceedances at $t$ but without at $t-1$',...
        '\# observation with exceedances at $t$ and $t-1$',...
        'p-value')
    set(h_lengend,'interpreter','latex')
    set(get(ChildFig,'XLabel'),'string','Percentile $\alpha$','interpreter','latex')
    if n==1
    set(get(ChildFig,'Title'),'string','Christoffersen''s test for GBP/USD returns','interpreter','latex')
    elseif n==2
        set(get(ChildFig,'Title'),'string','Christoffersen''s test for FTSE100 returns','interpreter','latex')
    elseif n==3
       set(get(ChildFig,'Title'),'string','Christoffersen''s test for Gold returns','interpreter','latex')
    end
end


%%
save('Marginal_Europe2_nuevo')     
