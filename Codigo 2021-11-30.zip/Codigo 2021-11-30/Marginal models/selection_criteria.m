function [Tfx, Tst, Tg] = selection_criteria(aic,bic,LLF_mg)

% Names of all models tested
names_garch = {'GARCH (Normal)            ';
               'GJR (Normal)              ';
               'EWMA (Normal)             ';
               'APARCH (Normal)           ';
               'GARCH-M (Normal)          ';
               'GARCH (Student t)         ';  
               'GJR (Student t)           ';
               'EWMA (Student t)          ';
               'APARCH (Student t)        ';
               'GARCH-M (Student t)       ';
               'GARCH (Skewed Student t)  ';  
               'GJR (Skewed Student t)    ';
               'EWMA (Skewed Student t)   ';
               'APARCH (Skewed Student t) '; 
               'GARCH-M (Skewed Student t)'};

% Table with values of AIC, BIC and max loglikelihood function for FX          
Akaike_FX = vertcat(aic(:,1,1),aic(:,2,1),aic(:,3,1));
Schwartz_FX = vertcat(bic(:,1,1),bic(:,2,1),bic(:,3,1));
Loglikelihood_FX = LLF_mg(:,1);
disp('Information criteria of GARCH models for Exchange rate')
Tfx = table(Akaike_FX,Schwartz_FX,Loglikelihood_FX,'RowNames',names_garch)

% Table with values of AIC, BIC and max loglikelihood function for stock variable         
Akaike_ST = vertcat(aic(:,1,2),aic(:,2,2),aic(:,3,2));
Schwartz_ST = vertcat(bic(:,1,2),bic(:,2,2),bic(:,3,2));
Loglikelihood_ST = LLF_mg(:,2);
disp('Information criteria of GARCH models for Stock index')
Tst = table(Akaike_ST,Schwartz_ST,Loglikelihood_ST,'RowNames',names_garch)

% Table with values of AIC, BIC and max loglikelihood function for gold          
Akaike_GOLD = vertcat(aic(:,1,3),aic(:,2,3),aic(:,3,3));
Schwartz_GOLD = vertcat(bic(:,1,3),bic(:,2,3),bic(:,3,3));
Loglikelihood_GOLD = LLF_mg(:,3);
disp('Information criteria of GARCH models for Gold')
Tg = table(Akaike_GOLD,Schwartz_GOLD,Loglikelihood_GOLD,'RowNames',names_garch)
