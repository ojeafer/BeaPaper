clear all
clc

load('Vines_Japan_nuevo')

%% MESHGRID
% Parameters of the marginal models
params_st2 = [params_st(1:6); 0.0; 2.0; params_st(end-1:end)]; % for Japan
% params_st2 = [params_st(1:7); 2.0; params_st(end-1:end)]; % for Brazil
params_marg = [params_fx,params_st2,params_gold];

% Mean and variance of each marginal distribution
mu = [mu_fx, mu_st, mu_gold];
sigma2 = [sigma2_fx, sigma2_st, sigma2_gold];

% Vine structure
copulatype = optim_model.copula_best;
theta = output_best.theta;

% Simulation of returns
T_sim = min(size(u_fx,1), min(size(u_st,1),size(u_gold,1)));
[R,unif_dep] = SimulGrid_Vines(copulatype,theta,params_marg,mu,sigma2,T_sim);
% [R,unif_dep] = SimulGrid_DCC(dist,dcc,params_marg,mu,sigma2,T_sim); 
    % where dist is equal to 1 (Normal) or 2 (Student), and dcc = [dcc12, dcc13, dcc23]';


%% CONSTRUCTION OF PORTFOLIOS
% For US investors
unif_dep_new = [unif_dep(:,1,:), unif_dep(:,3,:), unif_dep(:,2,:)]; clear unif_dep
unif_dep = unif_dep_new; clear unif_dep_new

R_new = [-R(:,1,:), R(:,3,:), R(:,2,:)]; clear R
R = R_new; clear R_new

%%
% CASE 1: Minimum-ES portfolio without extra-investment in FX
[w_mES2,ES_min] = weights_minES(R,size(R,3),2);

% CASE 2: Minimum-ES portfolio with extra-investment in FX
[w_mES3,ES_min3] = weights_minES(R,size(R,3),3);

  
%%
save('PortfoliosUSD_Japan_nuevo2','datewt2','T2','R','unif_dep',...
     'ES_min','ES_min3','w_mES2','w_mES3', '-v7.3') 
 % * where R = [-r_e, r_g, r_st] for US investors!!!


%% PLOTS
% Case 1: two-assets portfolio
w_es2 = w_mES2(1:2,:); % gold in local currency and stock
createfigure_minES_2w(datewt2, w_es2'*100, abs(ES_min)*100, 1, 'Japan') %abs=1: The ES is expressed in absolute terms

% Case 2: three-assets portfolio
w_es3 = [w_mES3(1,:)-w_mES3(3,:); w_mES3(2,:); w_mES3(3,:)]; % [omega2, (1-omega1-omega2), omega1]
createfigure_minES_3w(datewt2, w_es3'*100, abs(ES_min3)*100, 1, 'Japan')

%% Plots for US-investors portfolios
% Case 1: two-assets portfolio
w_es2_USD = w_mES2(2:3,:); % gold (in USD) and stock in USD
createfigure_minES_2w_US(datewt2, w_es2_USD'*100, abs(ES_min)*100, 1, 'Japan') 

% Case 2: three-assets portfolio
w_es3_USD = [w_mES3(1,:)-w_mES3(3,:); w_mES3(2,:); w_mES3(3,:)];
% For a US investor w_mES3(3,:) is the weight of the stock index in USD,
% w_mES3(2,:) is the weight of the gold and w_mES3(1,:) is the weight of the FX
createfigure_minES_3w_US(datewt2, w_es3_USD'*100, abs(ES_min3)*100, 1, 'Japan')
