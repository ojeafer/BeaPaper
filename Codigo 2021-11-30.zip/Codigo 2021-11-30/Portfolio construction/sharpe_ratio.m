clear all
clc

load('SimulVine_Europe')
%%
[rates,Date2_total] = xlsread('Risk free rates',2,'A12:E5181'); 

% Weekly data
DayNumber = weekday(datestr(Date2_total)); %get the day of the week of each day
% Check that we have weekly data and not biweekly data
vec = DayNumber==6; % vector de fechas que coinciden en viernes
idx = find(vec==1) ;
iwant = diff(idx)-1;
clear iwant idx vec

eur = (1+rates(:,1)/100).^(-1/250);
eur_week = eur(DayNumber==6);
rf_eur = log(eur_week(2:end)./eur_week(1:end-1));

jap = (1+rates(:,2)/100).^(-1/250);
jap_week = jap(DayNumber==6);
rf_jpy = log(jap_week(2:end)./jap_week(1:end-1));

uk = (1+rates(:,3)/100).^(-1/250);
uk_week = uk(DayNumber==6);
rf_gbp = log(uk_week(2:end)./uk_week(1:end-1));

bra = (1+rates(:,4)/100).^(-1/250);
bra_week = bra(DayNumber==6);
rf_brl = log(bra_week(2:end)./bra_week(1:end-1));

%%
% rf_eur = zeros(1,T2);

%%
R = permute(R_sim(2:end,:,:),[2,3,1]);
[w_sharpe2, Sharpe_max2] = weights_maxSR(R,rf_eur,T2,2);
[w_sharpe3, Sharpe_max3] = weights_maxSR(R,rf_eur,T2,3);


%%
figure(1);
haxes = axes();
    hbar = area(datewt2,w_sharpe2(1:2,:)'*100);
    set(hbar(1),'EdgeAlpha',0,'FaceAlpha',0.7)
    set(hbar(2),'EdgeAlpha',0,'FaceAlpha',0.7)
set(haxes,'TickLabelInterpreter','latex')
title('Dynamic weigths of each asset in the maximum-Sharpe ratio portfolio without extra investment in exchange rate','interpreter','latex')
ylabel('Weight ($\%$)','interpreter','latex')
xlabel('Date','interpreter','latex')
set(haxes,'YLim',[0,100],'TickLabelInterpreter','Latex')
grid on
yyaxis right
    hold on
    plot(datewt2,Sharpe_max2,'k','LineWidth',1.2)
    plot(datewt2,zeros(1,length(Sharpe_max2)),'k--')
ylabel('Sharpe ratio','interpreter','latex')
legend('Gold (in euros)','EUROSTOXX','Sharpe ratio of the portfolio','interpreter','latex') 


%%
w_SR3 = [w_sharpe3(1,:)-w_sharpe3(3,:); w_sharpe3(2,:); w_sharpe3(3,:)];
figure(2);
hbar = area(w_SR3'*100);
yyaxis right
hold on
plot(Sharpe_max3,'k','LineWidth',2)
plot(zeros(1,length(Sharpe_max3)),'k:')
hold off
legend('Gold','EUROSTOXX','EUR/USD','Sharpe ratio of the portfolio','interpreter','latex') 


%%
line_gold2 = repmat(50,1,size(w_sharpe2,2));
createfigure_minVar_2w(datewt2, w_sharpe2(1:2,:)'*100, line_gold2, Sharpe_max2, 'UK')


%%
line_gold3 = repmat(1/3*100,1,size(w_sharpe3,2));
w_SR3 = [w_sharpe3(1,:)-w_sharpe3(3,:); w_sharpe3(2,:); w_sharpe3(3,:)];
createfigure_minVar_3w(datewt2, w_SR3'*100, [line_gold3;line_gold3*2], Sharpe_max3, 'UK')

