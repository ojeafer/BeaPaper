function [w_sharpe, Sharpe_max] = weights_maxSR(R,Rf,T,N)
%% Calculate the weights of three assets in a max-Sharpe ratio portfolio
%   a) N==2: when w1=w3, w2=1-w1
%   b) N==3: when w3=1-w1-w2
%
%% SYNTAX: 
%   [w_sharpe, Sharpe_max] = weights_maxSR(R,T,N)
%
%% INPUTS:
%       R: matrix MxNxT of simulated returns
%           *M is the number of paths 
%       Rf: risk free rate returns
%       T: length of each path
%       N: number of assets with different weights
%
%% OUTPUTS:
%       w_sharpe: matrix NxT with the weights of each asset in the max-SR portfolio
%       Sharpe_max: maximum value of the Sharpe ratio obtained with weights in w_sharpe
%
%%
tic
if N==2
    M = 102; % Number of possible combinations of weights
    for w = 1:M
        vec_w(:,w) = [(w-1)/101; 1-(w-1)/101; (w-1)/101];
    end
    
elseif N==3
    [A,B] = meshgrid([0:0.01:1],[0:0.01:1]);
    w_grid = [A(:),B(:)];
    W = w_grid(sum(w_grid,2)<=1,:);
    WW = [1-sum(W,2),W];
    vec_w = WW + [WW(:,3),zeros(size(WW,1),2)]; % [fx st g]
    vec_w = vec_w';
    
    M = size(WW,1); % Number of possible combinations of weights
end

%%
h=52; % weeks per year
for t = 1:T  
    t
    R_Weighted = R(:,:,t) * vec_w;
    Mu(:,t) = mean(R_Weighted,2) * h; % Annualized mean
    Sigma2(:,t) = var(R_Weighted'); % Variance
    Var(:,t) = Sigma2(:,t) * h; % Annualized volatility

    % Sharpe ratio
    Sharpe(:,t) = (Mu(:,t) - Rf(t)) ./ sqrt(Var(:,t));

    % Maximum-SR portfolio
    pos_sr(t) = find(max(Sharpe(:,t))==Sharpe(:,t));
    Sharpe_max(t) = Sharpe(pos_sr(t),t);
    w_sharpe(:,t) = vec_w(:,pos_sr(t));
end
toc

end
