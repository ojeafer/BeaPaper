function [w_mES,ES_min] = weights_minES(R,T,N)
%% Calculate the weights of three assets in a min-ES portfolio
%   a) N==2: when w1=w3, w2=1-w1
%   b) N==3: when w3=1-w1-w2
%
%% SYNTAX: 
%   [w_mES2,ES_min] = weights_minVar_minES(R,T,N)
%
%% INPUTS:
%       R: matrix MxNxT of simulated returns.
%           M is the number of paths of simulations 
%       T: length of each path
%       N: number of assets with different weights
%
%% OUTPUTS:
%       w_mES: matrix 2xT with the weights of each asset in t in the min-ES portfolio
%       ES_min: minimum ES obtained with weights in w_mES
%
%%
tic
if N==2
    M = 102; % Number of possible combinations of weights
    for w = 1:M
        vec_w(:,w) = [(w-1)/101; 1-(w-1)/101; (w-1)/101];
    end
    
elseif N==3
    [A,B] = meshgrid([0:0.01:1],[0:0.01:1]);
    w_grid = [A(:),B(:)];
    W = w_grid(sum(w_grid,2)<=1,:);
    WW = [1-sum(W,2),W]; % [fx st ge]
    vec_w = WW + [WW(:,3),zeros(size(WW,1),2)]; % [fx st g]
    vec_w = vec_w';
    
    M = size(WW,1); % Number of possible combinations of weights
end


for t = 1:T  
    R_Weighted = R(:,:,t) * vec_w;
        
    for w = 1:M
        ES(w,t) = mean(R_Weighted(R_Weighted(:,w) < prctile(R_Weighted(:,w),10), w));
        sprintf('%.4f %%',(w+M*(t-1))/(M*T)*100)
    end
    
    % Minimum-Expected Shortfall portfolio
    if isnan(ES(:,t))
        pos_es(t) =  pos_es(t-1);
    else
        pos_es(t) = find(max(ES(:,t))==ES(:,t));
    end
    ES_min(t) = ES(pos_es(t),t);    
    w_mES(:,t) = vec_w(:,pos_es(t));
end
toc
