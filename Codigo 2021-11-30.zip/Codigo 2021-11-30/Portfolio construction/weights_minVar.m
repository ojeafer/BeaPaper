function [w_mv,Sigma2_min] = weights_minVar(R,T,N)
%% Calculate the weights of three assets in a min-variance portfolio
%   a) N==2: when w1=w3, w2=1-w1
%   b) N==3: when w3=1-w1-w2
%
%% SYNTAX: 
%   [w_mv2,Sigma2_min] = weights_minVar(R,T,N)
%
%% INPUTS:
%       R: matrix MxNxT of simulated returns.
%           M is the number of paths of simulations 
%       T: length of each path
%       N: number of assets with different weights
%
%% OUTPUTS:
%       w_mv: matrix NxT with the weights of each asset in t in the min-var portfolio
%       Sigma2_min: minimum variance obtained with weights in w_mv
%
%%
tic
if N==2
    M = 102; % Number of possible combinations of weights
    for w = 1:M
        vec_w(:,w) = [(w-1)/101; 1-(w-1)/101; (w-1)/101];
    end
    
elseif N==3
    [A,B] = meshgrid([0:0.01:1],[0:0.01:1]);
    w_grid = [A(:),B(:)];
    W = w_grid(sum(w_grid,2)<=1,:);
    WW = [1-sum(W,2),W];
    vec_w = WW + [WW(:,3),zeros(size(WW,1),2)]; % [fx st g]
    vec_w = vec_w';
    
    M = size(WW,1); % Number of possible combinations of weights
end


for t = 1:T  
    t
    R_Weighted = R(:,:,t) * vec_w;
    Sigma2(:,t) = var(R_Weighted);
    
    % Minimum-variance portfolio
    pos_var(t) = find(min(Sigma2(:,t))==Sigma2(:,t));
    Sigma2_min(t) = Sigma2(pos_var(t), t);
    w_mv(:,t) = vec_w(:,pos_var(t));

    sprintf('%.4f %%',(t/T*100)
end
toc


