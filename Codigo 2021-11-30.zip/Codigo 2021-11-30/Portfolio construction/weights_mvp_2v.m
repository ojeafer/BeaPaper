function weights_mvp = weights_mvp_2v(sigma2,corr)
%% Function to calculate the optimal weigths of a minimum-variance portfolio
% composed by two assets (assuming Normality for the marginal distributions)
%
%% SYNTAX: weights_mvp = weights_mpv_2v(sigma2,corr)
%
%% INPUTS:
%       sigma2: matrix Tx2 with the dynamic variance of the assets (for each t)
%       corr: matrix Tx2 with the dynamic correlation between the variables (given by DCC-GARCH model)
%
%% OUTPUTS:
%       weights_mpv: matrix with the optimal weigths of each asset for all the sample
%
%%
var1 = sigma2(:,1);
var2 = sigma2(:,2);

T = length(corr);

% Minimum-variance portfolio (assuming Normality)
omega2 = NaN(1,T);
for t = 1:T     
    omega2(t) = (var2(t) - sqrt(var2(t))*sqrt(var1(t))*corr(t)) / ...
             (var1(t) + var2(t) - 2*sqrt(var2(t))*sqrt(var1(t))*corr(t)); % weight for stock            
end

omega = 1 - omega2; % weight for gold and FX 

weights_mvp = [omega; omega2];

end