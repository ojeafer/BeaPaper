function [weights_mvp, mu_mvp, std_mvp] = weights_mvp_3v(mu,sigma2,corr)
%% Function to calculate the optimal weigths of a minimum-variance portfolio
% composed by three assets
%
%% SYNTAX: [weights_mvp, mu_mvp, std_mvp] = weights_mpv_3v(mu,sigma2,corr)
%
%% INPUTS:
%       mu: matrix Tx3 with the dynamic mean of the assets (for each t)
%       sigma2: matrix Tx3 with the dynamic variance of the assets (for each t)
%       corr: matrix Tx3 with the dynamic correlation between the variables (given by DCC-GARCH model)
%
%% OUTPUTS:
%       weights_mvp: matrix with the optimal weigths of each asset for all the sample
%       mu_mpv: dynamic mean of the minimum-variance portfolio
%       std_mpv: dynamic standard deviation of the minimum-variance portfolio
%
%%
mu1 = mu(:,1);
mu2 = mu(:,2);
mu3 = mu(:,3);

var1 = sigma2(:,1);
var2 = sigma2(:,2);
var3 = sigma2(:,3);

dcc12 = corr(:,1);
dcc13 = corr(:,2);
dcc23 = corr(:,3);

T = length(dcc12);
N = size(mu,2);

for t = 1:T
    muR = [mu1(t); mu2(t); mu3(t)]; % Mean vector of order Nx1
    sigR = [sqrt(var1(t)); sqrt(var2(t)); sqrt(var3(t))]; % Std vector of order Nx1
    corre = [   1      dcc12(t)  dcc13(t);
             dcc12(t)     1      dcc23(t);
             dcc13(t)  dcc23(t)     1    ]; % Correlation matrix 
    covR = diag(sigR) * corre * diag(sigR); % Covariance matrix
    invcov = inv(covR);

    l = ones(N,1);
    m1 = invcov * l;    %vector of order nx1
    m2 = invcov * muR;  %vector of order nx1

    A = l' * m2;        %real number
    B = muR' * m2;      %real number (positive)
    C = l' * m1;        %real number (positive)
    D = B*C - A^2;      %real number (positive)

    g = (1/D) * (B*m1-A*m2);  %vector of order nx1
    h = (1/D) * (C*m2-A*m1);  %vector of order nx1

    
    % Minimum-variance portfolio
    weights_mvp(:,t) = (1/C) * m1; % Weights of the mvp
    mu_mvp(t) = A/C; % Mean of the mvp
    std_mvp(t) = sqrt(1/C); % Standard deviation of the mvp
end


end