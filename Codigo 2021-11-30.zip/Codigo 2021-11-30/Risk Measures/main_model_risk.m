clear
clc
load('RiskMeasures_Gaussian_Japan2')

%% Risk measures assuming no-tail dependence
% We only need min-ES portfolios without and with extra-investment in FX
ES_DCC = [ES_p(:,1),ES_p(:,2)];
ES_up_DCC = [ES_p_up(:,1),ES_p_up(:,2)];
VaR_DCC = [VaR_p(:,1),VaR_p(:,2)];
VaR_up_DCC = [VaR_p_up(:,1),VaR_p_up(:,2)];

CoVaRs_DCC(:,:) = CoVaR1(:,2,1:2);
CoVaRs_up_DCC(:,:) = CoVaR1_up(:,2,1:2);
CoESs_DCC(:,:) = CoES1(:,2,1:2);
CoESs_up_DCC(:,:) = CoES1_up(:,2,1:2);


%%
save('ModelRisk_Brazil_nuevo','ES_DCC','ES_up_DCC','VaR_DCC','VaR_up_DCC',...
     'CoVaRs_DCC','CoVaRs_up_DCC','CoESs_DCC','CoESs_up_DCC')

%%
clear
load('RiskMeasures_Vine_Japan_nuevo')
load('ModelRisk_Japan_nuevo')

%% Risk measures assuming asymmetric tail dependence
ES_vines = ES_p(:,1:2);
ES_up_vines = ES_p_up(:,1:2);
VaR_vines = VaR_p(:,1:2);
VaR_up_vines = VaR_p_up(:,1:2);

CoVaRs_vines(:,:) = CoVaR1(:,2,1:2);
CoVaRs_up_vines(:,:) = CoVaR1_up(:,2,1:2);
CoESs_vines(:,:) = CoES1(:,2,1:2);
CoESs_up_vines(:,:) = CoES1_up(:,2,1:2);

%% Model risk
model_risk(:,:) = ES_vines - ES_DCC;
model_risk_up(:,:) = ES_up_vines - ES_up_DCC;

model_risk_s(:,:) = CoESs_vines - CoESs_DCC;
model_risk_s_up(:,:) = CoESs_up_vines - CoESs_up_DCC;

%%
save('ModelRisk_Japan','ES_DCC','ES_up_DCC','VaR_DCC','VaR_up_DCC',...
     'CoESs_DCC','CoESs_up_DCC','CoESs_vines','CoESs_up_vines',...
     'ES_vines','ES_up_vines','VaR_vines','VaR_up_vines','datewt2','T2',...
     'CoVaRs_DCC','CoVaRs_up_DCC','CoVaRs_vines','CoVaRs_up_vines',...
     'model_risk','model_risk_up','model_risk_s','model_risk_s_up')

%% Plots
createfigure_model_risk_uni(datewt2,[model_risk(:,1),model_risk(:,2)]*100,'ES','bearish')
createfigure_model_risk_uni(datewt2,[model_risk_s(:,1),model_risk_s(:,2)]*100,'CoES','bearish')
