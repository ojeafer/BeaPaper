clear all
clc

load('PortfoliosUSD_Japan')

%%
alpha = 0.10; beta = alpha;

dif_portfolios(:,:,1) = w_mES2; % min-ES portfolio without extra-investment in FX
dif_portfolios(:,:,2) = w_mES3; % min-ES portfolio with extra-investment in FX
dif_portfolios(:,:,3) = repmat([1,0,1],size(w_mES2,2),1)'; % stock portfolio
    % the first position is omega1+omega2=1+0=1 for the FX
    % dif_portfolios = NxTxN_p (N_p = Number of portfolios)
N = size(dif_portfolios,1); % Number of assets


%%
R2 = [R(:,1,:), R(:,2,:), R(:,3,:)+R(:,1,:)]; 
    % R = [-r_e, r_g, r_st] -> R2 = [r_e*, r_g, r_se*]
    % where r_e*=-r_e and r_se*=r_s+(-r_e)=r_s-r_e

tic
for i = 1:size(dif_portfolios,3)
    W = [dif_portfolios(1,:,i)-dif_portfolios(3,:,i); ... % extra-weight in FX
         dif_portfolios(2,:,i); ... % weight of gold
         dif_portfolios(3,:,i)]; % weight of stock in USD
    for t = 1:size(W,2)
        R_w(:,t) = R2(:,:,t) * W(:,t); % Matrix of weighted returns
    end

%     for t = 1:size(W,2)
%         %% Unconditional risk
%         % VaR & ES 
%         VaR_p(t,i) = prctile(R_w(:,t),beta*100);
%         ES_p(t,i) = mean(R_w(R_w(:,t)<VaR_p(t,i),t));
%         VaR_p_up(t,i) = prctile(R_w(:,t),(1-beta)*100);
%         ES_p_up(t,i) = mean(R_w(R_w(:,t)>VaR_p_up(t,i),t));
%         
%         % MES
%         MES(:,t,i) = mean(R2(R_w(:,t)<VaR_p(t,i),:,t));
%         Contribution_ES(:,t,i) = W(:,t).*MES(:,t,i);
%         
%         
%         %% Risk conditional on one variable scenario
%         for n = 1:N
%             % P(R_p < CoVaR(beta) | R_1 < VaR(alpha)) 
%             R_1(:,t) = R_w(unif_dep(:,n,t)<alpha, t); 
%             CoVaR1(t,n,i) = prctile(R_1(:,t),beta*100);
%             CoES1(t,n,i) = mean(R_w(R_w(:,t)<=CoVaR1(t,n,i), t));
% 
%             % DeltaCoVaR = CoVaR(beta) - CoVaR(0.5)
%             CoVaR1_med(t,i) = prctile(R_1(:,t),50);
%             DeltaCoVaR1(t,n,i) = CoVaR1(t,n,i) - CoVaR1_med(t,i);
% 
%             % P(R_p < CoVaR(beta) | R_1 > VaR(1-alpha)) 
%             R_1_up(:,t) = R_w(unif_dep(:,n,t)>(1-alpha),t);
%             CoVaR1_up(t,n,i) = prctile(R_1_up(:,t),beta*100);
%             CoES1_up(t,n,i) = mean(R_w(R_w(:,t)<CoVaR1_up(t,n,i), t));
%             CoVaR1_med_up(t,i) = prctile(R_1_up(:,t),50);
%             DeltaCoVaR1_up(t,n,i) = CoVaR1_up(t,n,i) - CoVaR1_med_up(t,i);
%             
%             clear R_1 R_1_up
%         end        
%     end
%     
    
%     %% Risk conditional on a spillover in the stock market
%     % P(r_p<CoVaR | r_s<VaR)
%     CoVaRs(:,i) = CoVaR1(:,3,i);
%     CoVaRs_up(:,i) = CoVaR1_up(:,3,i);
% 
%     % CoES
%     CoESs(:,i) = CoES1(:,3,i);
% 
%     % DeltaCoVaR
%     DeltaCoVaRs(:,i) = DeltaCoVaR1(:,3,i);
%     DeltaCoVaRs_up(:,i) = DeltaCoVaR1_up(:,3,i);    

    for t = 1:size(W,2)          
        % DeltaCoES
        DeltaCoESs(t,i) = mean(R_w(R_w(:,t)<DeltaCoVaRs(t,i),t));
        DeltaCoESs_up(t,i) = mean(R_w(R_w(:,t)>DeltaCoVaRs_up(t,i),t));
    end       
%         % MES
%         MES_s(:,t,i) = mean(R2(R_w(:,t)<CoVaRs(t,i),:,t));
%         Contribution_ESs(:,t,i) = W(:,t).*MES_s(:,t,i);
%         
%         % Results for FX and gold
%         E_re_s(t,i) = mean(R2(unif_dep(:,3,t)<alpha,1,t)); 
%         E_rs_s(t,i) = mean(R2(unif_dep(:,3,t)<alpha,3,t)); 
%         E_rg_s(t,i) = mean(R2(unif_dep(:,3,t)<alpha,2,t)); 
%         
%         % Expected return of the portfolio
%         E_rp_s(t,i) = [E_re_s(t,i),E_rg_s(t,i),E_rs_s(t,i)] * W(:,t);        
%         
%         
%         %% Risk conditional on the situation of FX and gold
%         sit_CoVaR2 = (unif_dep(:,1,t)<alpha) & (unif_dep(:,2,t)<alpha); 
%         sit_CoVaR2_up = (unif_dep(:,1,t)>(1-alpha)) & (unif_dep(:,2,t)>(1-alpha));
%         
%         R_2 = R_w(sit_CoVaR2, t);
%         CoVaR2(t,i) = prctile(R_2,beta*100);
%         CoES2(t,i) = mean(R_w(R_w<CoVaR2(t,i)));
%         CoVaR2_med(t,i) = prctile(R_2,50);
%         DeltaCoVaR2(t,i) = CoVaR2(t,i) - CoVaR2_med(t,i);
% 
%         R_2_up = R_w(sit_CoVaR2_up,t);
%         CoVaR2_up(t,i) = prctile(R_2_up,beta*100);
%         CoES2_up(t,i) = mean(R_w(R_w<CoVaR2_up(t,i)));
%         CoVaR2_up_med(t,i) = prctile(R_2_up,50);
%         DeltaCoVaR2_up(t,i) = CoVaR2_up(t,i) - CoVaR2_up_med(t,i);
%         
%         clear R_2 R_2_up
%     end
end
toc

%%
DeltaCoESsn = CoESs;
if isnan(CoESs(1,:))
    DeltaCoESsn(1,:) = 0;
end
for t = 2:size(w_mES2,2)
    for i = 1:3
        if isnan(CoESs(t,i))
            DeltaCoESsn(t,i) = DeltaCoESsn(t-1,i);
        else
            DeltaCoESsn(t,i) = DeltaCoESsn(t,i);
        end
    end
end

%
tableM(1,:) = mean(ES_p,1);
tableM(2,:) = mean(DeltaCoVaRs);
tableM(3,:) = mean(DeltaCoESsn,1);
tableM(4,:) = mean(E_rp_s);
tableM

tableR(1,:) = mean(E_re_s);
tableR(2,:) = mean(E_rs_s);
tableR(3,:) = mean(E_rg_s);
% tableR


%%
clear DeltaCoESsn W R_w i t n ans
save('RiskMeasures_USD_UK', '-v7.3')


%% Plots -> script plot_risk_measures_US.m
