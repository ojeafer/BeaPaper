%% Plot risk meausres
clear all
clc

load('RiskMeasures_Vine_UK')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot MES
N = 2;
if N == 1 
    Contrib = Contribution_ES;
    risk = ES_p;
    measure = {'MES'};
elseif N == 2 
    Contrib = Contribution_ESs;
    risk(:,:) = CoESs;
    measure = {'MCoES'};
end

%
MES_fx_mES2 = Contrib(1,:,1); % Contribution of FX to the ES of the minimum-ES portfolio without extra investment in FX
MES_fx_mES3 = Contrib(1,:,2); % Contribution of FX to the ES of the minimum-ES portfolio with extra investment in FX
MES_st_mES2 = Contrib(2,:,1); % Contribution of stock to the ES of the minimum-ES portfolio without extra investment in FX
MES_st_mES3 = Contrib(2,:,2); % Contribution of stock to the ES of the minimum-ES portfolio with extra investment in FX
MES_g_mES2 = Contrib(3,:,1); % Contribution of gold to the ES of the minimum-ES portfolio without extra investment in FX
MES_g_mES3 = Contrib(3,:,2); % Contribution of gold to the ES of the minimum-ES portfolio with extra investment in FX

% Two weights
MES = [MES_st_mES2; MES_g_mES2];
pesosPos = MES;
pesosNeg = MES;
pesosPos(pesosPos<0) = 0;
pesosNeg(pesosNeg>0) = 0;
createfigure_MES(datewt2, [pesosPos', pesosNeg']*100, risk(:,1)*100, 2, measure)

% Three weights
MES3 = [MES_fx_mES3; MES_st_mES3; MES_g_mES3];
pesosPos3 = MES3;
pesosNeg3 = MES3;
pesosPos3(pesosPos3<0) = 0;
pesosNeg3(pesosNeg3>0) = 0;
createfigure_MES(datewt2, [pesosPos3', pesosNeg3']*100, risk(:,2)*100, 3, measure)


%% Plot VaR, ES and CoVaR
matrix1 = [VaR_p(:,1)*100, ...
          (CoVaR1(:,1,1)+CoVaR1(:,3,1))*100, CoVaR1(:,2,1)*100];
matrix1b = [VaR_p_up(:,1)*100, ...
          (CoVaR1_up(:,1,1)+CoVaR1_up(:,3,1))*100, CoVaR1_up(:,2,1)*100];
matrix2 = [VaR_p(:,2)*100, ...
          CoVaR1(:,1,2)*100, CoVaR1(:,2,2)*100, CoVaR1(:,3,2)*100];
matrix2b = [VaR_p_up(:,2)*100, ...
          CoVaR1_up(:,1,2)*100, CoVaR1_up(:,2,2)*100, CoVaR1_up(:,3,2)*100];
      
createfigure_CoVaR(datewt2, matrix1, matrix2,'bearish')
% createfigure_CoVaR(datewt2, matrix1b, matrix2b,'bullish')


%% Spillover in stock market
%% a) Tail risk
createfigure_CoES1(datewt2,[CoESs(:,1),ES_p(:,1)]*100,...
                   [CoESs(:,2),ES_p(:,2)]*100,'nonUS')
               
%% b) Expected returns of each asset 
createfigure_spillover_stock(datewt2,...
                            [(E_re_s(:,1)+E_rg_s(:,1)),E_rs_s(:,1)]*100,...
                            [E_rs_s(:,2),E_rg_s(:,2),E_re_s(:,2)]*100)

%% c) Expected return of the portfolio
createfigure_E_rp(datewt2,E_rp_s*100)

%% d) Comparison of CoES
CoES_e1(:,:) = CoES1(:,1,1);
CoES_e2(:,:) = CoES1(:,1,2);
CoES_s1(:,:) = CoES1(:,2,1);
CoES_s2(:,:) = CoES1(:,2,2);
CoES_s3(:,:) = CoES1(:,2,3);
CoES_g1(:,:) = CoES1(:,3,1);
CoES_g2(:,:) = CoES1(:,3,2);

createfigure_CoES_multi(datewt2,[(CoES_e1+CoES_g1),CoES_s1,CoES_s3]*100,...
                        [CoES_s2,CoES_g2,CoES_e2,CoES_s3]*100)
