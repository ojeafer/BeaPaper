%% Plot risk meausres
clear all
clc

load('RiskMeasures_USD_Europe')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot MES
N = 2;
if N == 1 
    Contrib = Contribution_ES;
    risk = ES_p;
    measure = {'MES'};
elseif N == 2 
    Contrib = Contribution_ESs;
    risk(:,:) = CoESs;
    measure = {'MCoES'};
end

%
MES_fx_mES2 = Contrib(1,:,1); % Contribution of FX to the ES of the minimum-ES portfolio without extra investment in FX
MES_fx_mES3 = Contrib(1,:,2); % Contribution of FX to the ES of the minimum-ES portfolio with extra investment in FX
MES_g_mES2 = Contrib(2,:,1); % Contribution of stock to the ES of the minimum-ES portfolio without extra investment in FX
MES_g_mES3 = Contrib(2,:,2); % Contribution of stock to the ES of the minimum-ES portfolio with extra investment in FX
MES_st_mES2 = Contrib(3,:,1); % Contribution of gold to the ES of the minimum-ES portfolio without extra investment in FX
MES_st_mES3 = Contrib(3,:,2); % Contribution of gold to the ES of the minimum-ES portfolio with extra investment in FX

% Two weights
MES = [MES_g_mES2; MES_st_mES2];
pesosPos = MES;
pesosNeg = MES;
pesosPos(pesosPos<0) = 0;
pesosNeg(pesosNeg>0) = 0;
createfigure_MES_US(datewt2, [pesosPos', pesosNeg']*100, risk(:,1)*100, 2, measure)

% Three weights
MES3 = [MES_fx_mES3; MES_g_mES3; MES_st_mES3];
pesosPos3 = MES3;
pesosNeg3 = MES3;
pesosPos3(pesosPos3<0) = 0;
pesosNeg3(pesosNeg3>0) = 0;
createfigure_MES_US(datewt2, [pesosPos3', pesosNeg3']*100, risk(:,2)*100, 3, measure)


%% Plot VaR, ES and CoVaR
matrix1 = [VaR_p(:,1)*100, ...
          (CoVaR1(:,1,1)+CoVaR1(:,3,1))*100, CoVaR1(:,2,1)*100];
matrix2 = [VaR_p(:,2)*100, ...
          CoVaR1(:,1,2)*100, CoVaR1(:,3,2)*100, CoVaR1(:,2,2)*100];
      
createfigure_CoVaR_US(datewt2, matrix1, matrix2,'bearish')


%% Spillover in stock market
%% a) Tail risk
createfigure_CoES1(datewt2,[CoESs(:,1),ES_p(:,1)]*100,...
                   [CoESs(:,2),ES_p(:,2)]*100,'US')
               
%% b) Expected returns of each asset 
createfigure_spillover_stock_US(datewt2,...
                               [E_rg_s(:,1),E_rs_s(:,1)+E_re_s(:,1)]*100,...
                               [E_rs_s(:,2),E_rg_s(:,2),E_re_s(:,2)]*100)

%% c) Comparison of CoES
CoES_e1(:,:) = CoES1(:,1,1);
CoES_e2(:,:) = CoES1(:,1,2);
CoES_s1(:,:) = CoES1(:,2,1);
CoES_s2(:,:) = CoES1(:,2,2);
CoES_s3(:,:) = CoES1(:,2,3);
CoES_g1(:,:) = CoES1(:,3,1);
CoES_g2(:,:) = CoES1(:,3,2);

createfigure_CoES_multi_US(datewt2,[CoES_g1,(CoES_e1+CoES_s1),CoES_s3]*100,...
                          [CoES_s2,CoES_g2,CoES_e2,CoES_s3]*100)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Comparison between US and non-US portfolios
ES_p_USD = ES_p;
CoESs_USD = CoESs;
E_rp_s_USD = E_rp_s;

load('RiskMeasures_Vine_UK')

%%
% Inmunizacion carteras
inmun_nonUS2 = ES_p_USD(:,1) - CoESs_USD(:,1);
inmun_nonUS3 = ES_p_USD(:,2) - CoESs_USD(:,2);
inmun_US2 = ES_p(:,1) - CoESs(:,1);
inmun_US3 = ES_p(:,2) - CoESs(:,2);

createfigure_immunisation(datewt2, [inmun_nonUS2,inmun_US2]*100, [inmun_nonUS3,inmun_US3]*100)

%%
% Portfolio expected returns
E_rp_matrix = [E_rp_s,E_rp_s_USD(:,1:2)];

createfigure_E_rp2(datewt2,E_rp_matrix*100)

%
E_rp_matrix2 = [E_rp_s,E_rp_s_USD];
figure(3); 
haxes = axes();
plot(datewt2,E_rp_matrix2*100,'Linewidth',1.7)
set(haxes,'FontSize',16,'TickLabelInterpreter','latex')
grid on
grid minor 
legend('Non-US two-assets portfolio','Non-US three-assets portfolio','Non-US stock portfolio',...
       'US two-assets portfolio','US three-assets portfolio','US stock portfolio',...
       'FontSize',18,'interpreter','latex')
xlabel('Date','FontSize',18,'interpreter','latex')
ylabel('Returns ($\%$)','FontSize',18,'interpreter','latex')
title('Expected returns of non-US and US investors'' in a spillover event in the stock market',...
      'FontSize',24,'interpreter','latex')

