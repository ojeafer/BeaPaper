%% Scenario analysis
clear all
clc

load('Scenarios_Brazil')

%%
T2 = length(dcc12);
alpha = 0.1;
beta = alpha;
gamma = alpha;

%%
for i = 1:T2
    %% Pair of assets in the same situation
    C_fx_st(i) = mvncdf([norminv(alpha,0,1),norminv(beta,0,1)],...
                    [0,0], [1, dcc12(i); dcc12(i), 1]); % C(u_e,u_s) = C(alpha,beta)
    C_fx_gold(i) = mvncdf([norminv(alpha,0,1),norminv(gamma,0,1)],...
                      [0,0], [1, dcc13(i); dcc13(i), 1]); % C(u_e,u_g) = C(alpha,gamma)
    C_st_gold(i) = mvncdf([norminv(beta,0,1),norminv(gamma,0,1)],...
                      [0,0], [1, dcc23(i); dcc23(i), 1]); % C(u_s,u_g) = C(beta,gamma)
                
    %% Rotated copulas
    %C90(u1,u2) = u2 - C(1-u1,u2)
    C90_fx_st(i) = beta - mvncdf([norminv(1-alpha,0,1),norminv(beta,0,1)],...
                                   [0,0], [1, dcc12(i); dcc12(i), 1]); 
    C90_fx_gold(i) = gamma - mvncdf([norminv(1-alpha,0,1),norminv(gamma,0,1)],...
                                     [0,0], [1, dcc13(i); dcc13(i), 1]); 
    C90_st_gold(i) = gamma - mvncdf([norminv(1-beta,0,1),norminv(gamma,0,1)],...
                                     [0,0], [1, dcc23(i); dcc23(i), 1]); 
    %C180(u1,u2) = u2 + u1 - 1 + C(1-u1,1-u2)
    C180_fx_st(i) = beta + alpha - 1 + ...
        mvncdf([norminv(1-alpha,0,1),norminv(1-beta,0,1)],[0,0], [1, dcc12(i); dcc12(i), 1]); 
    C180_fx_gold(i) = gamma + alpha - 1 + ...
        mvncdf([norminv(1-alpha,0,1),norminv(1-gamma,0,1)],[0,0], [1, dcc13(i); dcc13(i), 1]); 
    C180_st_gold(i) = gamma + beta - 1 + ...
        mvncdf([norminv(1-beta,0,1),norminv(1-gamma,0,1)],[0,0], [1, dcc23(i); dcc23(i), 1]); 
    % C270(u1,u2) = u1 - C(u1,1-u2)
    C270_fx_st(i) = alpha - mvncdf([norminv(alpha,0,1),norminv(1-beta,0,1)],...
                                   [0,0], [1, dcc12(i); dcc12(i), 1]); 
    C270_fx_gold(i) = alpha - mvncdf([norminv(alpha,0,1),norminv(1-gamma,0,1)],...
                                     [0,0], [1, dcc13(i); dcc13(i), 1]); 
    C270_st_gold(i) = beta - mvncdf([norminv(beta,0,1),norminv(1-gamma,0,1)],...
                                     [0,0], [1, dcc23(i); dcc23(i), 1]); 

end


%% Scenarios for the three assets
for i = 1:T2
% A) Stock and gold move in the same direction
% P(FX>x, ST>y, G>z) (best scenario)
P_s1(i) = alpha + beta + gamma - 2 + ...
    mvncdf([norminv(1-alpha,0,1),norminv(1-beta,0,1)],[0,0], [1, dcc12(i); dcc12(i), 1]) + ...
    mvncdf([norminv(1-alpha,0,1),norminv(1-gamma,0,1)],[0,0], [1, dcc13(i); dcc13(i), 1]) + ...
    mvncdf([norminv(1-beta,0,1),norminv(1-gamma,0,1)],[0,0], [1, dcc23(i); dcc23(i), 1]) - ...
    mvncdf([norminv(1-alpha,0,1),norminv(1-beta,0,1),norminv(1-gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

% P(FX<x, ST>y, G>z)
P_s2(i) = alpha - ...
    mvncdf([norminv(alpha,0,1),norminv(1-beta,0,1)],[0,0], [1, dcc12(i); dcc12(i), 1]) - ...
    mvncdf([norminv(alpha,0,1),norminv(1-gamma,0,1)],[0,0], [1, dcc13(i); dcc13(i), 1]) + ...
    mvncdf([norminv(alpha,0,1),norminv(1-beta,0,1),norminv(1-gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

% P(FX>x, ST<y, G<z)       
P_s3(i) = mvncdf([norminv(beta,0,1),norminv(gamma,0,1)],[0,0], [1, dcc23(i); dcc23(i), 1]) - ...
    mvncdf([norminv(1-alpha,0,1),norminv(beta,0,1),norminv(gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

% P(FX<x, ST<y, G<z) (worst scenario)                
P_s4(i) = mvncdf([norminv(alpha,0,1),norminv(beta,0,1),norminv(gamma,0,1)],...
    [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);
                

% B) Stock and gold move in opposit direction
% P(FX>x, ST>y, G<z)
P_s5(i) = gamma - ...
    mvncdf([norminv(1-alpha,0,1),norminv(gamma,0,1)],[0,0], [1, dcc13(i); dcc13(i), 1]) - ...
    mvncdf([norminv(1-beta,0,1),norminv(gamma,0,1)],[0,0], [1, dcc23(i); dcc23(i), 1]) + ...
    mvncdf([norminv(1-alpha,0,1),norminv(1-beta,0,1),norminv(gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

% P(FX<x, ST>y, G<z)
P_s6(i) = mvncdf([norminv(alpha,0,1),norminv(gamma,0,1)],[0,0], [1, dcc13(i); dcc13(i), 1]) - ...
    mvncdf([norminv(alpha,0,1),norminv(1-beta,0,1),norminv(gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

% P(FX>x, ST<y, G>z)
P_s7(i) = beta - ...
    mvncdf([norminv(1-alpha,0,1),norminv(beta,0,1)],[0,0], [1, dcc12(i); dcc12(i), 1]) - ...
    mvncdf([norminv(beta,0,1),norminv(1-gamma,0,1)],[0,0], [1, dcc23(i); dcc23(i), 1]) + ...
    mvncdf([norminv(1-alpha,0,1),norminv(beta,0,1),norminv(1-gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

% P(FX<x, ST<y, G>z)
P_s8(i) = mvncdf([norminv(alpha,0,1),norminv(beta,0,1)],[0,0], [1, dcc12(i); dcc12(i), 1]) - ...
    mvncdf([norminv(alpha,0,1),norminv(beta,0,1),norminv(1-gamma,0,1)],...
           [0,0,0], [1, dcc12(i), dcc13(i); dcc12(i), 1, dcc23(i); dcc13(i), dcc23(i), 1]);

end

%%
save('Scenarios_UK')

%% Plots
% datewt2 = datewt2(2:end);

%%
figure(1)
haxes = axes();
    plot(datewt2,P_s1'*100,'LineWidth',1.7)
    hold on
    plot(datewt2,P_s2'*100,'LineWidth',1.7)
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('The price of stock and gold increase','FontSize',15,'interpreter','latex')
legend('Scenario 1: GBP is depreciated','Scenario 2: GBP is appreciated','FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')
% GBP/USD increases = GBP is depreciated (and viceversa)

figure(2)
haxes = axes();
    plot(datewt2,P_s3'*100,'LineWidth',1.7)
    hold on
    plot(datewt2,P_s4'*100,'LineWidth',1.7)
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('The price of stock and gold decrease','FontSize',15,'interpreter','latex')
legend('Scenario 3: GBP is depreciated','Scenario 4: GBP is appreciated','FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')


figure(3)
haxes = axes();
    plot(datewt2,P_s5'*100,'LineWidth',1.7)
    hold on
    plot(datewt2,P_s6'*100,'LineWidth',1.7)
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('The price of stock increases and the price of gold decreases','FontSize',15,'interpreter','latex')
legend('Scenario 5: GBP is depreciated','Scenario 6: GBP is appreciated','FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')


figure(4)
haxes = axes();
    plot(datewt2,P_s7'*100,'LineWidth',1.7)
    hold on
    plot(datewt2,P_s8'*100,'LineWidth',1.7)
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('The price of stock decreases and the price of gold increases','FontSize',15,'interpreter','latex')
legend('Scenario 7: GBP is depreciated','Scenario 8: GBP is appreciated','FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')


%
figure(5)
haxes = axes();
    plot(datewt2,C_fx_st'*100,'LineWidth',1.7)
    hold on
    plot(datewt2,C_fx_gold'*100,'LineWidth',1.7)
    plot(datewt2,C_st_gold'*100,'LineWidth',1.7)
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('Probability of being in the $\alpha=10\%$ of the worst cases of pair of assets', 'FontSize',15,'interpreter','latex')
legend('JPY/USD and Nikkei225','JPY/USD and Gold','Nikkei225 and Gold','FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')

%%
figure(6)
haxes = axes();
    plot(datewt2,C_st_gold'*100,'LineWidth',1.7,'Color',[1 0.800000011920929 0.400000005960464])
    hold on 
    plot(datewt2,C90_st_gold'*100,'LineWidth',1.7,'Color',[0.400000005960464 1 1])
    plot(datewt2,C180_st_gold'*100,'.','LineWidth',1,'Color',[0.635294139385223 0.0784313753247261 0.184313729405403])
    plot(datewt2,C270_st_gold'*100,'.','LineWidth',1,'Color',[0.0784313753247261 0.168627455830574 0.549019634723663])
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('Possible scenarios for Gold and FTSE100', 'FontSize',15,'interpreter','latex')
legend('P($S<VaR_s(\beta),G<VaR_g(\gamma$))','P($S>VaR_s(1-\beta),G<VaR_g(\gamma$))',...
    'P($S>VaR_s(1-\beta),G>VaR_g(1-\gamma$))','P($S<VaR_s(\beta),G>VaR_g(1-\gamma$))',...
    'FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')


figure(7)
haxes = axes();
    plot(datewt2,C_fx_gold'*100,'LineWidth',1.7,'Color',[1 0.800000011920929 0.400000005960464])
    hold on 
    plot(datewt2,C90_fx_gold'*100,'LineWidth',1.7,'Color',[0.400000005960464 1 1])
    plot(datewt2,C180_fx_gold'*100,'.','LineWidth',1,'Color',[0.635294139385223 0.0784313753247261 0.184313729405403])
    plot(datewt2,C270_fx_gold'*100,'.','LineWidth',1,'Color',[0.0784313753247261 0.168627455830574 0.549019634723663])
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('Possible scenarios for Gold and GBP/USD', 'FontSize',15,'interpreter','latex')
legend('P($E<VaR_e(\alpha),G<VaR_g(\gamma$))','P($E>VaR_e(1-\alpha),G<VaR_g(\gamma$))',...
    'P($E>VaR_e(1-\alpha),G>VaR_g(1-\gamma$))','P($E<VaR_e(\alpha),G>VaR_g(1-\gamma$))',...
    'FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')


figure(8)
haxes = axes();
    plot(datewt2,C_fx_st'*100,'LineWidth',1.7,'Color',[1 0.800000011920929 0.400000005960464])
    hold on 
    plot(datewt2,C90_fx_st'*100,'LineWidth',1.7,'Color',[0.400000005960464 1 1])
    plot(datewt2,C180_fx_st'*100,'.','LineWidth',1,'Color',[0.635294139385223 0.0784313753247261 0.184313729405403])
    plot(datewt2,C270_fx_st'*100,'.','LineWidth',1,'Color',[0.0784313753247261 0.168627455830574 0.549019634723663])
    hold off
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
title('Possible scenarios for GBP/USD and FTSE100', 'FontSize',15,'interpreter','latex')
legend('P($E<VaR_e(\alpha),S<VaR_s(\beta$))','P($E>VaR_e(1-\alpha),S<VaR_s(\beta$))',...
    'P($E>VaR_e(1-\alpha),S>VaR_s(1-\beta$))','P($E<VaR_e(\alpha),S>VaR_s(1-\beta$))',...
    'FontSize',15,'interpreter','latex')
xlabel('Date','FontSize',14,'interpreter','latex')
ylabel('Probability ($\%$)','FontSize',14,'interpreter','latex')
