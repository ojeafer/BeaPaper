function [r_sim,u_sim,vv,sigma,mu,theta_evolution] = ...
                SimulVines_OutofSample(r,params_marg,P,Q,structure_dependence,W,T)
%% Simulate W paths of length T for 3 assets with an ARMA(P,Q)-APARCH(1,1) 
% for the marginals and a vine copula model to define the dependence structure 
%
%% SYNTAX:
%   [r_sim, u_sim, sigma, mu] = simul(r,params_marg,structure_dependence,W,T)
%
%% INPUTS:
%   r: matrix of returns of the N assets (TxN)
%   params_marg: parameters of the marginal models (ARMA-APARCH)
%   P: number of lags of the AR model (Nx1)
%   Q: number of lags of the MA model (Nx1)
%   structure_dependence: parameters of the vine copula model
%               paramtr: set of transformed parameters
%               CopulaStructure: set of copulas in the structure (Nx1)
%               CopulaDynamic: 0 means constant, 1 means time-varying (Nx1)
%               output: cell array with the past time series of the 
%                       parameters of the copula and the probability integral 
%                       trasnformation (unconditional and conditional),
%                       employed at the beginning of the algorithm 
%                       (theta and uu, resulting of JointDependence_CVine.m)
%   W: numbers of paths 
%   T: length of the path
%
%% OUTPUTS:
%   r_sim: simulated returns
%   u_sim: simulated uniforms
%   sigma: standard deviation of simulated returns
%   mu: mean of simulated returns
%
%% Inputs
r1 = r(:,1); % Returns of asset 1
r2 = r(:,2); % Returns of asset 2
r3 = r(:,3); % Returns of asset 3

% ARMA model
phi0 = params_marg(1,:); % Constant 
phi1 = params_marg(2,:); % AR 
theta1 = params_marg(3,:); % MA 

% APARCH model
omega = params_marg(4,:); 
alpha1 = params_marg(5,:);
beta1 = params_marg(6,:);
gamma1 = params_marg(7,:);
delta = params_marg(8,:);

% Innovations distribution (Skewed Student t)
lambda = params_marg(end-1,:); % Skewness 
nu = params_marg(end,:); % Degrees of freedom 


%% First step: simulate dependence structure (vine copula)
[v,vv,theta_evolution] = Simulate_Dependence_CVine(structure_dependence,W,T);
    v1 = zeros(T,W); v1(:,:) = v(:,1,:); 
    v2 = zeros(T,W); v2(:,:) = v(:,2,:); 
    v3 = zeros(T,W); v3(:,:) = v(:,3,:); 

u1 = min(max(v1,1e-4),1-1e-4); u_sim(:,:,1) = u1; 
u2 = min(max(v2,1e-4),1-1e-4); u_sim(:,:,2) = u2; 
u3 = min(max(v3,1e-4),1-1e-4); u_sim(:,:,3) = u3;


%% Second step: simulate marginal distributions
N = size(r,2); % Number of assets
epsilon = NaN(T,W,N);
sigma = NaN(T,W,N);
r_sim = NaN(T,W,N);

for n = 1:N
    for t = 1:T
        if t==1 % seed
            mu(t,:,n) = phi0(n)./(1 - phi1(n))*ones(1,W); % epsilon(t-1)
            epsilon(t,:,n) = 0.0;
            sigma(t,:,n) = sqrt(var(r(:,n)))*ones(1,W);
            
        else         
            sigma(t,:,n) = (omega(n) + alpha1(n)*(abs(epsilon(t-1,:,n))-gamma1(n)*epsilon(t-1,:,n)).^delta(n) + ...
                        beta1(n)*sigma(t-1,:,n).^delta(n)) .^ (1/delta(n));
            epsilon(t,:,n) = skewtdis_inv(u_sim(t,:,n),nu(n),lambda(n)).* sigma(t,:,n);
            
            if t<=Q(n) % 1 < t <= Q
                if Q(n)==1
                    mu(t,:,n) = phi0(n)./(1 - phi1(n))*ones(1,W);
                else
                    mu(t,:,n) = phi0(n) + phi1(n).*r_sim(t-1,:,n);
                end
            else % t > Q
                mu(t,:,n) = phi0(n) + phi1(n).*r_sim(t-1,:,n) + theta1(n).*epsilon(t-Q(n),:,n);
            end
        end
        
    r_sim(t,:,n) = mu(t,:,n) + epsilon(t,:,n);
  
  sprintf('%.2f%% Completado',(t+(n-1)*T)./(N*T)*100)
  end
end


end
