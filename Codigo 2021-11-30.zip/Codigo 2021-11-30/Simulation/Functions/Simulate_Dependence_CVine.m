function [v,vv,theta_evolution] = Simulate_Dependence_CVine(structure_dependence,W,T)
%% Simulate_Dependence_CVine: simulate W dependence paths of length T for N
% assets which have a C-Vine structure
%% SYNTAX: [v,theta_evolution] = Simulate_Dependence_CVine(structure_dependence,W,T)
%
%% INPUTS: 
%           structure_dependence: structure of dependence
%               paramtr: set of transformed parameters
%               SortedVariables: to be employed at the
%                                end of the code to reorder the output
%               CopulaStructure: set of copulas in the structure (Nx1)
%               CopulaDynamic: 0 means constant, 1 means time-varying (Nx1)
%               output: cell array with the past time series of the 
%                       parameters of the copula and the probability integral 
%                       trasnformation (unconditional and conditional),
%                       employed at the beginning of the algorithm 
%                       (theta and uu, resulting of JointDependence_CVine.m)
%           W: number of simulations (defaults: 100)
%           T: length of the path (default: 52, which for weekly data means one year)
%
%% OUTPUTS:
%           v: structure between the quantiles
%           theta_evolution: future evolution of the parameters of the copulas
%
%% Javier Ojea Ferreiro 8/4/2021
if nargin==3

elseif nargin==2
        T=52;
elseif nargin==1
           T=52;
           W=100;
elseif nargin<1
    error('structure_dependence is the basic input to be introduced in the code')
end

% copula structure
copulaeset=structure_dependence.CopulaStructure;
dynamic=structure_dependence.CopulaDynamic;
% dimensions
N_link = size(copulaeset,2);
N_assets = size(structure_dependence.output.uu,1);

% Get the number of parameters in the model
for ii = 1:N_link
        if  strcmp(copulaeset{ii},'Gaussian')| strcmp(copulaeset{ii},'Frank')|...
                strcmp(copulaeset{ii},'Plackett')| strcmp(copulaeset{ii},'Joe')|...
                strcmp(copulaeset{ii},'90Joe')| strcmp(copulaeset{ii},'180Joe')|...
                strcmp(copulaeset{ii},'270Joe')|strcmp(copulaeset{ii},'Clayton')|...
                strcmp(copulaeset{ii},'90Clayton')|strcmp(copulaeset{ii},'180Clayton')|...
                strcmp(copulaeset{ii},'270Clayton')|strcmp(copulaeset{ii},'Gumbel')|...
                strcmp(copulaeset{ii},'90Gumbel')|strcmp(copulaeset{ii},'180Gumbel')|...
                strcmp(copulaeset{ii},'270Gumbel')
            n_param_cop(ii+1) = 1+2*dynamic(ii);
        elseif strcmp(copulaeset{ii},'BB1')|...
                strcmp(copulaeset{ii},'90BB1')|strcmp(copulaeset{ii},'180BB1')|...
                strcmp(copulaeset{ii},'270BB1')|strcmp(copulaeset{ii},'BB2')|...
                strcmp(copulaeset{ii},'90BB2')|strcmp(copulaeset{ii},'180BB2')|...
                strcmp(copulaeset{ii},'270BB2')|strcmp(copulaeset{ii},'BB3')|...
                strcmp(copulaeset{ii},'90BB3')|strcmp(copulaeset{ii},'180BB3')|...
                strcmp(copulaeset{ii},'270BB3')|strcmp(copulaeset{ii},'BB4')|...
                strcmp(copulaeset{ii},'90BB4')|strcmp(copulaeset{ii},'180BB4')|...
                strcmp(copulaeset{ii},'270BB4')|strcmp(copulaeset{ii},'BB5')|...
                strcmp(copulaeset{ii},'90BB5')|strcmp(copulaeset{ii},'180BB5')|...
                strcmp(copulaeset{ii},'270BB5')|strcmp(copulaeset{ii},'BB6')|...
                strcmp(copulaeset{ii},'90BB6')|strcmp(copulaeset{ii},'180BB6')|...
                strcmp(copulaeset{ii},'270BB6')|strcmp(copulaeset{ii},'BB7')|...
                strcmp(copulaeset{ii},'90BB7')|strcmp(copulaeset{ii},'180BB7')|...
                strcmp(copulaeset{ii},'270BB7')|strcmp(copulaeset{ii},'SJC')|...
                strcmp(copulaeset{ii},'90SJC')|strcmp(copulaeset{ii},'180SJC')|...
                strcmp(copulaeset{ii},'270SJC')|strcmp(copulaeset{ii},'BB8')|...
                strcmp(copulaeset{ii},'90BB8')|strcmp(copulaeset{ii},'180BB8')|...
                strcmp(copulaeset{ii},'270BB8')
            n_param_cop(ii+1) = 2+4*dynamic(ii);
        elseif strcmp(copulaeset{ii},'Student')
                n_param_cop(ii+1) = 2+2*dynamic(ii);
        else
            n_param_cop(ii+1) = 0;
        end
end

% conditioned quantiles
%%%%%%%%%%%%%%%%%%%% Uncomment for replication purposes %%%%%%%%%%%%%%%%%%%
% rng('default')
% s = rng
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
q=min(max(rand(T,N_assets,W),5e-3),1-5e-3); % Independent uniform on [0,1]
%
for ii=1:N_assets
    uu{ii,1}=q(:,ii,:);
end
%
for ii=1:N_link
    theta_evolution{1,ii}=permute(ones(W,1)*structure_dependence.output.theta{1,ii}(end,:),[3,2,1]);
end
uP=[];
for ii=1:N_assets
    for jj=ii+1:N_assets
        uP=[uP;[ii,jj]]; % uP = [1,2; 1,3; 2,3]
    end
end
% parameters of the copula structure
param=structure_dependence.paramtr;
for t=1:T
    for w=1:W
          for i=2:N_assets
              for j=i-1:-1:1
                  ii=find(all([uP==[j,i]],2));
%                   u = uu{i,1}(t,1,w)
%                   th = theta_evolution{1,ii}(t,:,w)
                  uu{i,1}(t,1,w)=qquantile_curve(copulaeset{ii},...
                                theta_evolution{1,ii}(t,:,w),...
                                uu{i,1}(t,1,w),uu{j,j}(t,1,w));
              end
            % compute the conditional distribution, which is going to be
            % the input for the next tree
                for j=1:i-1
                    ii=find(all([uP==[j,i]],2));
                    uu{i,j+1}(t,1,w)=conditionalcdf(copulaeset{ii},...
                        theta_evolution{1,ii}(t,:,w),...
                        uu{j,j}(t,1,w), uu{i,j}(t,1,w));
                end
%             sprintf('Generating dependence according to the CVine (%.2f %% Completed)',...
%                 (i-2+(w-1)*(N_assets-1)+(t-1)*W*(N_assets-1))./(T*W*(N_assets-1))*100)
          end
    end
    for ii = 1:N_link
        pp = sum(n_param_cop(1:ii));  %number of parameters up to this copula
        if dynamic(ii)==1 % Patton code
            theta_evolution{1,ii}(t+1,:,:) = bivariateCopula_Dyn_Patton(param(1+pp:pp+n_param_cop(ii+1)),...
                [uu{uP(ii,1),uP(ii,1)}(1:t,:,:),uu{uP(ii,2),uP(ii,1)}(1:t,:,:)],copulaeset{ii},...
                [structure_dependence.output.uu{uP(ii,1),uP(ii,1)},...
                structure_dependence.output.uu{uP(ii,2),uP(ii,1)}],...
                theta_evolution{1,ii}(1:t,:,:));
        elseif dynamic(ii)==0 % constant dependence
            theta_evolution{1,ii}(t+1,:,:)=theta_evolution{1,ii}(t,:,:);
        else
            error('dynamics must be zero or one')
        end
    end
end
% v=[uu{1,1},uu{2,1},uu{3,1},uu{4,1}];
v=[uu{1,1},uu{2,1},uu{3,1}];
vv=uu; %3x3
