%% Simulation
clear all
clc

load('Main_UK2')

%%
options = optimset('Display','Notify','MaxIter',1e4,'MaxFunEvals',1e4,'TolFun',1e-4,'TolX',1e-4);
P = [1, 1, 1]; % AR lags
Q = [1, 1, 1]; % MA lags

alpha0 = 0.04;  
beta0 = 0.92;
param0 = [alpha0 beta0];

nu0 = 4.0;
alphatr0 = -log(1/alpha0 - 1);
betatr0 = log(beta0/(1-alpha0-beta0));
nutr0 = log(nu0) + 3;
param0t = [alphatr0 betatr0 nutr0];

params_st2(1:7) = params_st(1:7); % for Brazil
params_st2(8) = 2.0;
params_st2(9:10) = params_st(8:9);

% Simulacion de rendimientos
W = 50;
[R_sim,u_sim,sigma,mu] = simul(returns,[dcc12(1);dcc13(1);dcc23(1)],...
                    [params_fx,params_st2',params_gold],param_opt,W,T); 

                
%% Estimate the parameters of each marginal model   
tic
for w = 1:W
    w 
    [param_sim1(:,w),u_sim1(:,w),mu_sim1(:,w),sigma2_sim1(:,w),z_sim1(:,w),LLF_sim1(w)] = ...
        EstimateModel(R_sim(:,w,1),P(1),Q(1),'APARCH','Skewedt',options);
    [aic_sim1(w),bic_sim1(w)] = aicbic(LLF_sim1(w),size(param_sim1,1),T);
    disp('Ya esta el 1')
    
    [param_sim2(:,w),u_sim2(:,w),mu_sim2(:,w),sigma2_sim2(:,w),z_sim2(:,w),LLF_sim2(w)] = ...
        EstimateModel(R_sim(:,w,2),P(2),Q(2),'GJR','Skewedt',options);
    [aic_sim2(w),bic_sim2(w)] = aicbic(LLF_sim2(w),size(param_sim2,1),T);
    disp('Ya esta el 2')
    
    [param_sim3(:,w),u_sim3(:,w),mu_sim3(:,w),sigma2_sim3(:,w),z_sim3(:,w),LLF_sim3(w)] = ...
        EstimateModel(R_sim(:,w,3),P(3),Q(3),'APARCH','Skewedt',options);
    [aic_sim3(w),bic_sim3(w)] = aicbic(LLF_sim3(w),size(param_sim3,1),T);
    disp('Ya esta el 3')
end
toc


%% Estimate the dependence of the simulated variables using DCC-GARCH model  
tic
for w = 1:W 
    w                     
    global uni 
    uni = [u_sim1(2:end,w), u_sim2(:,w), u_sim3(2:end,w)];
    
    % Normal
    param_opt_sim(:,w) = fminunc('dcc_garch3v_normal',param0,options);
    [lnL_dcc_sim(:,w),dcc12_sim(:,w),dcc13_sim(:,w),dcc23_sim(:,w)] = dcc_garch3v_normal(param_opt_sim);
    disp('Normal')
    
    % Student t
    paramtr_optt_sim = fminunc('dcc_garch3v_t',param0t,options);
    [lnL_dcc2_sim(:,w),dcc12t_sim(:,w),dcc13t_sim(:,w),dcc23t_sim(:,w)] = dcc_garch3v_t(paramtr_optt_sim);
    param_optt_sim(:,w) = [(1+exp(-paramtr_optt_sim(1)))^(-1);
                            exp(paramtr_optt_sim(2))/(1+exp(paramtr_optt_sim(1))+exp(paramtr_optt_sim(2)));
                            exp(paramtr_optt_sim(3)-3)];                                    

    param_optt_sim2(:,w) = [(1+exp(-paramtr_optt_sim(1)))^(-1);
                            exp(paramtr_optt_sim(2))/(1+exp(paramtr_optt_sim(1))+exp(paramtr_optt_sim(2)));
                            paramtr_optt_sim(3)];  
    disp('t')
end
toc

%%
std_param_mg_sim1 = std(param_sim1');
std_param_mg_sim2 = std(param_sim2');
std_param_mg_sim3 = std(param_sim3');
% vec_st_mg = [std_param_mg_sim1; std_param_mg_sim2; std_param_mg_sim3]';

std_param_dccN = std(param_opt_sim');
std_param_dcct = std(param_optt_sim');
std_param_dcct2 = std(param_optt_sim2');
         

%% Backtesting
alpha = 0.05;
vec_tau = [0.01, 0.025, 0.05, 0.10];
for w = 1:W
    [pValue1(:,w), h01(:,w), table_tests] = test_distribution_Skewedt(z_sim1(:,w),param_sim1(end),param_sim1(end-1),alpha);
    [pValue2(:,w), h02(:,w), table_tests] = test_distribution_Skewedt(z_sim2(:,w),param_sim2(end),param_sim2(end-1),alpha);
    [pValue3(:,w), h03(:,w), table_tests] = test_distribution_Skewedt(z_sim3(:,w),param_sim3(end),param_sim3(end-1),alpha);
    
    [percentage_exc1(:,w), pVal_K1(:,w), pVal_C1(:,w)] = ...
        VaR_backtesting(R_sim(:,w,1),mu_sim1(:,w),sigma2_sim1(:,w),param_sim1(end),param_sim1(end-1),alpha,vec_tau);
    [percentage_exc2(:,w), pVal_K2(:,w), pVal_C2(:,w)] = ...
        VaR_backtesting(R_sim(:,w,2),mu_sim2(:,w),sigma2_sim2(:,w),param_sim2(end),param_sim2(end-1),alpha,vec_tau);
    [percentage_exc3(:,w), pVal_K3(:,w), pVal_C3(:,w)] = ...
        VaR_backtesting(R_sim(:,w,3),mu_sim3(:,w),sigma2_sim3(:,w),param_sim3(end),param_sim3(end-1),alpha,vec_tau);
end


%%
save('Sim_param_UK2') 


%%
percentile_fx = prctile(param_sim1',[10,90, 5,95, 1,99])'; 
percentile_st = prctile(param_sim2',[10,90, 5,95, 1,99])';
percentile_gold = prctile(param_sim3',[10,90, 5,95, 1,99])';
