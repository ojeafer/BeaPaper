clear all
clc

load('Vines_UK_nuevo') % data of vine copula model


%% Simulation returns under the optim vine copula model
% params_st = [params_st(1:7); 2.0; params_st(8:9)]; % for Brazil
% params_st = [params_st(1:end-2); 0.0; 2.0; params_st(end-1:end)]; % for Japan
params_marg = [params_fx, params_st, params_gold];

structure_dependence.CopulaStructure = optim_model.copula_best;
structure_dependence.CopulaDynamic = [optim_model.Dynamics{1,1}(1), ...
                                      optim_model.Dynamics{1,2}(1), ...
                                      optim_model.Dynamics{1,3}(1)];
structure_dependence.output.uu = output_best.uu; 
structure_dependence.paramtr = optim_model.params{1,3};
structure_dependence.output.theta = output_best.theta;
structure_dependence.output = output_best;

W = 100;
tic
[R_sim,~,~,~] = simulation_vines(returns,params_marg,P,Q,structure_dependence,W,T2);
toc

R_sim2 = R_sim;

%% 
options = optimset('Display','Notify','MaxFunEvals',1.0e5,'MaxIter',1.0e4,'TolFun',1.0e-8,'TolX',1.0e-8);
N_link = size(R_sim,3);
nu_ini = 4.0;
bb1_ini = [0.01, 0.01];

dynamic_best = structure_dependence.CopulaDynamic;
copula_best = structure_dependence.CopulaStructure;

tic
for w = 1:W
    % Optim marginal
        clear uni data_comp
        [params_mg2(:,w,1),uni(:,w,1),~,~,~,~] = ...
            EstimateModel(R_sim(:,w,1),P(1),Q(1),'APARCH','Skewedt',options);
%         [params_marg2,uni0,~,~,~,~] = ...
        [params_mg2(:,w,2),uni(:,w,2),~,~,~,~] = ...
            EstimateModel(R_sim(:,w,2),P(2),Q(2),'APARCH','Skewedt',options);
%             params_mg2(:,w,2) = [params_marg2(1:end-2); 0.0; 2.0; params_marg2(end-1:end)];
%             uni(:,w,2) = [uni0];
        [params_mg2(:,w,3),uni(:,w,3),~,~,~,~] = ...
            EstimateModel(R_sim(:,w,3),P(3),Q(3),'APARCH','Skewedt',options);
    
    % Dependence structure
    data_comp(:,:) = uni(:,w,:);
    
    % Initial seed for the model
    for i = 1:N_link
        if i == 1
            data = data_comp(:,1:2);
            lambda = [params_mg2(end-1,w,1), params_mg2(end-1,w,2)];
            nu = [params_mg2(end,w,1), params_mg2(end,w,2)];
        elseif i == 2
            data = [data_comp(:,1), data_comp(:,3)];
            lambda = [params_mg2(end-1,w,1), params_mg2(end-1,w,3)];
            nu = [params_mg2(end,w,1), params_mg2(end,w,3)];
        elseif i == N_link
            data = data_comp(:,2:3);
            lambda = [params_mg2(end-1,w,2), params_mg2(end-1,w,3)];
            nu = [params_mg2(end,w,2), params_mg2(end,w,3)];
        end
        
        if dynamic_best(i) == 0
            if strcmp(copula_best{i},'Gaussian')  
                param_sim{w,1}.param0{i} = corr(norminv(data(:,1)),norminv(data(:,2)));
            elseif strcmp(copula_best{i},'Student')
                param_sim{w,1}.param0{i} = [corr(tinv(data(:,1),nu(1)),tinv(data(:,2),nu(2))),...
                                            -log(97.9/(nu_ini-2.1)-1)]; 
            elseif strcmp(copula_best{i},'Gumbel') | strcmp(copula_best{i},'Clayton')
                param_sim{w,1}.param0{i} = copulafit(copula_best{i},[data(:,1),data(:,2)]);
            elseif strcmp(copula_best{i},'90Gumbel') 
                param_sim{w,1}.param0{i} = copulafit('Gumbel',[1-data(:,1),data(:,2)]);
            elseif strcmp(copula_best{i},'90Clayton')
                param_sim{w,1}.param0{i} = copulafit('Clayton',[1-data(:,1),data(:,2)]);    
            elseif strcmp(copula_best{i},'BB1') | strcmp(copula_best{i},'90BB1') 
                param_sim{w,1}.param0{i} = [-log(1./bb1_ini(1)-1), -log(1./bb1_ini(1)-1)];
            end

        else % if dynamic_best(i) == 1
            if strcmp(copula_best{i},'Gaussian') 
                param_sim{w,1}.param0{i} = [corr(norminv(data(:,1)),norminv(data(:,2))), 0,0]; 
            elseif strcmp(copula_best{i},'Student') 
                param_sim{w,1}.param0{i} = [corr(tinv(data(:,1),nu_ini),tinv(data(:,2),nu_ini)), ...
                                       0,0, -log(97.9/(nu_ini-2.1)-1)]; 
            elseif strcmp(copula_best{i},'Gumbel') | strcmp(copula_best{i},'Clayton') 
                param_sim{w,1}.param0{i} = [copulafit(copula_best{i},[data(:,1),data(:,2)]), 0,0];
            elseif strcmp(copula_best{i},'90Gumbel')
                param_sim{w,1}.param0{i} = [copulafit('Gumbel',[1-data(:,1),data(:,2)]), 0,0];
            elseif strcmp(copula_best{i},'90Clayton')
                param_sim{w,1}.param0{i} = [copulafit('Clayton',[1-data(:,1),data(:,2)]), 0,0];
            elseif strcmp(copula_best{i},'BB1') | strcmp(copula_best{i},'90BB1')
                param_sim{w,1}.param0{i} = [-log(1./bb1_ini(1)-1), 0,0, ...
                                            -log(1./bb1_ini(2)-1), 0,0];
            end
        end 
        sprintf('%.4f%% Completado',(i+(w-1)*N_link)./(N_link*W)*100)
    end
    
    param_sim{w,1}.param0tot = [param_sim{w,1}.param0{1,1}, ...
                                param_sim{w,1}.param0{1,2}, ...
                                param_sim{w,1}.param0{1,3}];
     
    % Optim model
    param_sim{w,1}.param1 = fminsearch('JointDependence_CVine',...
            param_sim{w,1}.param0tot,options,data_comp,copula_best',dynamic_best');
    [LLF_sim(w),output_sim{w,1}] = ...
            JointDependence_CVine(param_sim{w,1}.param1,data_comp,copula_best',dynamic_best');
        output_sim{w,1}.LLF = LLF_sim(w);
        output_sim{w,1}.params = param_sim{w,1}.param1;
        for j1 = 1:size(output_sim{w,1}.theta{1,1},2)
            theta12(:,j1,w) = output_sim{w,1}.theta{1,1}(:,j1);
        end
        for j2 = 1:size(output_sim{w,1}.theta{1,2},2)
            theta13(:,j2,w) = output_sim{w,1}.theta{1,2}(:,j2);
        end
        for j3 = 1:size(output_sim{w,1}.theta{1,3},2)
            theta23_1(:,j3,w) = output_sim{w,1}.theta{1,3}(:,j3);
        end
end
toc


% Standard deviation of the parameters
for k = 1:W
    param_optv(k,:) = param_sim{k,1}.param1;
    DoFtr(k,:) = [param_sim{k,1}.param1(2);param_sim{k,1}.param1(end)]; % cambiar en cada region
    DoF(k,:) = 97.9./(1+exp(-DoFtr(k,:)))+2.1;
%     claytontr(k,:) = param_sim{k,1}.param1(end);
%     clayton(k,:) = 100./(1+exp(-claytontr(k,:)));
end

for p = 1:size(param_optv,2)
    percentile(p,:) = prctile(param_optv(:,p),[10, 90, 5, 95, 1, 99]);
end

std_param = std(param_optv,1); %1xN_param
std_DoF = std(DoF,1);

%
params_mg_sim1(:,:) = params_mg2(:,:,1); std_marg1 = std(params_mg_sim1',1);
params_mg_sim2(:,:) = params_mg2(:,:,2); std_marg2 = std(params_mg_sim2',1);
params_mg_sim3(:,:) = params_mg2(:,:,3); std_marg3 = std(params_mg_sim3',1);
for p1 = 1:size(params_mg_sim1,1)
    percentile_mg1(p1,:) = prctile(params_mg_sim1(p1,:),[10, 90, 5, 95, 1, 99]);
end
for p2 = 1:size(params_mg_sim2,1)
    percentile_mg2(p2,:) = prctile(params_mg_sim2(p2,:),[10, 90, 5, 95, 1, 99]);
end
for p3 = 1:size(params_mg_sim3,1)
    percentile_mg3(p3,:) = prctile(params_mg_sim3(p3,:),[10, 90, 5, 95, 1, 99]);
end

%%
save('SimulVine_UK_nuevo', 'R_sim','uni','params_marg','params_mg2','std_param','std_DoF',...
     'structure_dependence','returns','params_marg','P','Q','W','T2','datewt2',...
     'param_optv','DoF','percentile','data_comp','LLF_sim','param_sim','output_sim', ...
     'params_mg_sim1','params_mg_sim2','params_mg_sim3','std_marg1','std_marg2','std_marg3','-v7.3')