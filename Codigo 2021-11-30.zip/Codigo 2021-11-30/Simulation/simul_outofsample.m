function [r_sim,u_sim,sigma,mu,rho12,rho13,rho23] = simul_outofsample(r,dcc,params_marg,params_dcc,W,T)
%% Simulate W paths of length T for 3 assets which have an ARMA(P,Q)-APARCH(1,1)-DCC-GARCH(1,1) structure
%
%% SYNTAX:
%   [r_sim, u_sim,sigma, mu] = simul(r,dcc,params_marg,params_dcc,W,T)
%
%% INPUTS:
%   r: matrix of returns of the N assets
%   dcc: vector of first values of dynamic correlation from DCC-GARCH model
%       (seed for simulate DCC-GARCH)
%   params_marg: parameters of the marginal models (ARMA-GARCH)
%   params_dcc: parameters of the DCC-GARCH model
%   W: numbers of paths simulated
%   T: length of the path
%
%% OUTPUTS:
%   r_sim: simulated returns
%   u_sim: simulated uniforms
%   sigma: standard deviation of simulated returns
%   mu: mean of simulated returns
%
%%
r1 = r(:,1); % Returns of asset 1
r2 = r(:,2); % Returns of asset 2
r3 = r(:,3); % Returns of asset 3

% ARMA model
phi0 = params_marg(1,:); % Constant 
phi1 = params_marg(2,:); % AR 
theta1 = params_marg(3,:); % MA 

% APARCH model
omega = params_marg(4,:); 
alpha1 = params_marg(5,:);
beta1 = params_marg(6,:);
gamma1 = params_marg(7,:);
delta = params_marg(8,:);

% Innovations distribution (Skewed Student t)
lambda = params_marg(end-1,:); % Skewness 
nu = params_marg(end,:); % Degrees of freedom 

% DCC-GARCH model
alpha_dcc = params_dcc(1); 
beta_dcc = params_dcc(2);
q11(1,1:W) = 1.0;
q22(1,1:W) = 1.0;
q33(1,1:W) = 1.0;
q12(1,1:W) = dcc(1,1); % It is equal to mean(cross1) in the original model
q13(1,1:W) = dcc(2,1);
q23(1,1:W) = dcc(3,1);

rho12(1,1:W) = q12(1,1:W);
rho13(1,1:W) = q13(1,1:W);
rho23(1,1:W) = q23(1,1:W);


%% First step: simulate DCC-GARCH dynamic (dependence structure)
% Gaussian r.v. (iid)
z1 = randn(T,W+100); z1 = z1(:,101:end); % Eliminamos las primeras 100 simulaciones
% para eliminar alguna posible dependencia entre las v.a. generadas
z2 = randn(T,W+100); z2 = z2(:,101:end);
z3 = randn(T,W+100); z3 = z3(:,101:end); 
Z(:,:,1) = z1;
Z(:,:,2) = z2;
Z(:,:,3) = z3;

% DCC-GARCH
for t = 1:T       
    if t > 1 
       q11(t,:) = q11(1,:) + beta_dcc*(q11(t-1,:)-q11(1,:)) + alpha_dcc*(x1(t-1,:).^2-q11(1,:));
       q12(t,:) = q12(1,:) + beta_dcc*(q12(t-1,:)-q12(1,:)) + alpha_dcc*(cross1(t-1,:)-q12(1,:));  
       q22(t,:) = q22(1,:) + beta_dcc*(q22(t-1,:)-q22(1,:)) + alpha_dcc*(x2(t-1,:).^2-q22(1,:));    
       q33(t,:) = q33(1,:) + beta_dcc*(q33(t-1,:)-q33(1,:)) + alpha_dcc*(x3(t-1,:).^2-q33(1,:));
       q13(t,:) = q13(1,:) + beta_dcc*(q13(t-1,:)-q13(1,:)) + alpha_dcc*(cross2(t-1,:)-q13(1,:));  
       q23(t,:) = q23(1,:) + beta_dcc*(q23(t-1,:)-q23(1,:)) + alpha_dcc*(cross3(t-1,:)-q23(1,:)); 
       
       rho12(t,:) = real(q12(t,:)./sqrt(q11(t,:).*q22(t,:)));
       rho13(t,:) = real(q13(t,:)./sqrt(q11(t,:).*q33(t,:)));
       rho23(t,:) = real(q23(t,:)./sqrt(q22(t,:).*q33(t,:)));
    end
    
    % Apply Cholesky to obtain dependent gaussian variables
    x1(t,:) = Z(t,:,1);
    x2(t,:) = rho12(t,:).*Z(t,:,1) + real(sqrt(1-rho12(t,:).^2)).*Z(t,:,2);
    x3(t,:) = rho13(t,:).*Z(t,:,1) + ...
              (rho23(t,:)-rho12(t,:).*rho13(t,:))./real(sqrt(1-rho12(t,:).^2)).*Z(t,:,2) + ...
              real(sqrt(1-rho13(t,:).^2-((rho23(t,:)-rho12(t,:).*rho13(t,:)).^2)/(1-rho12(t,:).^2))).*Z(t,:,3);
      
    cross1(t,:) = x1(t,:).*x2(t,:);
    cross2(t,:) = x1(t,:).*x3(t,:);
    cross3(t,:) = x2(t,:).*x3(t,:); 

end

u1 = min(max(normcdf(x1),1e-4),1-1e-4); u_sim(:,:,1) = u1; 
u2 = min(max(normcdf(x2),1e-4),1-1e-4); u_sim(:,:,2) = u2; 
u3 = min(max(normcdf(x3),1e-4),1-1e-4); u_sim(:,:,3) = u3;


%% Second step: simulate marginal distributions
N = size(r,2); % Number of assets
epsilon = NaN(T,W,N);
sigma = NaN(T,W,N);
r_sim = NaN(T,W,N);

for n = 1:N
    for t = 1:T
        if t==1
            mu(t,:,n) = phi0(n)./(1 - phi1(n))*ones(1,W); % epsilon(t-1)
            epsilon(t,:,n) = 0.0;
            sigma(t,:,n) = sqrt(var(r(:,n)))*ones(1,W);
            
        else         
            sigma(t,:,n) = (omega(n) + alpha1(n)*(abs(epsilon(t-1,:,n))-gamma1(n)*epsilon(t-1,:,n)).^delta(n) + ...
                        beta1(n)*sigma(t-1,:,n).^delta(n)) .^ (1/delta(n));
            epsilon(t,:,n) = skewtdis_inv(u_sim(t,:,n),nu(n),lambda(n)).* sigma(t,:,n);
            
            if t<=12 % 1 < t <= 12
                mu(t,:,n) = phi0(n) + phi1(n).*r_sim(t-1,:,n);
            else % t > 12
                mu(t,:,n) = phi0(n) + phi1(n).*r_sim(t-1,:,n) + theta1(n).*epsilon(t-12,:,n);
            end
        end
        
    r_sim(t,:,n) = mu(t,:,n) + epsilon(t,:,n);
  
  sprintf('%.2f%% Completado',(t+(n-1)*T)./(N*T)*100)
  end
end


end
