function [ff, theta, uu]=CVine_pdf(param,data,copulaeset,n_param_cop,dynamic)
%% CVine_pdf: Probability Distribution Function of the joint dependence
%% following a CVine structure where the type of dependence
%% is taken from "copula" and the presence of dynamic is presented in "dynamic"
%
%% SYNTAX: [ff, theta, uu] = CVine_pdf(param,data,copulaeset,n_param_cop,dynamic)
%
%% INPUTS:
%       param : copula parameter set
%       data : uniform distribution for the marginal variables
%       copulaset : type of copulas that link the variables
%       n_param_cop : number of parameters of the structure
%       dynamic: a vector with zeros and ones indicating if the
%       copula between a couple of variables is constant (zero) or
%       evolves over time (one) following Pattons specification
%
%% OUTPUTS:
%       ff : structure {N-1,K} of log density function at each time t
%       theta : structure {N-1,K} of the estimated parameters
%       uu : inputs of the copula function at each tree, i.e. at the
%            first column we get the probability integral transformation, in
%            the second column we get the conditional copula distribution
%            given the relationship between each dataset and the data which
%            is the root at the first tree,...
%
%%
[N_link,~] = size(copulaeset);
N_assets = size(data,2);

for ii = 1:N_assets
    uu{ii,1} = data(:,ii);
end

uP = [];
for ii = 1:N_assets
    for jj = ii+1:N_assets
        uP = [uP;[ii,jj]];
    end
end

%% Pair-copulas 
for ii = 1:N_link % each relation between variables        
        pp = sum(n_param_cop(1:ii)); % number of parameters up to this copula
        
        if dynamic(ii,1)==1 % Patton code
            [~,paramhat,CL] = bivDyn3_LogLiketr(param(1+pp:pp+n_param_cop(ii+1)),...
                [uu{uP(ii,1),uP(ii,1)},uu{uP(ii,2),uP(ii,1)}],copulaeset{ii});

        elseif dynamic(ii,1)==0 % constant dependence
            [~,paramhat,CL] = biv_LogLiketr_complete(param(1+pp:pp+n_param_cop(ii+1)),...
                             [uu{uP(ii,1),uP(ii,1)},uu{uP(ii,2),uP(ii,1)}],copulaeset{ii});
        else
            error('dynamics must be zero or one')
        end
        
        thetahat{ii} = paramhat;
        logL{ii,1} = CL;
        uu{uP(ii,2),uP(ii,1)+1} = conditionalcdf(copulaeset{ii}, thetahat{ii}(2:end,:),...
                                  uu{uP(ii,1),uP(ii,1)}, uu{uP(ii,2),uP(ii,1)});
%         uu{uP(ii,2),uP(ii,1)+1} = max(min(uu{uP(ii,2),uP(ii,1)+1},1-1.0e-4),1.0e-4);
end

%% Outputs
ff = logL;
theta = thetahat;