function cdf = BB1_cdf(u,v,theta,delta)
%% BB1_cdf: BB1 copula cdf
%
%% SYNTAX:
%         cdf = BB1_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017


cdf = (1+((u.^(-theta)-1).^delta+(v.^(-theta)-1).^delta).^(1./delta)).^(-1./theta);