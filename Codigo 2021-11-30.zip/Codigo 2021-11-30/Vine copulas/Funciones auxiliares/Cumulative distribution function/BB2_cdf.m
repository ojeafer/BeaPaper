function cdf = BB2_cdf(u,v,theta,delta)
%% BB2_cdf: BB2 copula cdf
%
%% SYNTAX:
%         cdf = BB2_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017


cdf = (1+delta.^(-1).*log(exp(delta.*(u.^(-theta)-1))+exp(delta.*(v.^(-theta)-1))-1)).^(-1./theta);