function cdf = BB3_cdf(u,v,theta,delta)
%% BB3_cdf: BB3 copula cdf
%
%% SYNTAX:
%         cdf = BB3_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017

u_hat=-log(u);
v_hat=-log(v);
cdf = exp(-(delta.^(-1).*log(exp(delta.*u_hat.^theta)+exp(delta.*v_hat.^theta)-1)).^(1./theta));