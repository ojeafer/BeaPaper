function cdf = BB4_cdf(u,v,theta,delta)
%% BB4_cdf: BB4 copula cdf
%
%% SYNTAX:
%         cdf = BB4_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 7/11/2017


cdf = (u.^(-theta)+v.^(-theta)-1-((u.^(-theta)-1).^(-delta)+(v.^(-theta)-1).^(-delta)).^(-1./delta)).^(-1./theta);
