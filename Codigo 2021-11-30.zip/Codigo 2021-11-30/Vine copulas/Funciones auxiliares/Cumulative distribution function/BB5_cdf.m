function cdf = BB5_cdf(u,v,theta,delta)
%% BB5_cdf: BB5 copula cdf
%
%% SYNTAX:
%         cdf = BB5_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 7/11/2017
u_hat=-log(u);
v_hat=-log(v);

cdf = exp(-(u_hat.^theta+v_hat.^theta-(u_hat.^(-theta.*delta)+v_hat.^(-theta.*delta)).^(-1./delta)).^(1./theta));