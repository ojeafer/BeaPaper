function cdf = BB6_cdf(u,v,theta,delta)
%% BB6_cdf: BB6 copula cdf
%
%% SYNTAX:
%         cdf = BB6_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 7/11/2017


cdf = 1-(1-exp(-((-log(1-(1-u).^theta)).^delta+(-log(1-(1-v).^theta)).^delta).^(1./delta))).^(1./theta);