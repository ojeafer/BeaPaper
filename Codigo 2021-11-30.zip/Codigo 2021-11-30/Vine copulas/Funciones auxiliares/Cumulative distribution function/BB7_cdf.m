function cdf = BB7_cdf(u,v,theta,delta)
%% BB7_cdf: BB7 copula cdf
%
%% SYNTAX:
%         cdf = BB7_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 7/11/2017

u_bar=1-u;
v_bar=1-v;
cdf = 1-(1-((1-u_bar.^(theta)).^(-delta)+(1-v_bar.^(theta)).^(-delta)-1).^(-1./delta)).^(1./theta);