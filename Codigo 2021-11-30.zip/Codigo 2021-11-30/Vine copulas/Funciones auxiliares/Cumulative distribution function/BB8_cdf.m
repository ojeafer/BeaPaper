function cdf = BB8_cdf(u,v,theta,delta)
%% BB8_cdf: BB8 copula cdf
%
%% SYNTAX:
%         cdf = BB8_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 7/11/2017


cdf =1./delta.*(1-(1-((1-(1-delta.*u).^theta).*(1-(1-delta.*v).^theta))./(1-(1-delta).^theta)).^(1./theta));