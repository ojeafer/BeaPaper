function cdf = SJC_cdf(u,v,theta,delta)
%% SJC_cdf: SJC copula cdf
%
%% SYNTAX:
%         cdf = SJC_cdf(u,v,theta,delta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%        delta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 7/11/2017


cdf = 0.5*(BB7_cdf(u,v,theta,delta)+BB7_cdf(1-u,1-v,theta,delta)+u+v-1);