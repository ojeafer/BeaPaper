function cdf = clayton_cdf(u,v,theta)
%% clayton_cdf: Clayton copula cdf
%
%% SYNTAX:
%         cdf = clayton_cdf(u,v,theta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017


cdf = (u.^(-theta)+v.^(-theta)-1).^(-1/theta);
if theta<=1e-5
    cdf=u.*v;
end