function cdf = frank_cdf(u,v,theta)
%% frank_cdf: Frank copula cdf
%
%% SYNTAX:
%         cdf = frank_cdf(u,v,theta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017


cdf = -log(1+expm1(-theta.*u).*expm1(-theta.*v)./expm1(-theta))./theta;