function cdf = gumbel_cdf(u,v,theta)
%% gumbel_cdf: Gumbel copula cdf
%
%% SYNTAX:
%         cdf = gumbel_cdf(u,v,theta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017
cdf = exp(-((-log(u)).^theta+(-log(v)).^theta).^(1./theta));