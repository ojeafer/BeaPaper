function cdf = joe_cdf(u,v,theta)
%% joe_cdf: Joe copula cdf
%
%% SYNTAX:
%         cdf = joe_cdf(u,v,theta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017


cdf = 1-((1-u).^theta+(1-v).^theta-(1-u).^theta.*(1-v)^theta).^(1./theta);