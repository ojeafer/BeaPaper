function cdf = plackett_cdf(u,v,theta)
%% frank_cdf: Plackett copula cdf
%
%% SYNTAX:
%         cdf = plackett_cdf(u,v,theta)
%
%% INPUT:
%        u: uniform value for assets 1
%        v: uniform value for assets 2
%        theta : parameter
%% OUTPUT:
%         cdf: cumulative distribution function
%
%% Javier Ojea Ferreiro 31/10/2017


cdf = ((1+(theta-1).*(u+v))-((1+(theta-1).*(u+v))^2-4.*theta.*(theta-1).*u.*v).^(1/2))./(2.*(theta-1));
