function [S, paramhat, CL] = bivDyn3_LogLiketr(param,data,copulatype)
%% biv_LogLike:  LogLike function
%
%% SYNTAX:
%        [S, paramhat, CL] = bivDyn3_LogLike(param,data,copulatype)
%
%% INPUT:
%              param    =	parameters
%              data = u (Tx2)
%              copulatype =  Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90Joe'/'180Joe'/'270Joe'
%                           *'Clayton'/'90Clayton'/'180Clayton'/'270RClayton'
%                           *'Gumbel'/'90Gumbel'/'180Gumbel'/'270Gumbel'
%                           *'BB1'/'90BB1'/'180BB1'/'270BB1'
%                           *'BB2'/'90BB2'/'180BB2'/'270BB2'
%                           *'BB3'/'90BB3'/'180BB3'/'270BB3'
%                           *'BB4'/'90BB4'/'180BB4'/'270BB4'
%                           *'BB5'/'90BB5'/'180BB5'/'270BB5'
%                           *'BB6'/'90BB6'/'180BB6'/'270BB6'
%                           *'BB7'/'90BB7'/'180BB7'/'270BB7'
%                           *'SJC'/'90SJC'/'180SJC'/'270SJC'
%                           *'BB8'/'90BB8'/'180BB8'/'270BB8'
%                           *'Independence'
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               paramhat : values of the estimates
%               CL : logdensity at each point
%%
%Javier Ojea Ferreiro 20/10/2017
% Updated: 23/04/2018
%Updated: 15/12/2018
%%
T = size(data,1);
%%
% if strcmp(copulatype,'Independence')
%         paramhat(:,1) = NaN(T+1,1);
% end
if length(param)<=4 
    if length(param)==0 % when copulatype is 'Independence'
        omega = 0;
    else
        omega=param(1);
        alpha=param(2);
        beta=param(3);
    end
else % BB1
    omega(1,1)=param(1);
    alpha(1,1)=param(2);
    beta(1,1)=param(3);
    omega(1,2)=param(4);
    alpha(1,2)=param(5);
    beta(1,2)=param(6);
end
if  strcmp(copulatype,'Gaussian')
    x = norminv(data(:,1),0,1);
    y = norminv(data(:,2),0,1);
    %1. Gaussian copula
    for t=1:T+1
        if t<=10
            if t==1
                psi(t)= omega;
            else
                psi(t) = omega + alpha*mean(x(1:t-1).*y(1:t-1)) + beta*rho(t-1);
            end
        else
            psi(t) = omega + alpha*mean(x(t-10:t-1).*y(t-10:t-1)) + beta*rho(t-1);
        end
        rho(t,1) = (1-exp(-psi))/(1+exp(-psi));
    end
    paramhat=rho;
elseif strcmp(copulatype,'Student')
    %2. Student copula
    nu=97.9/(1+exp(-param(end)))+2.1;
    x = tinv(data(:,1),nu);
    y = tinv(data(:,2),nu);
    for t=1:T+1
        if t<=10
            if t==1
                psi = omega;
            else
                psi = omega + alpha*mean(x(1:t-1).*y(1:t-1)) + beta*rho(t-1);
            end
        else
            psi = omega + alpha*mean(x(t-10:t-1).*y(t-10:t-1)) + beta*rho(t-1);
        end
        rho(t,1) = (1-exp(-psi))/(1+exp(-psi));
    end
    paramhat=[rho, ones(T+1,1)*nu];
else
    x = data(:,1);
    y = data(:,2);
    if strncmpi(copulatype,'90',2)
        x = 1-x;
    end
    if strncmpi(copulatype,'180',3)
        x = 1-x;
        y = 1-y;
    end
    if strncmpi(copulatype,'270',3)
        y = 1-y;
    end
    if strcmp(copulatype,'Frank') |strcmp(copulatype,'Plackett') | ...
            strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
            strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')|...
            strcmp(copulatype,'Clayton') |strcmp(copulatype,'90Clayton') | ...
            strcmp(copulatype,'180Clayton') |strcmp(copulatype,'270Clayton') | ...
            strcmp(copulatype,'Gumbel') | strcmp(copulatype,'90Gumbel')|...
            strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel')
        if strcmp(copulatype,'Frank')
            for t=1:T+1
                if t<=10
                    if t==1
                        psi(t,1)=omega;
                    else
                        psi(t,1)=omega+beta*theta(t-1,1)+alpha*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                    end
                else
                    psi(t,1)=omega + alpha*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1))) + beta*theta(t-1,1);
                end
                theta(t,1)=psi(t,1);
            end
        elseif strcmp(copulatype,'Plackett')| strcmp(copulatype,'Clayton') |...
                strcmp(copulatype,'90Clayton') | strcmp(copulatype,'180Clayton') |...
                strcmp(copulatype,'270Clayton')
            for t=1:T+1
                if t<=10
                    if t==1
                        psi(t,1)=omega;
                    else
                        psi(t,1)=omega+beta*theta(t-1,1)+alpha*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                    end
                else
                    psi(t,1)=omega+beta*theta(t-1,1)+alpha*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
                end
                theta(t,1)=100/(1+exp(-psi(t,1))); % Alternative: theta(t,1) = exp(psi(t));
            end
        elseif strcmp(copulatype,'Gumbel') |  strcmp(copulatype,'90Gumbel')|...
                strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel') |...
                strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
                strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')
            for t=1:T+1
                if t<=10
                    if t==1
                        psi(t)=omega;
                    else
                        psi(t)=omega+beta*theta(t-1,1)+alpha*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                    end
                else
                    psi(t)=omega+beta*theta(t-1,1)+alpha*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
                end
                theta(t,1)=99/(1+exp(-psi(t)))+1; % Alternative: 
%                 theta(t,1) = exp(psi(t))+1;
            end
        end
        paramhat=theta;
    elseif strcmp(copulatype,'BB1')| strcmp(copulatype,'90BB1')|...
            strcmp(copulatype,'180BB1')|strcmp(copulatype,'270BB1')
        %8. BB1 copula
        for t=1:T+1
            if t<=10
                if t==1
                       psi_L(t,1)=omega(1,1);
                       psi_U(t,1)=omega(1,2);
                else
                psi_L(t,1)=omega(1,1)+beta(1,1)*tau_L(t-1,1)+alpha(1,1)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                psi_U(t,1)=omega(1,2)+beta(1,2)*tau_U(t-1,1)+alpha(1,2)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                end
            else
                psi_L(t,1)=omega(1,1)+beta(1,1)*tau_L(t-1,1)+alpha(1,1)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
                psi_U(t,1)=omega(1,2)+beta(1,2)*tau_U(t-1,1)+alpha(1,2)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
            end
            tau_L(t,1)=(1+exp(-psi_L(t,1)))^(-1);
            tau_U(t,1)=(1+exp(-psi_U(t,1)))^(-1);
            theta(t,1)=-log2(2-tau_U(t,1))/log2(tau_L(t,1));
            delta(t,1)=1/log2(2-tau_U(t,1));
        end
        paramhat(:,1) = theta;
        paramhat(:,2) = delta;
    elseif strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
            strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2') | ...
            strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
            strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
            strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
            strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5') | ...
            strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
            strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')  | ...
            strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') |...
            strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
        if strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
                strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2')
            function_theta=@(x) x;
            function_delta=@(x) 99./(1+exp(-x))+1;
        elseif strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
                strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
                strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
                strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5')
            function_theta=@(x) 99./(1+exp(-x))+1;
            function_delta=@(x) 100./(1+exp(-x));
        elseif strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
                strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')
            function_theta=@(x) 99./(1+exp(-x))+1;
            function_delta=@(x) 99./(1+exp(-x))+1;
        elseif strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') | ...
                strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
            function_theta=@(x) 99./(1+exp(-x))+1;
            function_delta=@(x) 1./(1+exp(-x));
        end
        %%
        for t=1:T+1
            if t<=10
                if t==1
                    psi_T(t,1)=omega(1,1);
                    psi_D(t,1)=omega(1,2);
                else
                psi_T(t,1)=omega(1,1)+beta(1,1)*theta(t-1,1)+alpha(1,1)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                psi_D(t,1)=omega(1,2)+beta(1,2)*delta(t-1,1)+alpha(1,2)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                end
            else
                psi_T(t,1)=omega(1,1)+beta(1,1)*theta(t-1,1)+alpha(1,1)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
                psi_D(t,1)=omega(1,2)+beta(1,2)*delta(t-1,1)+alpha(1,2)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
            end
            theta(t,1)=function_theta(psi_T(t,1));
            delta(t,1)=function_delta(psi_D(t,1));
        end
        paramhat(:,1) = theta;
        paramhat(:,2) = delta;
    elseif strcmp(copulatype,'BB4') | strcmp(copulatype,'90BB4') |...
            strcmp(copulatype,'180BB4') | strcmp(copulatype,'270BB4')
        %11. BB4 copula
    
        for t=1:T+1
            if t<=10
                if t==1
                    psi_L(t,1)=omega(1,1);
                    psi_U(t,1)=omega(1,2);
                else
                    psi_L(t,1)=omega(1,1)+beta(1,1)*tau_L(t-1,1)+alpha(1,1)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                    psi_U(t,1)=omega(1,2)+beta(1,2)*tau_U(t-1,1)+alpha(1,2)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                end
                else
                psi_L(t,1)=omega(1,1)+beta(1,1)*tau_L(t-1,1)+alpha(1,1)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
                psi_U(t,1)=omega(1,2)+beta(1,2)*tau_U(t-1,1)+alpha(1,2)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
            end
            tau_L(t,1)=(1+exp(-psi_L(t,1)))^(-1);
            tau_U(t,1)=(1+exp(-psi_U(t,1)))^(-1);
            theta(t,1)=-log(2-tau_U(t,1))/log(tau_L(t,1));
            delta(t,1)=-1/log2(tau_U(t,1));
        end
        paramhat(:,1) = theta;
        paramhat(:,2) = delta;
    elseif strcmp(copulatype,'BB7') | strcmp(copulatype,'90BB7') |...
            strcmp(copulatype,'180BB7') | strcmp(copulatype,'270BB7') |...
            strcmp(copulatype,'SJC') | strcmp(copulatype,'90SJC') |...
            strcmp(copulatype,'180SJC') | strcmp(copulatype,'270SJC')
        for t=1:T+1
            if t<=10
                if t==1
                psi_L(t,1)=omega(1,1);
                psi_U(t,1)=omega(1,2);
                else
                psi_L(t,1)=omega(1,1)+beta(1,1)*tau_L(t-1,1)+alpha(1,1)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                psi_U(t,1)=omega(1,2)+beta(1,2)*tau_U(t-1,1)+alpha(1,2)*mean(abs(x(1:t-1,1)-y(1:t-1,1)));
                end
                else
                psi_L(t,1)=omega(1,1)+beta(1,1)*tau_L(t-1,1)+alpha(1,1)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
                psi_U(t,1)=omega(1,2)+beta(1,2)*tau_U(t-1,1)+alpha(1,2)*mean(abs(x(t-10:t-1,1)-y(t-10:t-1,1)));
            end
            tau_L(t,1)=(1+exp(-psi_L(t,1)))^(-1);
            tau_U(t,1)=(1+exp(-psi_U(t,1)))^(-1);
            theta(t,1)=1/log2(2-tau_U(t,1));
            delta(t,1)=-1/log2(tau_L(t,1));
        end
        paramhat(:,1) = theta;
        paramhat(:,2) = delta;
    elseif strcmp(copulatype,'Independence')
        paramhat(:,1) = NaN(T+1,1);
    end
end

[S,CL]=logpdf_complete([x,y],copulatype,paramhat(1:end-1,:));
