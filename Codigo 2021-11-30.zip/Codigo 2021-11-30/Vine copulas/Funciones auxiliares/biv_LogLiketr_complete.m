function [S, paramhat,CL] = biv_LogLiketr_complete(param,data,copulatype)
%% biv_LogLike:  LogLike function
%
%% SYNTAX:
%        [S, paramhat] = biv_LogLike(param,data,rhobar)
%
%% INPUT:
%              param    =	parameters
%              data = u (Tx2)
%              copulatype =  Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90Joe'/'180Joe'/'270Joe'
%                           *'Clayton'/'90Clayton'/'180Clayton'/'270Clayton'
%                           *'Gumbel'/'90Gumbel'/'180Gumbel'/'270Gumbel'
%                           *'BB1'/'90BB1'/'180BB1'/'270BB1'
%                           *'BB2'/'90BB2'/'180BB2'/'270BB2'
%                           *'BB3'/'90BB3'/'180BB3'/'270BB3'
%                           *'BB4'/'90BB4'/'180BB4'/'270BB4'
%                           *'BB5'/'90BB5'/'180BB5'/'270BB5'
%                           *'BB6'/'90BB6'/'180BB6'/'270BB6'
%                           *'BB7'/'90BB7'/'180BB7'/'270BB7'
%                           *'SJC'/'90SJC'/'180SJC'/'270SJC'
%                           *'BB8'/'90BB8'/'180BB8'/'270BB8'
%                           *'Independence'
%% OUTPUT:
%               S : Value of the Maximum Likelihood function
%               paramhat : values of the estimates
%               CL : logdensity at each point
%%
% Javier Ojea Ferreiro 20/10/2017
% Updated: 23/04/2018
% Updated: 15/12/2018
%%
T = size(data,1);
%%
if  strcmp(copulatype,'Gaussian')
    x = norminv(data(:,1),0,1);
    y = norminv(data(:,2),0,1);
    %1. Gaussian copula
    rho = (1-exp(-param(1)))/(1+exp(-param(1)));
    paramhat = rho*ones(T+1,1);
elseif strcmp(copulatype,'Student')
    %2. Student copula
    nu=97.9/(1+exp(-param(2))) + 2.1;
    x = tinv(data(:,1),nu);
    y = tinv(data(:,2),nu); 
    rho = (1-exp(-param(1)))/(1+exp(-param(1)));
    paramhat = ones(T+1,1)*[rho, nu];
else
    x = data(:,1);
    y = data(:,2);
    if strncmpi(copulatype,'90',2)
        x = 1-x;
    end
    if strncmpi(copulatype,'180',3)
        x = 1-x;
        y = 1-y;
    end
    if strncmpi(copulatype,'270',3)
        y = 1-y;
    end
    if strcmp(copulatype,'Frank') |strcmp(copulatype,'Plackett') | ...
            strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
            strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')|...
            strcmp(copulatype,'Clayton') |strcmp(copulatype,'90Clayton') | ...
            strcmp(copulatype,'180Clayton') |strcmp(copulatype,'270Clayton') | ...
            strcmp(copulatype,'Gumbel') | strcmp(copulatype,'90Gumbel')|...
            strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel')
        if strcmp(copulatype,'Frank')
            theta=param(1);
        elseif strcmp(copulatype,'Plackett')| strcmp(copulatype,'Clayton') |...
                 strcmp(copulatype,'90Clayton') | strcmp(copulatype,'180Clayton') |...
                 strcmp(copulatype,'270Clayton') 
            theta=100/(1+exp(-param(1)));
        elseif strcmp(copulatype,'Gumbel') |  strcmp(copulatype,'90Gumbel')|...
            strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel') |...
                strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
            strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')
            theta=99/(1+exp(-param(1)))+1;
        end
        paramhat=theta*ones(T+1,1);
    elseif strcmp(copulatype,'BB1')| strcmp(copulatype,'90BB1')|...
            strcmp(copulatype,'180BB1')|strcmp(copulatype,'270BB1')
        %8. BB1 copula
        tau_L=(1+exp(-param(1)))^(-1);
        tau_U=(1+exp(-param(2)))^(-1);
        paramhat(:,1) = ones(T+1,1)*-log2(2-tau_L)/log2(tau_U);
        paramhat(:,2) = ones(T+1,1)*1/log2(2-tau_L);
    elseif strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
            strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2') | ...
            strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
            strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
            strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
            strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5') | ...
            strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
            strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')  | ...
            strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') |...
            strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
        if strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
            strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2')
            theta=100/(1+exp(-param(1)));
            delta=100/(1+exp(-param(2)));
        elseif strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
            strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
            strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
            strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5')
            theta=99/(1+exp(-param(1)))+1;
            delta=100/(1+exp(-param(2)));
        elseif strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
            strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6') 
            theta=99/(1+exp(-param(1)))+1;
            delta=99/(1+exp(-param(2)))+1;
        elseif strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') | ...
            strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
            theta=99/(1+exp(-param(1)))+1;
            delta=1/(1+exp(-param(2)));
        end       
        paramhat(:,1) = ones(T+1,1)*theta;
        paramhat(:,2) = ones(T+1,1)*delta;
    elseif strcmp(copulatype,'BB4') | strcmp(copulatype,'90BB4') |...
            strcmp(copulatype,'180BB4') | strcmp(copulatype,'270BB4')
        %11. BB4 copula
        tau_L=(1+exp(-param(1)))^(-1);
        tau_U=(1+exp(-param(2)))^(-1);
        paramhat(:,1) = ones(T+1,1)*-log(2-tau_U)/log(tau_L);
        paramhat(:,2) = ones(T+1,1)*-1/log2(tau_U);
    elseif strcmp(copulatype,'BB7') | strcmp(copulatype,'90BB7') |...
            strcmp(copulatype,'180BB7') | strcmp(copulatype,'270BB7') |...
            strcmp(copulatype,'SJC') | strcmp(copulatype,'90SJC') |...
            strcmp(copulatype,'180SJC') | strcmp(copulatype,'270SJC')
        tau_L=(1+exp(-param(1)))^(-1);
        tau_U=(1+exp(-param(2)))^(-1);
        paramhat(:,1) = ones(T+1,1)*1/log2(2-tau_U);
        paramhat(:,2) = ones(T+1,1)*-1/log2(tau_L);
    elseif strcmp(copulatype,'Independence')
        paramhat(:,1) = NaN(T+1,1);
    end
end

[S,CL]=logpdf_complete([x,y],copulatype,paramhat(2:end,:));
    
     
