function [paramhat] = bivariateCopula_Dyn_Patton(param,data,copulatype,past_u,theta_evolution)
%% bivariateCopula_Dyn_Patton: future value of the parameters of the model following the Patton dynamic
%
%% SYNTAX:
%        [paramhat] = bivariateCopula_Dyn_Patton(param,data,copulatype,past_u,theta_evolution)
%
%% INPUT:
%              param    =	parameters
%              data = u (tx2xW) from the forecast
%              copulatype =  Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90Joe'/'180Joe'/'270Joe'
%                           *'Clayton'/'90Clayton'/'180Clayton'/'270RClayton'
%                           *'Gumbel'/'90Gumbel'/'180Gumbel'/'270Gumbel'
%                           *'BB1'/'90BB1'/'180BB1'/'270BB1'
%                           *'BB2'/'90BB2'/'180BB2'/'270BB2'
%                           *'BB3'/'90BB3'/'180BB3'/'270BB3'
%                           *'BB4'/'90BB4'/'180BB4'/'270BB4'
%                           *'BB5'/'90BB5'/'180BB5'/'270BB5'
%                           *'BB6'/'90BB6'/'180BB6'/'270BB6'
%                           *'BB7'/'90BB7'/'180BB7'/'270BB7'
%                           *'SJC'/'90SJC'/'180SJC'/'270SJC'
%                           *'BB8'/'90BB8'/'180BB8'/'270BB8'
%                           *'Independence'
%               past_u: historical uniformly-distributed values, main input
%                   at the beginning of the forecast.
%               theta_evolution : parameters (tx1xW) or (tx2xW)
%% OUTPUT:
%               paramhat : values of the estimates at t+1
%% Javier Ojea Ferreiro 8/4/2021
%%
T = size(data,1);
W = size(data,3);
%%
if length(param)<=4
    omega=param(1);
    alpha=param(2);
    beta=param(3);
else
    omega(1,1)=param(1);
    alpha(1,1)=param(2);
    beta(1,1)=param(3);
    omega(1,2)=param(4);
    alpha(1,2)=param(5);
    beta(1,2)=param(6);
end
if  strcmp(copulatype,'Gaussian')
    x = norminv(data(:,1,:),0,1);
    y = norminv(data(:,2,:),0,1);
    x_past = norminv(past_u(:,1),0,1);
    y_past = norminv(past_u(:,2),0,1);
    rho=permute(theta_evolution(end,1,:),[1,3,2]);
    %1. Gaussian copula
        if T<=10
            psi = omega + alpha*permute(mean([[x(1:T,1,:).*y(1:T,1,:)];...
                permute([x_past(end-(10-T-1):end,1).*y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])]),[1,3,2]) + beta*rho;
        else
            psi = omega + alpha*permute(mean(x(T-9:T,1,:).*y(T-9:T,1,:)),[1,3,2]) + beta*rho;
        end
        paramhat = permute((1-exp(-psi))/(1+exp(-psi)),[1,3,2]);
elseif strcmp(copulatype,'Student')
    %2. Student copula
    nu=97.9/(1+exp(-param(end))) + 2.1;
    x = tinv(data(:,1,:),nu);
    y = tinv(data(:,2,:),nu);
    x_past = tinv(past_u(:,1),nu);
    y_past = tinv(past_u(:,2),nu);
    rho=permute(theta_evolution(end,1,:),[1,3,2]);
        if T<=10
              psi = omega + alpha*permute(mean([[x(1:T,1,:).*y(1:T,1,:)];...
                permute([x_past(end-(10-T-1):end,1).*y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])]),[1,3,2]) + beta*rho;
        else
            psi = omega + alpha*permute(mean(x(T-9:T,1,:).*y(T-9:T,1,:)),[1,3,2]) + beta*rho; 
        end
        paramhat = [permute((1-exp(-psi))./(1+exp(-psi)),[1,3,2]), permute(nu*ones(1,W),[1,3,2])];
else
    x = data(:,1,:);
    x_past = past_u(:,1);
    y = data(:,2,:);
    y_past = past_u(:,2);
    if strncmpi(copulatype,'90',2)
        x = 1-x;
        x_past = 1-x_past;
    end
    if strncmpi(copulatype,'180',3)
        x = 1-x;
        x_past = 1-x_past;
        y = 1-y;
        y_past = 1-y_past;
    end
    if strncmpi(copulatype,'270',3)
        y = 1-y;
        y_past = 1-y_past;
    end
    if strcmp(copulatype,'Frank') |strcmp(copulatype,'Plackett') | ...
            strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
            strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')|...
            strcmp(copulatype,'Clayton') |strcmp(copulatype,'90Clayton') | ...
            strcmp(copulatype,'180Clayton') |strcmp(copulatype,'270Clayton') | ...
            strcmp(copulatype,'Gumbel') | strcmp(copulatype,'90Gumbel')|...
            strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel')
        if strcmp(copulatype,'Frank')
            theta=permute(theta_evolution(end,1,:),[1,3,2]);
                if T<=10
                    psi=omega+beta*theta+alpha*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
                else
                    psi=omega+beta*theta+alpha*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
                end
                paramhat = permute(psi,[1,3,2]);
        elseif strcmp(copulatype,'Plackett')| strcmp(copulatype,'Clayton') |...
                strcmp(copulatype,'90Clayton') | strcmp(copulatype,'180Clayton') |...
                strcmp(copulatype,'270Clayton')
            theta=permute(theta_evolution(end,1,:),[1,3,2]);
            if T<=10
                psi=omega+beta*theta+alpha*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
            else
                psi=omega+beta*theta+alpha*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
            end
            paramhat = permute(100./(1+exp(-psi)),[1,3,2]);
        elseif strcmp(copulatype,'Gumbel') |  strcmp(copulatype,'90Gumbel')|...
                strcmp(copulatype,'180Gumbel') | strcmp(copulatype,'270Gumbel') |...
                strcmp(copulatype,'Joe') | strcmp(copulatype,'90Joe') | ...
                strcmp(copulatype,'180Joe')|strcmp(copulatype,'270Joe')
            theta=permute(theta_evolution(end,1,:),[1,3,2]);
            if T<=10
                psi=omega+beta*theta+alpha*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
            else
                psi=omega+beta*theta+alpha*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
            end
            paramhat = permute(99./(1+exp(-psi))+1,[1,3,2]);     
        end
    elseif strcmp(copulatype,'BB1')| strcmp(copulatype,'90BB1')|...
            strcmp(copulatype,'180BB1')|strcmp(copulatype,'270BB1')
        %8. BB1 copula
        theta=permute(theta_evolution(end,1,:),[1,3,2]);
        delta=permute(theta_evolution(end,2,:),[1,3,2]);
        tau_L=2.^(-1./(delta.*theta));
        tau_U=2-2.^(1./delta);
            if T<=10
                psi_L=omega(1,1)+beta(1,1)*tau_L+alpha(1,1)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
                psi_U=omega(1,2)+beta(1,2)*tau_U+alpha(1,2)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
            else
                psi_L=omega(1,1)+beta(1,1)*tau_L+...
                    alpha(1,1)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
                psi_U=omega(1,2)+beta(1,2)*tau_U+...
                    alpha(1,2)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
            end
            tau_L_new=(1+exp(-psi_L)).^(-1);
            tau_U_new=(1+exp(-psi_U)).^(-1);
        paramhat = [permute(-log2(2-tau_U_new)./log2(tau_L_new),[1,3,2]),...
            permute(1./log2(2-tau_U_new),[1,3,2])];
    elseif strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
            strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2') | ...
            strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
            strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
            strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
            strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5') | ...
            strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
            strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')  | ...
            strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') |...
            strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
        if strcmp(copulatype,'BB2') | strcmp(copulatype,'90BB2') | ...
                strcmp(copulatype,'180BB2') | strcmp(copulatype,'270BB2')
            function_theta=@(x) x;
            function_delta=@(x) 99./(1+exp(-x))+1;
        elseif strcmp(copulatype,'BB3') | strcmp(copulatype,'90BB3') | ...
                strcmp(copulatype,'180BB3') | strcmp(copulatype,'270BB3') | ...
                strcmp(copulatype,'BB5') | strcmp(copulatype,'90BB5') | ...
                strcmp(copulatype,'180BB5') | strcmp(copulatype,'270BB5')
            function_theta=@(x) 99./(1+exp(-x))+1;
            function_delta=@(x) 100./(1+exp(-x));
        elseif strcmp(copulatype,'BB6')  | strcmp(copulatype,'90BB6')  | ...
                strcmp(copulatype,'180BB6')  | strcmp(copulatype,'270BB6')
            function_theta=@(x) 99./(1+exp(-x))+1;
            function_delta=@(x) 99./(1+exp(-x))+1;
        elseif strcmp(copulatype,'BB8') | strcmp(copulatype,'90BB8') | ...
                strcmp(copulatype,'180BB8') | strcmp(copulatype,'270BB8')
            function_theta=@(x) 99./(1+exp(-x))+1;
            function_delta=@(x) 1./(1+exp(-x));
        end
        %%
        theta=permute(theta_evolution(end,1,:),[1,3,2]);
        delta=permute(theta_evolution(end,2,:),[1,3,2]);
            if T<=10
                psi_T=omega(1,1)+beta(1,1)*theta+...
                    alpha(1,1)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
                psi_D=omega(1,2)+beta(1,2)*delta+...
                    alpha(1,2)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
            else
                psi_T=omega(1,1)+beta(1,1)*theta+...
                    alpha(1,1)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
                psi_D=omega(1,2)+beta(1,2)*delta+...
                    alpha(1,2)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
            end
            paramhat=[permute(function_theta(psi_T),[1,3,2]),...
                permute(function_delta(psi_D),[1,3,2])];
    elseif strcmp(copulatype,'BB4') | strcmp(copulatype,'90BB4') |...
            strcmp(copulatype,'180BB4') | strcmp(copulatype,'270BB4')
        %11. BB4 copula
        theta=permute(theta_evolution(end,1,:),[1,3,2]);
        delta=permute(theta_evolution(end,2,:),[1,3,2]);
        tau_L=(2-2.^(-1./delta)).^(-1./theta);
        tau_U=2.^(-1./delta);
            if T<=10
                psi_L=omega(1,1)+beta(1,1)*tau_L+alpha(1,1)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
                psi_U=omega(1,2)+beta(1,2)*tau_U+alpha(1,2)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
            else
                psi_L=omega(1,1)+beta(1,1)*tau_L+...
                    alpha(1,1)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
                psi_U=omega(1,2)+beta(1,2)*tau_U+...
                    alpha(1,2)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
            end
            tau_L_new=(1+exp(-psi_L)).^(-1);
            tau_U_new=(1+exp(-psi_U)).^(-1);
            paramhat = [permute(-log(2-tau_U_new)./log(tau_L_new),[1,3,2]),...
            permute(-1./log2(tau_U_new),[1,3,2])];
    elseif strcmp(copulatype,'BB7') | strcmp(copulatype,'90BB7') |...
            strcmp(copulatype,'180BB7') | strcmp(copulatype,'270BB7') |...
            strcmp(copulatype,'SJC') | strcmp(copulatype,'90SJC') |...
            strcmp(copulatype,'180SJC') | strcmp(copulatype,'270SJC')
        theta=permute(theta_evolution(end,1,:),[1,3,2]);
        delta=permute(theta_evolution(end,2,:),[1,3,2]);
        tau_L=2.^(-1./delta);
        tau_U=2-2.^(-1./theta);
        if T<=10
                psi_L=omega(1,1)+beta(1,1)*tau_L+alpha(1,1)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
                psi_U=omega(1,2)+beta(1,2)*tau_U+alpha(1,2)*permute(mean(abs([[x(1:T,1,:)-y(1:T,1,:)];...
                    permute([x_past(end-(10-T-1):end,1)-y_past(end-(10-T-1):end,1)]*ones(1,W),[1,3,2])])),[1,3,2]);
            else
                psi_L=omega(1,1)+beta(1,1)*tau_L+...
                    alpha(1,1)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
                psi_U=omega(1,2)+beta(1,2)*tau_U+...
                    alpha(1,2)*permute(mean(abs(x(T-9:T,1,:)-y(T-9:T,1,:))),[1,3,2]);
            end
            tau_L_new=(1+exp(-psi_L)).^(-1);
            tau_U_new=(1+exp(-psi_U)).^(-1);
            paramhat = [permute(1./log2(2-tau_U_new),[1,3,2]),...
            permute(-1./log2(tau_L_new),[1,3,2])];
    elseif strcmp(copulatype,'Independence')
        paramhat = NaN(size(theta_evolution(end,:,:)));
    end
end

