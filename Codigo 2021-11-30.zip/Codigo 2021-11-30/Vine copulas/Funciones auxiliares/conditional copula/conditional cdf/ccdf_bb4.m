function q=ccdf_bb4(u1,u2,paramhat)
%% ccdf_bb4: Conditional bb4 copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_bb4(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameters theta and delta
%% OUTPUT:
%         q : Conditional distribution of the bb4 copula
%
%% Javier Ojea Ferreiro 20/06/2018
%% Updated : Javier Ojea Ferreiro 20/03/2021
theta=paramhat(:,1);
delta=paramhat(:,2);
x=(u1.^(-theta)-1).^(-delta);
y=(u2.^(-theta)-1).^(-delta);
q=(1+x.^(-1./delta)+y.^(-1./delta)-(x+y).^(-1./delta)).^(-1./theta-1).*...
    (x.^(-1./delta-1)-(x+y).^(-1./delta-1)).*...
    x.^(1+1./delta)./(u1.^(1+theta));