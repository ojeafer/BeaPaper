function q=ccdf_gumbel(u1,u2,paramhat)
%% ccdf_gumbel: Conditional gumbel copula cumulative distribution function
%% ccdf=dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        u=ccdf_gumbel(u1,u2,paramhat)
%
%% INPUT:
%        u1: quantile for the conditioning institution
%        u2:  quantile for the conditioned institution
%        paramhat :  parameter theta
%% OUTPUT:
%         q : Conditional distribution of the gumbel copula
%
%% Javier Ojea Ferreiro 20/06/2018
theta = paramhat(:,1);
q = exp(-((-log(u1)).^(theta)+(-log(u2)).^(theta)).^(1./theta)) .* ...
    ((-log(u1)).^(theta)+(-log(u2)).^(theta)).^(1./theta-1) .* ...
    (-log(u1)).^(theta-1) .* 1./u1;

% for t = 1:length(u1)
%     q(t) = exp(-((-log(u1(t))).^(theta(t))+(-log(u2(t))).^(theta(t))).^(1./theta(t))) .* ...
%     ((-log(u1(t))).^(theta(t))+(-log(u2(t))).^(theta(t))).^(1./theta(t)-1) .* ...
%     (-log(u1(t))).^(theta(t)-1) .* 1./u1(t);
% end
