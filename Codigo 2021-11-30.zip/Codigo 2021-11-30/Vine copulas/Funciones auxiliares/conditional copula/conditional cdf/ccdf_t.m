function q = ccdf_t(u1,u2,paramhat)
%% ccdf_t: Conditional t copula cumulative distribution function
%% ccdf = dC(u1,u2)/du1=P(U2<u2 | U1=u1)
%% SYNTAX:
%        q = ccdf_t(u1,u2,paramhat)
%
%% INPUTS:
%        u1: quantile for the conditioning institution
%        u2: quantile for the conditioned institution
%        paramhat: parameter rho from the t copula and number of degrees of freedom
%        
%% OUTPUT:
%        q: conditional distribution of the t copula
%
%% Javier Ojea Ferreiro 20/06/2018
u2=min(u2,1-1e-5);
u1=min(u1,1-1e-5);
u2=max(u2,1e-5);
u1=max(u1,1e-5);
%%
rho=paramhat(1,1);
nu=paramhat(1,2);
q=tcdf((sqrt((nu+1)./(nu+(tinv(u1,nu)).^2)).*(tinv(u2,nu)-rho.*tinv(u1,nu))./(sqrt(1-rho.^2))), nu+1);
% u2=tinv(rho*tinv(u1,nu)+sqrt(1-rho^2)*(nu+(tinv(u1))^2)/(nu+1)*tinv(q,nu+1),nu)
