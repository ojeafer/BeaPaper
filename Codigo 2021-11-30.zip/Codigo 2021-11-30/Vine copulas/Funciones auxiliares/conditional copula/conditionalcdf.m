function q=conditionalcdf(copulatype,paramhat,u1,u2,inverse)
%% conditionalcdf: conditional probability (q) of  variable u2 given a 
%%                 quantile of variable u1 , a type of copula and its parameter. 
%% if inverse==1 then conditionalcdf represents conditional probability (q) of  variable u1 given a 
%%                 quantile of variable u2 , a type of copula and its parameter. 
%% This is specially relevant for 90 and 270 degrees rotated copulas when we
%% have assymetric tail dependence
%% SYNTAX:
%        q=conditionalcdf(copulatype,paramhat,u1,u2,inverse)
%
%% INPUT:
%           copulatype = 
%                        Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%           theta : copula parameter
%           u1 : quantile of variable u1
%           u2 : value for u2 
%           inverse: by default 0, otherwise 1
%          
%% OUTPUT:
%               q: conditional probability of looking a value equal or
%               lower than u2 given u1
%% NOTES:
%C^{90R}(u1,u2)=u2-C(1-u1,u2)
% dC^{90R}(u1,u2)/du1=q-->C(u2|1-u1)=q
% dC^{90R}(u1,u2)/du2=q-->1-C(1-u1|u2)=q
%C^{180R}(u1,u2)=u1+u2-1+C(1-u1,1-u2)
% dC^{180R}(u1,u2)/du1=q-->1-C(1-u2|1-u1)=q
%C^{270R}(u1,u2)=u1-C(u1,1-u2)
% dC^{270R}(u1,u2)/du1=q-->1-C(1-u2|u1)=q
% [T,k]=size(u1);

if nargin==4
    inverse=0;
elseif nargin==5;
    if strcmpi('double',class(inverse))==0 | any(inverse==[0,1])==0
       inverse=1;
       warning('"inverse" must be zero or one, value set as one')
    end
end
switch copulatype
    case 'Gaussian'
        if inverse
            q=normcdf((norminv(u1)-paramhat.*norminv(u2))./sqrt(1-paramhat.^2));
        else
            q=normcdf((norminv(u2)-paramhat.*norminv(u1))./sqrt(1-paramhat.^2));
        end
    case 'Student'
        if max(size(paramhat))==2
            rho=paramhat(1);
            nu=paramhat(2);
        else
            rho=paramhat(:,1); nu=paramhat(:,2);
        end
         if inverse
             q=tcdf(sqrt((nu+1)./(nu+(tinv(u2,nu)).^2)).*(tinv(u1,nu)-rho.*tinv(u2,nu))./sqrt(1-rho.^2), nu+1);
         else
            q=tcdf(sqrt((nu+1)./(nu+(tinv(u1,nu)).^2)).*(tinv(u2,nu)-rho.*tinv(u1,nu))./sqrt(1-rho.^2), nu+1);
         end
        case 'Frank'
            if inverse
                q = ccdf_frank(u2,u1,paramhat);
            else
            q = ccdf_frank(u1,u2,paramhat);
            end
    case 'Plackett'
             if inverse
                q = ccdf_plackett(u2,u1,paramhat);
            else
        q = ccdf_plackett(u1,u2,paramhat);
             end
    case 'Joe'
          if inverse
                q = ccdf_joe(u2,u1,paramhat);
            else
        q = ccdf_joe(u1,u2,paramhat);
                     end
    case '90Joe'
        if inverse
            q = 1-ccdf_joe(u2,1-u1,paramhat);
        else
            q = ccdf_joe(1-u1,u2,paramhat);
        end
    case '180Joe'
        q = (1-ccdf_joe(1-u1,1-u2,paramhat));
    case '270Joe'
        if inverse
            q = ccdf_joe(1-u2,u1,paramhat);
        else
            q = (1-ccdf_joe(u1,1-u2,paramhat));
        end
    case 'Clayton'
        if inverse
            q = ccdf_clayton(u2,u1,paramhat);
        else
            q = ccdf_clayton(u1,u2,paramhat);
        end
    case '90Clayton'
        if inverse
            q = 1-ccdf_clayton(u2,1-u1,paramhat);
        else
            q = ccdf_clayton(1-u1,u2,paramhat);
        end
    case '180Clayton'
        q = (1-ccdf_clayton(1-u1,1-u2,paramhat));
    case '270Clayton'
        if inverse
            q = ccdf_clayton(1-u2,u1,paramhat);
        else
            q = (1-ccdf_clayton(u1,1-u2,paramhat));
        end
   case 'Gumbel'
        if inverse
            q = ccdf_gumbel(u2,u1,paramhat);
        else
            q = ccdf_gumbel(u1,u2,paramhat);
        end
   case '90Gumbel'
        if inverse
            q = 1-ccdf_gumbel(u2,1-u1,paramhat);
        else
            q = ccdf_gumbel(1-u1,u2,paramhat);
        end
    case '180Gumbel'
        q = (1-ccdf_gumbel(1-u1,1-u2,paramhat));
    case '270Gumbel'
        if inverse
            q = ccdf_gumbel(1-u2,u1,paramhat);
        else
            q = (1-ccdf_gumbel(u1,1-u2,paramhat));
        end
    case 'BB1'
         if inverse
            q = ccdf_bb1(u2,u1,paramhat);
        else
        q = ccdf_bb1(u1,u2,paramhat);
                       end
       
   case '90BB1'
        if inverse
            q = 1-ccdf_bb1(u2,1-u1,paramhat);
        else
            q = ccdf_bb1(1-u1,u2,paramhat);
        end
    case '180BB1'
        q = (1-ccdf_bb1(1-u1,1-u2,paramhat));
    case '270BB1'
        if inverse
            q = ccdf_bb1(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb1(u1,1-u2,paramhat));
        end
    case 'BB2'
         if inverse
            q = ccdf_bb2(u2,u1,paramhat);
        else
        q = ccdf_bb2(u1,u2,paramhat);
         end
   case '90BB2'
        if inverse
            q = 1-ccdf_bb2(u2,1-u1,paramhat);
        else
            q = ccdf_bb2(1-u1,u2,paramhat);
        end
    case '180BB2'
        q = (1-ccdf_bb2(1-u1,1-u2,paramhat));
    case '270BB2'
        if inverse
            q = ccdf_bb2(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb2(u1,1-u2,paramhat));
        end     
    case 'BB3'
             if inverse
            q = ccdf_bb3(u2,u1,paramhat);
        else
        q = ccdf_bb3(u1,u2,paramhat);
             end
   case '90BB3'
        if inverse
            q = 1-ccdf_bb3(u2,1-u1,paramhat);
        else
            q = ccdf_bb3(1-u1,u2,paramhat);
        end
    case '180BB3'
        q = (1-ccdf_bb3(1-u1,1-u2,paramhat));
    case '270BB3'
        if inverse
            q = ccdf_bb3(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb3(u1,1-u2,paramhat));
        end
    case 'BB4'
        q = ccdf_bb4(u1,u2,paramhat);
   case '90BB4'
        if inverse
            q = 1-ccdf_bb4(u2,1-u1,paramhat);
        else
            q = ccdf_bb4(1-u1,u2,paramhat);
        end
    case '180BB4'
        q = (1-ccdf_bb4(1-u1,1-u2,paramhat));
    case '270BB4'
        if inverse
            q = ccdf_bb4(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb4(u1,1-u2,paramhat));
        end  
    case 'BB5'
        q = ccdf_bb5(u1,u2,paramhat);
   case '90BB5'
        if inverse
            q = 1-ccdf_bb5(u2,1-u1,paramhat);
        else
            q = ccdf_bb5(1-u1,u2,paramhat);
        end
    case '180BB5'
        q = (1-ccdf_bb5(1-u1,1-u2,paramhat));
    case '270BB5'
        if inverse
            q = ccdf_bb5(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb5(u1,1-u2,paramhat));
        end
    case 'BB6'
        q = ccdf_bb6(u1,u2,paramhat);
   case '90BB6'
        if inverse
            q = 1-ccdf_bb6(u2,1-u1,paramhat);
        else
            q = ccdf_bb6(1-u1,u2,paramhat);
        end
    case '180BB6'
        q = (1-ccdf_bb6(1-u1,1-u2,paramhat));
    case '270BB6'
        if inverse
            q = ccdf_bb6(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb6(u1,1-u2,paramhat));
        end
    case 'BB7'
        q = ccdf_bb7(u1,u2,paramhat);
   case '90BB7'
        if inverse
            q = 1-ccdf_bb7(u2,1-u1,paramhat);
        else
            q = ccdf_bb7(1-u1,u2,paramhat);
        end
    case '180RBB7'
        q = (1-ccdf_bb7(1-u1,1-u2,paramhat));
    case '270BB7'
        if inverse
            q = ccdf_bb7(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb7(u1,1-u2,paramhat));
        end
    case 'SJC'
        q = ccdf_sjc(u1,u2,paramhat);
   case '90SJC'
        if inverse
            q = 1-ccdf_sjc(u2,1-u1,paramhat);
        else
            q = ccdf_sjc(1-u1,u2,paramhat);
        end
    case '180SJC'
        q = (1-ccdf_sjc(1-u1,1-u2,paramhat));
    case '270SJC'
        if inverse
            q = ccdf_sjc(1-u2,u1,paramhat);
        else
            q = (1-ccdf_sjc(u1,1-u2,paramhat));
        end
    case 'BB8'
        q = ccdf_bb8(u1,u2,paramhat);
   case '90BB8'
        if inverse
            q = 1-ccdf_bb8(u2,1-u1,paramhat);
        else
            q = ccdf_bb8(1-u1,u2,paramhat);
        end
    case '180BB8'
        q = (1-ccdf_bb8(1-u1,1-u2,paramhat));
    case '270BB8'
        if inverse
            q = ccdf_bb8(1-u2,u1,paramhat);
        else
            q = (1-ccdf_bb8(u1,1-u2,paramhat));
        end
    case 'Independence'
        q = u2;
end