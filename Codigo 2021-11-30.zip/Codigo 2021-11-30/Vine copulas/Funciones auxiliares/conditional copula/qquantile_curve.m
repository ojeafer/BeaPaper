function v=qquantile_curve(copulatype,paramhat,q,u,inverse)
%% qquantile_curve: q-quantile curve (u2) given a quantile of variable, (u1)
%%                      a conditional probability  (q), a type of copula and its parameter.
%% if inverse==1 then qquantile_curve q-quantile curve (u1) given a
%%                 quantile of variable u2 , a type of copula and its parameter.
%% C(u,v)
%% SYNTAX:
%        v = qquantile_curve(copulatype,paramhat,q,u,inverse)
%
%% INPUT:
%           copulatype =
%                        Types:
%                           *'Gaussian'
%                           *'Student'
%                           *'Frank'
%                           *'Plackett'
%                           *'Joe'/'90RJoe'/'180RJoe'/'270RJoe'
%                           *'Clayton'/'90RClayton'/'180RClayton'/'270RClayton'
%                           *'Gumbel'/'90RGumbel'/'180RGumbel'/'270RGumbel'
%                           *'BB1'/'90RBB1'/'180RBB1'/'270RBB1'
%                           *'BB2'/'90RBB2'/'180RBB2'/'270RBB2'
%                           *'BB3'/'90RBB3'/'180RBB3'/'270RBB3'
%                           *'BB4'/'90RBB4'/'180RBB4'/'270RBB4'
%                           *'BB5'/'90RBB5'/'180RBB5'/'270RBB5'
%                           *'BB6'/'90RBB6'/'180RBB6'/'270RBB6'
%                           *'BB7'/'90RBB7'/'180RBB7'/'270RBB7'
%                           *'SJC'/'90RSJC'/'180RSJC'/'270RSJC'
%                           *'BB8'/'90RBB8'/'180RBB8'/'270RBB8'
%                           *'Independence'
%           paramhat : copula parameter (theta)
%           q : conditional probability
%           u : quantile of variable u1
%           inverse: by default 0, otherwise 1
%% OUTPUT:
%               v: quantile of variable 2 that has a probability q
%               conditioned that variable 1 is at its u quantile, i.e.
%               q-quantile curve.
%% NOTES:
%C^{90R}(u1,u2)=u2-C(1-u1,u2)
% dC^{90R}(u1,u2)/du1=q-->C(u2|1-u1)=q
% dC^{90R}(u1,u2)/du2=q-->1-C(1-u1|u2)=q
%C^{180R}(u1,u2)=u1+u2-1+C(1-u1,1-u2)
% dC^{180R}(u1,u2)/du1=q-->1-C(1-u2|1-u1)=q
% dC^{180R}(u1,u2)/du2=q-->1-C(1-u1|1-u2)=q
%C^{270R}(u1,u2)=u1-C(u1,1-u2)
% dC^{270R}(u1,u2)/du1=q-->1-C(1-u2|u1)=q
% dC^{270R}(u1,u2)/du2=q-->C(u1|1-u2)=q
if nargin==4
    inverse=0;
elseif nargin==5
    if strcmpi('double',class(inverse))==0 | any(inverse==[0,1])==0
        inverse=1;
        warning('"inverse" must be zero or one, value set as one')
    end
end
switch copulatype
    case 'Gaussian'
        v=normcdf(norminv(q)*sqrt(1-paramhat.^2)+paramhat.*norminv(u));
    case 'Student'
        rho=paramhat(:,1); nu=paramhat(:,2);
        v=tcdf(rho.*tinv(u,nu)+sqrt(1-rho.^2).*(nu+(tinv(u,nu+1)).^2)/(nu+1).*tinv(q,nu+1),nu);
    case 'Frank'
        fun = @(x) ccdf_frank(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'Plackett'
        fun = @(x) ccdf_plackett(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'Joe'
        fun = @(x) ccdf_joe(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90Joe'
        if inverse
            fun = @(x) (1-ccdf_joe(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_joe(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180Joe'
        fun = @(x) (1-ccdf_joe(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270Joe'
        if inverse
            fun = @(x) ccdf_joe(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_joe(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'Clayton'
        %         fun = @(x) ccdf_clayton(u1,x,paramhat)-q;
        %         utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        %         u2=(1+exp(-utr)).^(-1);
        v=(1+u.^(-paramhat).*(q.^(-paramhat./(1+paramhat))-1)).^(-1./paramhat);
    case '90Clayton'
        if inverse
            fun = @(x) (1-ccdf_clayton(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_clayton(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180Clayton'
        fun = @(x) (1-ccdf_clayton(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270Clayton'
        if inverse
            fun = @(x) ccdf_clayton(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_clayton(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'Gumbel'
        fun = @(x) ccdf_gumbel(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90Gumbel'
        if inverse
            fun = @(x) (1-ccdf_gumbel(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_gumbel(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180Gumbel'
        fun = @(x) (1-ccdf_gumbel(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270Gumbel'
        if inverse
            fun = @(x) ccdf_gumbel(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_gumbel(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB1'
        fun = @(x) ccdf_bb1(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB1'
        if inverse
            fun = @(x) (1-ccdf_bb1(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb1(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB1'
        fun = @(x) (1-ccdf_bb1(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB1'
        if inverse
            fun = @(x) ccdf_bb1(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb1(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB2'
        fun = @(x) ccdf_bb2(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB2'
        if inverse
            fun = @(x) (1-ccdf_bb2(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb2(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB2'
        fun = @(x) (1-ccdf_bb2(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB2'
        if inverse
            fun = @(x) ccdf_bb2(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb2(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB3'
        fun = @(x) ccdf_bb3(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB3'
        if inverse
            fun = @(x) (1-ccdf_bb3(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb3(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB3'
        fun = @(x) (1-ccdf_bb3(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB3'
        if inverse
            fun = @(x) ccdf_bb3(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb3(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB4'
        fun = @(x) ccdf_bb4(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB4'
        if inverse
            fun = @(x) (1-ccdf_bb4(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb4(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB4'
        fun = @(x) (1-ccdf_bb4(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB4'
        if inverse
            fun = @(x) ccdf_bb4(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb4(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB5'
        fun = @(x) ccdf_bb5(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB5'
        if inverse
            fun = @(x) (1-ccdf_bb5(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb5(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB5'
        fun = @(x) (1-ccdf_bb5(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB5'
        if inverse
            fun = @(x) ccdf_bb5(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb5(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB6'
        fun = @(x) ccdf_bb6(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB6'
        if inverse
            fun = @(x) (1-ccdf_bb6(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb6(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB6'
        fun = @(x) (1-ccdf_bb6(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB6'
        if inverse
            fun = @(x) ccdf_bb6(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb6(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB7'
        fun = @(x) ccdf_bb7(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB7'
        if inverse
            fun = @(x) (1-ccdf_bb7(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb7(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB7'
        fun = @(x) (1-ccdf_bb7(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB7'
        if inverse
            fun = @(x) ccdf_bb7(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb7(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'SJC'
        fun = @(x) ccdf_sjc(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90SJC'
        if inverse
            fun = @(x) (1-ccdf_sjc(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_sjc(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180SJC'
        fun = @(x) (1-ccdf_sjc(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270SJC'
        if inverse
            fun = @(x) ccdf_sjc(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_sjc(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'BB8'
        fun = @(x) ccdf_bb8(u,x,paramhat)-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '90BB8'
        if inverse
            fun = @(x) (1-ccdf_bb8(u,1-x,paramhat))-q;
        else
            fun = @(x) ccdf_bb8(1-u,x,paramhat)-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '180BB8'
        fun = @(x) (1-ccdf_bb8(1-u,1-x,paramhat))-q;
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case '270BB8'
        if inverse
            fun = @(x) ccdf_bb8(1-u,x,paramhat)-q;
        else
            fun = @(x) (1-ccdf_bb8(u,1-x,paramhat))-q;
        end
        utr=fzero(@(utr0)fun((1+exp(-utr0))^(-1)),-log(1/q-1));
        v=(1+exp(-utr)).^(-1);
    case 'Independence'
        v = q;
end