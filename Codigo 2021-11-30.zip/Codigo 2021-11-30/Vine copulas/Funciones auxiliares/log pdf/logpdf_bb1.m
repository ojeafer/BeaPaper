function [S,CL]=logpdf_bb1(x,y,paramhat)
%% logpdf_bb1: Log pdf for the bb1 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb1(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
T=length(x);
theta = paramhat(:,1);
delta=paramhat(:,2);
a=x.^(-theta)-ones(T,1);
b=y.^(-theta)-ones(T,1);
c=a.^delta+b.^delta;
d=(1+c.^(ones(T,1)./delta));

CL=(-theta-ones(T,1)).*log(x.*y);
% CL=CL+(delta-ones(T,1)).*log(a);
CL=CL+(delta-ones(T,1)).*log(a+eps);
% CL=CL+(delta-ones(T,1)).*log(b);
CL=CL+(delta-ones(T,1)).*log(b+eps);
% CL= CL +(ones(T,1)./delta-ones(T,1)*2).*log(c);
CL= CL +(ones(T,1)./delta-ones(T,1)*2).*log(c+eps);
CL=CL+(-ones(T,1)./theta-ones(T,1)).*log(d);
CL=CL+log(d.^(-ones(T,1)).*c.^(ones(T,1)./delta).*(ones(T,1)+theta)+(delta-ones(T,1)).*theta);

S=-sum(CL);
%
if isreal(paramhat)==0;
   S = 1e6;
   CL=0;
elseif isreal(S)==0;
   S = 1e6;
   CL=0;
elseif isnan(S)
   S = 1e6;
   CL=0;
elseif isinf(S)
   S = 1e6;
   CL=0;
end