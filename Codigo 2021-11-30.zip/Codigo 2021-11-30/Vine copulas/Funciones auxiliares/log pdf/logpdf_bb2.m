function [S,CL]=logpdf_bb2(x,y,paramhat)
%% logpdf_bb2: Log pdf for the bb2 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb2(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
%
x_exp=exp(delta.*(x.^(-theta)-1));
y_exp=exp(delta.*(y.^(-theta)-1));
B=x_exp+y_exp-1;
A=1+1./delta.*log(B);
CL=log(x_exp)+log(y_exp)-(theta+1).*log(x.*y)-2.*log(B)-(1./theta+2).*log(A)+log(1+theta+theta.*delta.*A);
S=-sum(CL);

if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
elseif any(any([exp(delta.*(0.01.^(-theta)-1))+exp(delta.*(0.01.^(-theta)-1))<1,...
        exp(delta.*(0.01.^(-theta)-1))+exp(delta.*(0.5.^(-theta)-1))<1,...
        exp(delta.*(0.01.^(-theta)-1))+exp(delta.*(0.99.^(-theta)-1))<1,...
        exp(delta.*(0.99.^(-theta)-1))+exp(delta.*(0.5.^(-theta)-1))<1,...
        exp(delta.*(0.99.^(-theta)-1))+exp(delta.*(0.99.^(-theta)-1))<1])) % to assess later the CoVaR
    S=1e6;
end
