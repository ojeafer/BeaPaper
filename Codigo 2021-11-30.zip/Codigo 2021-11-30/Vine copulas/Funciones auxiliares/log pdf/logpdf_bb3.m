function [S,CL]=logpdf_bb3(x,y,paramhat)
%% logpdf_bb3: Log pdf for the bb3 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb3(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
%
x_hat=-log(x); y_hat=-log(y);
x_exp=exp(delta.*x_hat.^theta);
y_exp=exp(delta.*y_hat.^theta);
A=x_exp+y_exp-1;
CL=log(x_exp)+log(y_exp)+(theta-1).*log(x_hat.*y_hat)-log(x.*y)-(delta.^(-1).*log(A)).^(1./theta)-2.*log(A);
CL=CL+(1./theta-2).*log(delta.^(-1).*log(A))+log((delta.^(-1).*log(A)).^(1./theta)+(theta-1)+theta.*log(A));
S=-sum(CL);


if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
elseif any(any([(exp(delta.*(-log(0.01)).^theta)+exp(delta.*(-log(0.01)).^theta)<1),...
        (exp(delta.*(-log(0.01)).^theta)+exp(delta.*(-log(0.5)).^theta)<1),...
        (exp(delta.*(-log(0.01)).^theta)+exp(delta.*(-log(0.99)).^theta)<1),...
        (exp(delta.*(-log(0.99)).^theta)+exp(delta.*(-log(0.5)).^theta)<1),...
        (exp(delta.*(-log(0.99)).^theta)+exp(delta.*(-log(0.99)).^theta)<1)]))% to assess later the CoVaR
   S = 1e6;
end