function [S,CL]=logpdf_bb4(x,y,paramhat)
%% logpdf_bb4: Log pdf for the bb4 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb4(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
%
B=(x.^(-theta)-1).^(-delta)+(y.^(-theta)-1).^(-delta); 
A=(x.^(-theta)+y.^(-theta)-1-B.^(-1./delta));
CL=(-1./theta-2).*log(A)-(theta+1).*log(x.*y)-(delta+1).*log((x.^(-theta)-1).*(y.^(-theta)-1));
CL=CL+log((1+theta).*((x.^(-theta)-1).^(delta+1)-B.^(-1./delta-1)).*((y.^(-theta)-1).^(delta+1)-B.^(-1./delta-1))+(1+delta).*theta.*A.*B.^(-1./delta-2));
S=-sum(CL);
if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end
