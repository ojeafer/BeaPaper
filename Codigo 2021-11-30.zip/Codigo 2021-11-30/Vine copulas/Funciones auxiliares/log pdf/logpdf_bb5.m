function [S,CL]=logpdf_bb5(x,y,paramhat)
%% logpdf_bb5: Log pdf for the bb5 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb5(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
x_hat=-log(x); y_hat=-log(y);
%
B1=x_hat.^(theta-1)-x_hat.^(-theta.*delta-1).*((x_hat.^(-theta.*delta)+y_hat.^(-theta.*delta)).^(-1./delta-1));
B2=y_hat.^(theta-1)-y_hat.^(-theta.*delta-1).*((x_hat.^(-theta.*delta)+y_hat.^(-theta.*delta)).^(-1./delta-1));
A=x_hat.^theta+y_hat.^theta-((x_hat.^(-theta.*delta)+y_hat.^(-theta.*delta)).^(-1./delta));
B=B1.*B2.*(A.^(1./theta)+(theta-1));
C=A.*(x_hat.*y_hat).^(-theta.*delta-1).*theta.*(1+delta).*(x_hat.^(-theta.*delta)+y_hat.^(-theta.*delta)).^(-1./delta-2);
CL=(1./theta-2).*log(A)-A.^(1./theta)-log(x.*y)+log(B+C);
S=-sum(CL);
%
if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end

