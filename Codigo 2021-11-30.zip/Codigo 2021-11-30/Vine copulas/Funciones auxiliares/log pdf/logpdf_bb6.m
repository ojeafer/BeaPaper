function [S,CL]=logpdf_bb6(x,y,paramhat)
%% logpdf_bb6: Log pdf for the bb6 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb6(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
x_bar=1-x;
y_bar=1-y;
A=(-log(1-x_bar.^theta));
B=(-log(1-y_bar.^theta));
CL=(delta-1).*log(A.*B)+(theta-1).*log(x_bar.*y_bar)-log(1-x_bar.^theta);
CL=CL-log(1-y_bar.^theta)-(A.^delta+B.^delta).^(1./delta);
CL=CL+(1./theta-2).*log(1-exp(-(A.^delta+B.^delta).^(1./delta)))+(1./delta-2).*log(A.^delta+B.^delta);
CL=CL+log((A.^delta+B.^delta).^(1./delta).*(theta-exp(-(A.^delta+B.^delta).^(1./delta)))+(1-exp(-(A.^delta+B.^delta).^(1./delta))).*theta.*(delta-1));
S=-sum(CL);
%
if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end