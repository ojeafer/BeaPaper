function [S,CL]=logpdf_bb7(x,y,paramhat)
%% logpdf_bb7: Log pdf for the bb7 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb7(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
%%
T=length(x);
T_1_1=1-(1-x).^(theta);
T_1_2=1-(1-y).^(theta);
T_2_1=(1-x).^(theta-1);
T_2_2=(1-y).^(theta-1);
L_1=T_1_1.^(-delta)+T_1_2.^(-delta)-1;
CL=-(1+delta).*log(T_1_1.*T_1_2);
CL=CL+log(T_2_1)+log(T_2_2);
CL=CL-2*(1+delta)./delta.*log(L_1);
CL=CL+(ones(T,1)./theta-2).*log(1-L_1.^(-ones(T,1)./delta));
CL=CL+log((1+delta).*theta.*L_1.^(ones(T,1)./delta)-theta.*delta-1);
S=-sum(CL);
%
if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end