function [S,CL]=logpdf_bb8(x,y,paramhat)
%% logpdf_bb8: Log pdf for the bb8 distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_bb8(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 19/07/2018
theta = paramhat(:,1);
delta=paramhat(:,2);
%%

A=(1-delta.*x);
B=(1-delta.*y);
D=(1-A.^(theta)).*(1-B.^(theta))./(1-(1-delta).^(theta));
CL=log(delta)+(1./theta-2).*log(1-D)+(theta-1).*log(A.*B)-log(1-(1-delta).^(theta))+log(theta-D);
S=-sum(CL);
%
if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end