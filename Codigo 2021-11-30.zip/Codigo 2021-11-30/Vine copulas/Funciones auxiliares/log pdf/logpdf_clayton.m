function [S,CL]=logpdf_clayton(x,y,paramhat)
%% logpdf_clayton: Log pdf for the clayton distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_clayton(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
thetahat = paramhat;
 [T,~]=size(y);
if size(thetahat,1)<T;
    thetahat=ones(T,1)*thetahat;
%     if size(x,1)<T
%         x=ones(T,1)*x
%     end
end
% if size(thetahat,2)<n;
%     thetahat=thetahat*ones(1,n);
% end

for t=1:T
%     for k=1:n
    if thetahat(t,1)>1e-5;
        CL(t,:) = log(x(t,:).*y(t,:)).*(-1-thetahat(t,:));
        CL(t,:) = CL(t,:) - (2+1/thetahat(t,:)).*log((x(t,:).^(-thetahat(t,:)))...
            + (y(t,:).^(-thetahat(t,:))) -1);
        CL(t,:) = log(1+thetahat(t,:)) + CL(t,:);
    else
        CL(t,:) = 0;  % under independence the copula pdf=1, so the log-likelihood=0
    end
%     end
end
S = -sum(CL);
%
if isreal(paramhat)==0;
   S = 1e6;
    CL=0;
elseif isreal(S)==0;
   S = 1e6;
    CL=0;
elseif isnan(S)
   S = 1e6;
    CL=0;
elseif isinf(S)
   S = 1e6;
    CL=0;
end