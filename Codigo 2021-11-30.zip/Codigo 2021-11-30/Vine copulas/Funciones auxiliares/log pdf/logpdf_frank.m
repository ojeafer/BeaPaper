function [S,CL]=logpdf_frank(x,y,paramhat)
%% logpdf_frank: Log pdf for the frank distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_frank(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               paramhat = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta= paramhat;
eta=1-exp(-theta);
CL=log(theta)+log(eta)-theta.*(x+y);
CL = CL-2*log(eta - (1-exp(-theta.*x)).*(1-exp(-theta.*y)));
S = -sum(CL);

if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end