function [S,CL]=logpdf_gumbel(x,y,paramhat)
%% logpdf_gumbel: Log pdf for the gumbel distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_gumbel(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
theta = paramhat;
xhat = -log(x);
yhat = -log(y);

CL = log(gumbel_cdf(x,y,theta)) - log(x) - log(y);
CL = CL + (theta-1).*(log(xhat)+log(yhat)) - (2-1./theta).*(log(xhat.^theta+yhat.^theta));
CL = CL + log((xhat.^theta + yhat.^theta).^(1./theta) + theta - 1);
S = -sum(CL);

if isreal(paramhat)==0;
   S = 1e6;
   CL=0;
elseif isreal(S)==0;
   S = 1e6;
   CL=0;
elseif isnan(S)
   S = 1e6;
   CL=0;
elseif isinf(S)
   S = 1e6;
   CL=0;
end