function [S,CL]=logpdf_joe(x,y,paramhat)
%% logpdf_joe: Log pdf for the joe distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_joe(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
thetahat = paramhat;
A=(1-x);
B=(1-y);
CL=(1./thetahat-2).*log(A.^thetahat+B.^thetahat-(A.*B).^thetahat)+(thetahat-1).*log(A.*B);
CL=CL+log(thetahat.*(A.^thetahat+B.^thetahat-(A.*B).^thetahat)+(thetahat-1).*(1-B.^thetahat).*(1-A.^thetahat));
S=-sum(CL);if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end