function [S,CL]=logpdf_plackett(x,y,paramhat)
%% logpdf_plackett: Log pdf for the plackett distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_plackett(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               theta = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
thetahat = paramhat;
CL = plackett_pdf(x,y,thetahat);
CL = log(CL);
S = -sum(CL);
if isreal(paramhat)==0;
   S = 1e6;
elseif isreal(S)==0;
   S = 1e6;
elseif isnan(S)
   S = 1e6;
elseif isinf(S)
   S = 1e6;
end