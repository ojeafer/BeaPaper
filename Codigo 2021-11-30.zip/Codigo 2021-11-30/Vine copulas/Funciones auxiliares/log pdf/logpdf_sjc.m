function [S,CL]=logpdf_sjc(x,y,paramhat)
%% logpdf_sjc: Log pdf for the sjc distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_sjc(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               paramhat = copula parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 19/07/2018
tau_l=2.^(-1/paramhat(:,2));
tau_u=2-2.^(1/paramhat(:,1));
CL = sym_jc_pdf(x,y,tau_l,tau_u);
CL = log(CL);
S = -sum(CL);
%
if isnan(S)
   S = 1e6;
end
if isreal(S)==0
   S = 1e6;
end
if isreal(paramhat)==0
   S = 1e8;
end
