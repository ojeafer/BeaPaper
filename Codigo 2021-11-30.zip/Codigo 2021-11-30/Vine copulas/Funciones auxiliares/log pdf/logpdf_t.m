function [S,CL]=logpdf_t(x,y,paramhat)
%% logpdf_t: Log pdf for the t distribution
%
%% SYNTAX:
%        [S,CL]=logpdf_t(x,y,paramhat)
%
%% INPUT:
%               x, y = vectors of length T
%               paramhat = correlation parameter of length T
%% OUTPUT:
%                S = minus log-likelihood
%                CL   = sample size
%%
%Javier Ojea Ferreiro 25/04/2018
nu=paramhat(:,2);
rho=paramhat(:,1);
[T,k]=size(x);
if size(nu,1)<T
    nu=ones(T,1)*nu;
end
if size(nu,2)<k
    nu=nu*ones(1,k);
end
if size(rho,1)<T
    rho=ones(T,1)*rho;
end
if size(rho,2)<k
    rho=rho*ones(1,k);
end
CL = gammaln((nu+2)/2) + gammaln(nu/2) - 2*gammaln((nu+1)/2) - 0.5*log(1-rho.^2);
CL = CL - (nu+2)./2 .* log(1+(x.^2 + y.^2 - 2*rho.*x.*y)./(nu.*(1-rho.^2)));
CL = CL + (nu+1)./2 .* (log(1+x.^2./nu) + log(1+y.^2./nu));
S = -sum(CL);
if isreal(paramhat)==0
   S = 1e6;
   CL=0;
elseif isreal(S)==0
   S = 1e6;
   CL=0;
elseif isnan(S)
   S = 1e6;
   CL=0;
elseif isinf(S)
   S = 1e6;
   CL=0;
end