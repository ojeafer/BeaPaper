function [LL,output]=JointDependence_CVine(param,data,copulaeset,dynamic)
%% JointDependence_CVine: Dependence between variables following a CVine 
%% SYNTAX: [LL,output]=JointDependence_CVine(param,data,copulaeset,dynamic)
%
%% INPUT:
%               param : estimated parameter vector
%               data : uniform data [TxN]
%               copulaset : Set of copulas employed to model the
%               relationship between variables:
%                       *1st row --> data_order(1) -- data_1 
%                                   (relación de la 1a variable y la 2a variable)
%                       *2nd row --> data_order(1) -- data_2
%                                   (relación de la 1a variable y la 3a variable)
%                           ...
%                       *(N-1)th row --> data_order(1) -- data_N
%                       *Nth row --> data_order(2) -- data_1 |data_order(1)
%                                   (relacion de la 2a variable con la 3a condicionada a la 1a)
%                        
%               dynamic: a vector with zeros and ones indicating if the
%               copula between a couple of variables is constant (zero) or
%               evolves over time (one) following Pattons specification
%% OUTPUT:
%              LL : minus maximum loglikelihood value
%              output : results of the model
%
%%%%%%%%%%%%%%%%%%%%%% Check the info structure %%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check the number of inputs arguments
if nargin==3
    dynamic=zeros(size(copulaeset));
    warning('Constant copula structure is assumed')
elseif nargin<3
    error('You must provide at least the data, the dependence structure of the data and the parameters')
end
% Check the consistency of the inputs introduced
[N_link,~]=size(copulaeset); % Number of levels of the vine
[N_link_dyn,~]=size(dynamic);
if (N_link~=N_link_dyn)
    error('The copula inputs do not match, please check the input structure')
end
% Get the number of parameters in the model
for ii = 1:N_link
        if  strcmp(copulaeset{ii},'Gaussian')| strcmp(copulaeset{ii},'Frank')|...
                strcmp(copulaeset{ii},'Plackett')| strcmp(copulaeset{ii},'Joe')|...
                strcmp(copulaeset{ii},'90Joe')| strcmp(copulaeset{ii},'180Joe')|...
                strcmp(copulaeset{ii},'270Joe')|strcmp(copulaeset{ii},'Clayton')|...
                strcmp(copulaeset{ii},'90Clayton')|strcmp(copulaeset{ii},'180Clayton')|...
                strcmp(copulaeset{ii},'270Clayton')|strcmp(copulaeset{ii},'Gumbel')|...
                strcmp(copulaeset{ii},'90Gumbel')|strcmp(copulaeset{ii},'180Gumbel')|...
                strcmp(copulaeset{ii},'270Gumbel')
            n_param_cop(ii+1) = 1+2*dynamic(ii);
        elseif strcmp(copulaeset{ii},'BB1')|...
                strcmp(copulaeset{ii},'90BB1')|strcmp(copulaeset{ii},'180BB1')|...
                strcmp(copulaeset{ii},'270BB1')|strcmp(copulaeset{ii},'BB2')|...
                strcmp(copulaeset{ii},'90BB2')|strcmp(copulaeset{ii},'180BB2')|...
                strcmp(copulaeset{ii},'270BB2')|strcmp(copulaeset{ii},'BB3')|...
                strcmp(copulaeset{ii},'90BB3')|strcmp(copulaeset{ii},'180BB3')|...
                strcmp(copulaeset{ii},'270BB3')|strcmp(copulaeset{ii},'BB4')|...
                strcmp(copulaeset{ii},'90BB4')|strcmp(copulaeset{ii},'180BB4')|...
                strcmp(copulaeset{ii},'270BB4')|strcmp(copulaeset{ii},'BB5')|...
                strcmp(copulaeset{ii},'90BB5')|strcmp(copulaeset{ii},'180BB5')|...
                strcmp(copulaeset{ii},'270BB5')|strcmp(copulaeset{ii},'BB6')|...
                strcmp(copulaeset{ii},'90BB6')|strcmp(copulaeset{ii},'180BB6')|...
                strcmp(copulaeset{ii},'270BB6')|strcmp(copulaeset{ii},'BB7')|...
                strcmp(copulaeset{ii},'90BB7')|strcmp(copulaeset{ii},'180BB7')|...
                strcmp(copulaeset{ii},'270BB7')|strcmp(copulaeset{ii},'SJC')|...
                strcmp(copulaeset{ii},'90SJC')|strcmp(copulaeset{ii},'180SJC')|...
                strcmp(copulaeset{ii},'270SJC')|strcmp(copulaeset{ii},'BB8')|...
                strcmp(copulaeset{ii},'90BB8')|strcmp(copulaeset{ii},'180BB8')|...
                strcmp(copulaeset{ii},'270BB8')
            n_param_cop(ii+1) = 2+4*dynamic(ii);
        elseif strcmp(copulaeset{ii},'Student')
                n_param_cop(ii+1) = 2+2*dynamic(ii);
        else
            n_param_cop(ii+1) = 0;
        end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute the density function
[f_c,theta,uu] = CVine_pdf(param,data,copulaeset,n_param_cop,dynamic);
ff=0;
for ii=1:N_link
    ff=ff+f_c{ii,1}; % Sum of the loglikelihood of all pair-copulas of the vine structure
end
%
if isinf(sum(ff))
    LL = 1.0e6;
else
    LL = -sum(ff); 
end
output.theta = theta;
output.uu = uu;
output.n_param = n_param_cop;
output.CL = ff;
output.logL_pc = f_c;
end