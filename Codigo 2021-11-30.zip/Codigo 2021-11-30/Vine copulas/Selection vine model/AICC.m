function [aicc,AICC_best,Name_best,dynamic_best] = AICC(logL,T,k,copula_name,n_opt)
%% AICC: Akaike Information Criterion corrected for small sample bias
%
%% SYNTAX:
%         [aicc,AICC_best,Name_best,dynamic_best]=AICC(logL,T,k,copula_name,n_opt)
%
%% INPUT:
%               logL: minus log-likelihood value (N_copulas x N_assets)
%               T: sample size
%               k: number of estimated parameters
%               copula_name: name of the copula
%               n_opt: number of optimal models to obtain
%
%% OUTPUT:
%               aicc: aicc value
%               AICC_best: best copula for modeling data (row)
%               Name_best: best copula (name)
%               dynamic_best: best dynamic (zero or one)
%
%%
%Javier Ojea Ferreiro 25/04/2018
%% References
% Brechmann, E., & Schepsmeier, U. (2013). Cdvine: Modeling dependence with c-and d-vine copulas in r. Journal of Statistical Software, 52(3), 1-27.
% Reboredo, Juan C. & Ugolini, Andrea, 2015. "A vine-copula conditional value-at-risk approach to systemic sovereign debt risk for the financial sector," The North American Journal of Economics and Finance, Elsevier, vol. 32(C), pages 98-123.
% Reboredo, Juan C. & Ugolini, Andrea, 2015. "Downside/upside price spillovers between precious metals: A vine copula approach," The North American Journal of Economics and Finance, Elsevier, vol. 34(C), pages 84-102.
% Reboredo, Juan C. & Ugolini, Andrea, 2016. "Quantile dependence of oil price movements and stock returns," Energy Economics, Elsevier, vol. 54(C), pages 33-49.
%
%%
if  nargin==4
    n_opt = 1;
end
[~,N_assets] = size(logL);
aicc = 2.*k.*(T./(T-k-1)).*ones(1,N_assets) + 2.*logL;  
% equiv aicc = aic + (2*k.*(k+1))./(T-k-1); where aic = 2*k - 2*ln(L)
    % https://besjournals.onlinelibrary.wiley.com/doi/epdf/10.1111/2041-210X.12541

for i = 1:N_assets
    aicc_sort_soe = sort(aicc(:,i));
    for j = 1:n_opt
        AICC_best1(:,j,i) = find(aicc(:,i)==aicc_sort_soe(j));
        AICC_best(j,i) = AICC_best1(1,j,i);
        Name_best(j) = copula_name(AICC_best(j,i));
        
        if rem(AICC_best(j,i),2) == 0 % if AICC_best(j,i)/2 = 0 -> AICC_best es par
            dynamic_best(j) = 1;
        else 
            dynamic_best(j) = 0;
        end
    end
end