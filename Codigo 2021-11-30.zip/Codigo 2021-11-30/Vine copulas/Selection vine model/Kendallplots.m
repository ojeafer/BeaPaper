function [Win,H_hat]=Kendallplots(U)
%% Kendallplots: x-axis and y-axis for the kendall-plot
%
%% SYNTAX:
%        [Win,H_hat]=Kendallplots(U)
%
%% INPUT:
%              U = data (Tx2)
%% OUTPUT:
%               Win : x-axis
%               H_hat : y-axis
%%
%Javier Ojea Ferreiro 26/04/2018
%% References
% Brechmann, E., & Schepsmeier, U. (2013). Cdvine: Modeling dependence with c-and d-vine copulas in r. Journal of Statistical Software, 52(3), 1-27.
% Genest, C., & Favre, A. C. (2007). Everything you always wanted to know about copula modeling but were afraid to ask. Journal of hydrologic engineering, 12(4), 347-368.
% Abberger, K. (2004). A simple graphical method to explore tail-dependence in stock-return pairs. Discussion Paper, University of Konstanz, Germany.
% https://github.com/tnagler/VineCopula/blob/master/R/BiCopChiPlot.R
%%

T=length(U);
%
for t=1:T
h=0;
    for tt=1:T
        if t==tt
        else
            indicator=U(t,:)>U(tt,:);
            if all(indicator==ones(1,2))
                h=h+1;
            end
        end
    end
    Hi(1,t)=h/(T-1);
end
[H_hat,H_order]=sort(Hi);
Wi=(Hi.*(T-1)+1)./T;
for t=1:T
    warning('off','all')
    KK=@(w) w.*(-log(w)).*(w-w.*log(w)).^(t-1).*(1-w+w.*log(w)).^(T-t);
    Win(t)=T*nchoosek(T-1,t-1).*integral(@(x)KK(x),0,1);
end
%
% W=1e3;
% w_perfdep=rand(W,1);
% w_perfdep=[w_perfdep,w_perfdep];
% for j=1:W
%     h=0;
%     for tt=1:W
%         if j==tt
%         else
%             indicator=w_perfdep(j,:)>w_perfdep(tt,:);
%             if all(indicator==ones(1,2))
%                 h=h+1;
%             end
%         end
%     end
%     Hpd(1,j)=h/(W-1);
% end
% [Hpd_hat,Hpd_order]=sort(Hpd);
% for j=1:W
%     warning('off','all')
%     KK=@(w) w.*(-log(w)).*(w-w.*log(w)).^(j-1).*(1-w+w.*log(w)).^(W-j);
%     Wpd(j)=W*nchoosek(W-1,j-1).*integral(@(x)KK(x),0,1);
% end
% scatter(Win,H_hat,'.')
% hold on
% plot(Wpd,Hpd_hat,'k')
% plot([0,1],[0,1],'k')
