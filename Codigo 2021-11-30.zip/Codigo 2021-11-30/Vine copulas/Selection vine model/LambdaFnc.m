function [Lambda]=LambdaFnc(v,Type,info)
%% LambdaFnc: Lambda-Function
%
%% SYNTAX:
%        lambda=LambdaFnc(v,Type,info)
%
%% INPUT:
%              v = one of the parameter of the lambda-function
%              Type = Copula
%              ('Gaussian','Student','Clayton','Gumbel','BB1', 'Empirical')
%               info = either the parameter of the copula (for the
%               parametric copulas) or the 2-column matrix of uniform
%               values
%% OUTPUT:
%               Lambda = the lambda-function output
%                        the 5-th percentile and the 95-th
%                        and the independence lambda-function
%% Reference:
% Brechmann and Schepsmeier (2013), page 11
% Schepsmeier (2010)
if strcmpi(Type,'Empirical')
    U=info;
%     [u_1,u_2]=meshgrid(U(:,1),U(:,2));
%     U_v=[u_1(:),u_2(:)];
    N=length(U);
%     for j=1:length(U_v)
%         V(j,1)=sum(all(U<=U_v(j,:),2))./(N-1);
%     end
%     for jj=1:length(v)
%         lambda(jj,1)=v(jj)-sum(V<=v(jj))/length(U_v);
%     end
   for j=1:N
        V(j,1)=sum(all(U<=U(j,:),2))./(N+1);
    end
    for jj=1:length(v)
        lambda(jj,1)=v(jj)-sum(V<=v(jj))/N;
    end
elseif strcmpi(Type,'Gaussian')
    rho = info;
    u = linspace(0,1,1000);
    [u1,u2] = meshgrid(u,u);
    U=copulacdf('Gaussian',[u1(:),u2(:)],rho);
    for k=1:length(v)
          lambda(k,1)=v(k)-sum(U<v(k))/(length(U));
    end
elseif strcmpi(Type,'Student')
    rho = info(1);
    nu = info(2);
    u = linspace(0,1,100);
    [u1,u2] = meshgrid(u,u);
    U=copulacdf('t',[u1(:),u2(:)],rho,nu);
    for k=1:length(v)
          lambda(k,1)=v(k)-sum(U<v(k))/(length(U));
    end
elseif strcmpi(Type,'Clayton')
    theta = info;
    lambda = (-v.*(1-v.^theta)./theta)';
elseif strcmpi(Type,'Gumbel')
    theta = info;
    lambda = (v.*log(v)./theta)';
elseif strcmpi(Type,'BB1')
    theta = info(1);
    delta = info(2);
    lambda = (-1./(theta.*delta).*(v.^(-theta)-1)./(v.^(-1-theta)))';
    
end
         Lambda= lambda;
