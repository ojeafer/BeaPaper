function qC=TailConcentrationFnc(t,type,info)
%% Tail concentration function
%
%% SYNTAX:
%        qC=TailConcentrationFnc(t,type,info)
%
%% INPUT:
%              t = input for the copula (scalar or column vector)
%              Type = Copula
%              ('Gaussian','Student','Clayton','Gumbel','BB1', 'Empirical')
%               info = either the parameter of the copula (for the
%               parametric copulas) or the 2-column matrix of uniform
%               values
%% OUTPUT:
%               qC = Tail concentration function
%% Reference:
% A Graphical Tool for Copula Selection Based on Tail Dependence (2018)
%%
if strcmpi(type,'Gaussian')
    rho=info;
    qC=copulacdf('Gaussian',[t,t],rho)./t.*(t<=0.5)+...
       (1-2.*t+copulacdf('Gaussian',[t,t],rho))./(1-t).* (t>0.5);
elseif strcmpi(type,'Student')
    rho=info(1);
    nu=info(2);
        qC=copulacdf('t',[t,t],rho,nu)./t.*(t<=0.5)+...
       (1-2.*t+copulacdf('t',[t,t],rho,nu))./(1-t).* (t>0.5);
elseif strcmpi(type,'Clayton')
    theta=info;
       qC=clayton_cdf(t,t,theta)./t.*(t<=0.5)+...
       (1-2.*t+clayton_cdf(t,t,theta))./(1-t).*(t>0.5);
elseif strcmpi(type,'Gumbel')
    theta=info;
       qC=gumbel_cdf(t,t,theta)./t.*(t<=0.5)+...
       (1-2.*t+gumbel_cdf(t,t,theta))./(1-t).*(t>0.5);
elseif strcmpi(type,'BB1')
    theta=info(1);
    delta=info(2);
            qC=BB1_cdf(t,t,theta,delta)./t.*(t<=0.5)+...
       (1-2.*t+BB1_cdf(t,t,theta,delta))./(1-t).*(t>0.5);
elseif strcmpi(type,'Empirical')
%     U=info;N=length(U);
    N=length(info);
    for i=1:2
        for tt=1:length(info)
            U(tt,i)=sum(info(:,i)<info(tt,i))./(N+1);
        end
    end
    for kk=1:length(t)
      qC(kk,1)=(sum(all(U<t(kk),2))/N)./t(kk).*(t(kk)<=0.5)+...
       (sum(all(U>t(kk),2))/N)./(1-t(kk)).*(t(kk)>0.5);
    end
end

    