function [lambda_valid,Chi_valid]=chiplots(U)
%% chiplots: x-axis and y-axis for the chi-plot
%
%% SYNTAX:
%        [lambda_valid,Chi_valid]=chiplots(U)
%
%% INPUT:
%              U = data (Tx2)
%% OUTPUT:
%               lambda_valid : x-axis
%               Chi_valid : y-axis
%%
%Javier Ojea Ferreiro 25/04/2018
%% References
% Brechmann, E., & Schepsmeier, U. (2013). Cdvine: Modeling dependence with c-and d-vine copulas in r. Journal of Statistical Software, 52(3), 1-27.
% Genest, C., & Favre, A. C. (2007). Everything you always wanted to know about copula modeling but were afraid to ask. Journal of hydrologic engineering, 12(4), 347-368.
% Abberger, K. (2004). A simple graphical method to explore tail-dependence in stock-return pairs. Discussion Paper, University of Konstanz, Germany.


T=length(U);
%
for t=1:T
h=0;
f=0;
g=0;
    for tt=1:T
        if t==tt
        else
            indicator=U(t,:)>U(tt,:);
            if all(indicator==ones(1,2))
                h=h+1;
                f=f+1;
                g=g+1;
            elseif all(indicator==[1,0])
                f=f+1;
            elseif all(indicator==[0,1])
                g=g+1;
            end
        end
    end
    H(1,t)=h/(T-1);
    F(1,t)=f/(T-1);
    G(1,t)=g/(T-1);
end
%%
Chi=(H-F.*G)./sqrt(F.*(1-F).*G.*(1-G));
%%
F_hat=F-1/2;
G_hat=G-1/2;
lambda=4*sign(F_hat.*G_hat).*max(F_hat.^2,G_hat.^2);
lambda_valid=  lambda(abs(lambda)<=4*(1/(T-1)-1/2).^2);
Chi_valid=Chi(abs(lambda)<=4*(1/(T-1)-1/2).^2);
% % scatter(lambda_valid,Chi_valid,'+')
% % xlim([-1,1])
% % xlabel('$\lambda_t$','FontSize',12,'Interpreter','LateX')
% % ylim([-1,1])
% % ylabel('$\chi_t$','FontSize',12,'Interpreter','LateX')
% % hold on
% % c95=1.78;
% % c99=2.18;
% % plot([-1,1],c95/sqrt(T)*ones(1,2),'r')
% % plot([-1,1],-c95/sqrt(T)*ones(1,2),'r')
% % plot([-1,1],c99/sqrt(T)*ones(1,2),'m')
% % plot([-1,1],-c99/sqrt(T)*ones(1,2),'m')

end