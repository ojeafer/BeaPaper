clear all
clc

load('Main_Japan') 

%%
options = optimset('Display','Iter','MaxFunEvals',1.0e5,'MaxIter',1.0e5,'TolFun',1.0e-8,'TolX',1.0e-8);

TT = min(length(u_fx), min(length(u_st),length(u_gold)));
data_comp = [u_fx(end-TT+1:end), u_st(end-TT+1:end), u_gold(end-TT+1:end)]; % the first column will be the conditioning variable
copulas = {'Gaussian', 'Student',   'Gumbel', '90Gumbel', ...
           'Clayton',  '90Clayton', 'BB1',    '90BB1'};
nu_ini = 8.0;
bb1_ini = [0.01, 0.01];

N_link = size(data_comp,2);

%%      
tic
for ii = N_link
    if ii == 1
        data = data_comp(:,1:2);
    elseif ii == 2
        data = [data_comp(:,1), data_comp(:,3)];
    elseif ii == N_link
        data = data_comp;
    end
    
    if ii < N_link % Pair-copulas of first level
        for i1 = 1:length(copulas)  
        % FIRST STEP: find the optimal parameters for constant copula
            if strcmp(copulas{i1},'Gaussian') 
                param0pc = corr(norminv(data(:,1)),norminv(data(:,2))); 
                param0pc = -log((1-param0pc)/(1+param0pc));
            elseif strcmp(copulas{i1},'Student') 
                param0pc(1) = corr(tinv(data(:,1),nu_ini),tinv(data(:,2),nu_ini));
                param0pc(1) = -log((1-param0pc(1))/(1+param0pc(1)));
                param0pc(2) = -log(97.9/(nu_ini-2.1)-1);  
            elseif strcmp(copulas{i1},'Gumbel') 
                param0pc = copulafit('Gumbel',[data(:,1),data(:,2)]);
                param0pc = -log(99/(param0pc-1) - 1);
            elseif strcmp(copulas{i1},'90Gumbel') 
                param0pc = copulafit('Gumbel',[1-data(:,1),data(:,2)]);
                param0pc = -log(99/(param0pc-1) - 1);
            elseif strcmp(copulas{i1},'Clayton') 
                param0pc = copulafit('Clayton',[data(:,1),data(:,2)]);
                param0pc = -log(100/param0pc - 1);
            elseif strcmp(copulas{i1},'90Clayton')
                param0pc = copulafit('Clayton',[1-data(:,1),data(:,2)]);
                param0pc = -log(100/param0pc - 1);
            elseif strcmp(copulas{i1},'BB1') | strcmp(copulas{i1},'90BB1')
                param0pc(1) = -log(1/bb1_ini(1) - 1);
                param0pc(2) = -log(1/bb1_ini(2) - 1);
            elseif strcmp(copulas{i1},'Independence')
                param0pc = 0;
            end

            param1pc{ii,1+2*(i1-1)} = ...
                fminsearch('JointDependence_CVine',param0pc,options,data,{copulas{i1}},0);

            % Output of the copula with the optimal parameters
            [LLF_vine(ii,1+2*(i1-1)),output_pc{ii,1+2*(i1-1)}] = ...
                    JointDependence_CVine(param1pc{ii,1+2*(i1-1)},data,{copulas{i1}},0);
                
            output_pc{ii,1+2*(i1-1)}.LLF = LLF_vine(ii,1+2*(i1-1));
            n_param(ii,1+2*(i1-1)) = size(param1pc{ii,1+2*(i1-1)},2);            
            copula_name{1+2*(i1-1)} = sprintf('%s_constant',copulas{i1});
            copula_name{1+2*(i1-1)}
         
            
        % SECOND STEP: find the optimal parameters for copula with Patton dynamics
            if strcmp(copulas{i1},'Student')
                param00pc = [param1pc{ii,1+2*(i1-1)}(1),0,0,param1pc{ii,1+2*(i1-1)}(2)];
            elseif strcmp(copulas{i1},'BB1') | strcmp(copulas{i1},'90BB1')
                param00pc = [param1pc{ii,1+2*(i1-1)}(1),0,0, param1pc{ii,1+2*(i1-1)}(1),0,0];
            elseif strcmp(copulas{i1},'Independence')
                param00pc = [param1pc{ii,1+2*(i1-1)}(1),1,1]
            else
                param00pc = [param1pc{ii,1+2*(i1-1)}(1),0,0];
            end
            
            param1pc{ii,2*i1} = ...
                fminsearch('JointDependence_CVine',param00pc,options,data,{copulas{i1}},1);            
            
            % Output of the copula with the optimal parameters
            [LLF_vine(ii,2*i1),output_pc{ii,2*i1}] = ...
                    JointDependence_CVine(param1pc{ii,2*i1},data,{copulas{i1}},1);
                
            output_pc{ii,2*i1}.LLF = LLF_vine(ii,2*i1);
            n_param(ii,2*i1) = length(param1pc{ii,2*i1});
            copula_name{2*i1} = sprintf('%s_time_varying',copulas{i1});
            copula_name{2*i1}
        end    

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    else % if ii == N_link (% Pair-copula of second level)
        for i1 = 1:length(copulas)  
            for j = 1:(N_link-1) % Redefine the name of the best copula models
                if strcmp(Name_best{1,j}{1,1},'Gaussian_constant') | strcmp(Name_best{1,j}{1,1},'Gaussian_time_varying')
                    copula_best{j} = 'Gaussian';
                elseif strcmp(Name_best{1,j}{1,1},'Student_constant') | strcmp(Name_best{1,j}{1,1},'Student_time_varying')
                    copula_best{j} = 'Student';
                elseif strcmp(Name_best{1,j}{1,1},'Gumbel_constant') | strcmp(Name_best{1,j}{1,1},'Gumbel_time_varying')
                    copula_best{j} = 'Gumbel';
                elseif strcmp(Name_best{1,j}{1,1},'90Gumbel_constant') | strcmp(Name_best{1,j}{1,1},'90Gumbel_time_varying')
                    copula_best{j} = '90Gumbel';
                elseif strcmp(Name_best{1,j}{1,1},'Clayton_constant') | strcmp(Name_best{1,j}{1,1},'Clayton_time_varying')
                    copula_best{j} = 'Clayton';
                elseif strcmp(Name_best{1,j}{1,1},'90Clayton_constant') | strcmp(Name_best{1,j}{1,1},'90Clayton_time_varying')
                    copula_best{j} = '90Clayton';
                elseif strcmp(Name_best{1,j}{1,1},'BB1_constant') | strcmp(Name_best{1,j}{1,1},'BB1_time_varying')
                    copula_best{j} = 'BB1';
                elseif strcmp(Name_best{1,j}{1,1},'90BB1_constant') | strcmp(Name_best{1,j}{1,1},'90BB1_time_varying')
                    copula_best{j} = '90BB1';
                elseif strcmp(Name_best{1,j}{1,1},'Independence_constant') | strcmp(Name_best{1,j}{1,1},'Independence_time_varying')
                    copula_best{j} = 'Independence';
                else
                    disp('error defining Name_best')
                end
            end

            copulas_vine = [copula_best'; copulas{i1}];
            
            % FIRST STEP: find the optimal parameters for constant copula
            dynamics = [dynamic_best(1:2,1); 0];
                
            % Initial seed for the model
            param0_1 = optim_model.params{1,1};
            param0_2 = optim_model.params{1,2};
           
            if strcmp(copulas{i1},'Gaussian') 
                param0_3 = corr(norminv(data(:,2)),norminv(data(:,3))); 
                param0_3 = -log((1-param0_3)/(1+param0_3));
            elseif strcmp(copulas{i1},'Student') 
                param0_3(1) = corr(tinv(data(:,2),nu_ini),tinv(data(:,3),nu_ini)); 
                param0_3(1) = -log((1-param0_3(1))/(1+param0_3(1)));
                param0_3(2) = -log(97.9/(nu_ini-2.1) - 1);  
            elseif strcmp(copulas{i1},'Gumbel') 
                param0_3 = copulafit('Gumbel',[data(:,2),data(:,3)]);
                param0_3 = -log(99/(param0_3-1) - 1);
            elseif strcmp(copulas{i1},'90Gumbel') 
                param0_3 = copulafit('Gumbel',[1-data(:,2),data(:,3)]);
                param0_3 = -log(99/(param0_3-1) - 1);
            elseif strcmp(copulas{i1},'Clayton') 
                param0_3 = copulafit('Clayton',[data(:,2),data(:,3)]);
                param0_3 = -log(100/param0_3 - 1);
            elseif strcmp(copulas{i1},'90Clayton')
                param0_3 = copulafit('Clayton',[1-data(:,2),data(:,3)]);
                param0_3 = -log(100/param0_3 - 1);
            elseif strcmp(copulas{i1},'BB1') | strcmp(copulas{i1},'90BB1')
                param0_3(1) = -log(1/bb1_ini(1) - 1);
                param0_3(2) = -log(1/bb1_ini(2) - 1);
            elseif strcmp(copulas{i1},'Independence')
                param0pc_3 = 0;
            end

            param0 = [param0_1, param0_2, param0_3];

            param1{1+2*(i1-1)} = ...
                fminsearch('JointDependence_CVine',param0,options,data,copulas_vine,dynamics);
            
            % Output of the copula with the optimal parameters
            [LLF_vine(ii,1+2*(i1-1)),output_pc{ii,1+2*(i1-1)}] = ...
                    JointDependence_CVine(param1{1+2*(i1-1)},data,copulas_vine,dynamics);
            
            output_pc{ii,1+2*(i1-1)}.LLF = LLF_vine(ii,1+2*(i1-1));
            n_param(ii,1+2*(i1-1)) = length(param1{1+2*(i1-1)});
            copula_name2{1+2*(i1-1)} = sprintf('%s_constant',copulas{i1})
        
            
            % SECOND STEP: find the optimal parameters for copula with Patton dynamics 
            dynamicsP = [dynamic_best(1:2,1); 1];
            
            param00_1 = param0_1;
            param00_2 = param0_2;
            
            if strcmp(copulas{i1},'Student')
                param00_3 = [param1{1+2*(i1-1)}(1,end-1),0,0,param1{1+2*(i1-1)}(1,end)];
                param00_3(4) = max(param00_3(4), -log(97.9/(10-2.1)-1));
            elseif strcmp(copulas{i1},'BB1') | strcmp(copulas{i1},'90BB1')
                param00_3 = [param1{1+2*(i1-1)}(1,end-1),0,0, param1{1+2*(i1-1)}(1,end),0,0];
            else
                param00_3 = [param1{1+2*(i1-1)}(1,end),0,0];
            end
            
            param00 = [param00_1, param00_2, param00_3];

            param1{2*i1} = ...
                fminsearch('JointDependence_CVine',param00,options,data,copulas_vine,dynamicsP);
            
            % Output of the copula with the optimal parameters
            [LLF_vine(ii,2*i1),output_pc{ii,2*i1}] = ...
                    JointDependence_CVine(param1{2*i1},data,copulas_vine,dynamicsP);
             
            output_pc{ii,2*i1}.LLF = LLF_vine(ii,2*i1);
            n_param(ii,2*i1) = length(param1{2*i1}); 
            copula_name2{2*i1} = sprintf('%s_time_varying',copulas{i1})
            
        end                          
    end

    
    % THIRD STEP: Select the best model
    if ii < N_link
        [aicc(ii,:),AICC_best(:,ii),Name_best{ii},dynamic_best(ii,:)] = ...
               AICC(LLF_vine(ii,:)',size(data,1),n_param(ii,:)',copula_name,3);
        param_vine_opt{ii} = param1pc{ii,AICC_best(1,ii)};
    else
        [aicc(ii,:),AICC_best(:,ii),Name_best{ii},dynamic_best(ii,:)] = ...
               AICC(LLF_vine(ii,:)',size(data,1),n_param(ii,:)',copula_name2,3);
        param_vine_opt{ii} = param1{AICC_best(1,ii)};
    end
    
    optim_model.Names{ii} = Name_best{ii};
    optim_model.Dynamics{ii} = dynamic_best(ii,:);
    optim_model.AICC_best{ii} = AICC_best(:,ii);
    optim_model.AICc_best_value{ii} = aicc(ii,AICC_best(1,ii));
    optim_model.params{ii} = param_vine_opt{ii};
    optim_model.LLF_vine_best{ii} = LLF_vine(ii,AICC_best(1,ii));

end
toc
%%
optim_model.copula_best = copula_best;


% For the best vine-copula model
if strcmp(Name_best{1,3}{1,1},'Gaussian_constant') | strcmp(Name_best{1,3}{1,1},'Gaussian_time_varying')
    optim_model.copula_best{1,3} = 'Gaussian';
elseif strcmp(Name_best{1,3}{1,1},'Student_constant') | strcmp(Name_best{1,3}{1,1},'Student_time_varying')
    optim_model.copula_best{1,3} = 'Student';
elseif strcmp(Name_best{1,3}{1,1},'Gumbel_constant') | strcmp(Name_best{1,3}{1,1},'Gumbel_time_varying')
    optim_model.copula_best{1,3} = 'Gumbel';
elseif strcmp(Name_best{1,3}{1,1},'90Gumbel_constant') | strcmp(Name_best{1,3}{1,1},'90Gumbel_time_varying')
    optim_model.copula_best{1,3} = '90Gumbel';
elseif strcmp(Name_best{1,3}{1,1},'Clayton_constant') | strcmp(Name_best{1,3}{1,1},'Clayton_time_varying')
    optim_model.copula_best{1,3} = 'Clayton';
elseif strcmp(Name_best{1,3}{1,1},'90Clayton_constant') | strcmp(Name_best{1,3}{1,1},'90Clayton_time_varying')
    optim_model.copula_best{1,3} = '90Clayton';
elseif strcmp(Name_best{1,3}{1,1},'BB1_constant') | strcmp(Name_best{1,3}{1,1},'BB1_time_varying')
    optim_model.copula_best{1,3} = 'BB1';
elseif strcmp(Name_best{1,3}{1,1},'90BB1_constant') | strcmp(Name_best{1,3}{1,1},'90BB1_time_varying')
    optim_model.copula_best{1,3} = '90BB1';
end

param_opt0 = optim_model.params{1,3};
dynamic_opt = [optim_model.Dynamics{1,1}(1); optim_model.Dynamics{1,2}(1); optim_model.Dynamics{1,3}(1)];
copula_opt = optim_model.copula_best;

[LLF_vine_best,output_best] = JointDependence_CVine(param_opt0,data_comp,copula_opt',dynamic_opt(:,1));
    output_best.LLF = LLF_vine_best;


%%
save('Vines_Japan_nuevo2', 'data_comp','datewt2','aicc','LLF_vine','n_param','Name_best',...
     'param1pc','param1','output_pc','optim_model','output_best','T2','r_fx','r_st','r_gold', ...
     'returns','params_fx','params_st','params_gold','P','Q','u_fx','u_st','u_gold',...
     'mu_fx','mu_st','mu_gold','sigma2_fx','sigma2_st','sigma2_gold','-v7.3')
   

%% Plots
copula_names = {optim_model.copula_best{1,1}, ...
                optim_model.copula_best{1,2}, ...
                optim_model.copula_best{1,3}};
dynamics = [optim_model.Dynamics{1,1}(1); optim_model.Dynamics{1,2}(1); optim_model.Dynamics{1,3}(1)];
createfigure_theta_vine(datewt2, output_best.theta{1,1}(2:end,1), ...
                        output_best.theta{1,2}(2:end,1),...
                        output_best.theta{1,3}(2:end,1), ...
                        copula_names, dynamics, 'Japan')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% theta12 = output_best.theta{1,1}(:,1);
% delta12 = output_best.theta{1,1}(:,2);
% 
% tau_L12 = 2.^(-1./(theta12.*delta12));
% tau_U12 = 2 - 2.^(1./delta12);

%
theta13 = output_best.theta{1,3}(:,1);
delta13 = output_best.theta{1,3}(:,2);

tau_L13 = 2.^(-1./(theta13.*delta13));
tau_U13 = 2 - 2.^(1./delta13);


% Plot
copula_names = {optim_model.copula_best{1,1}, ...
                optim_model.copula_best{1,1}, ...
                optim_model.copula_best{1,3}};
dynamics = [optim_model.Dynamics{1,1}(1); optim_model.Dynamics{1,2}(1); optim_model.Dynamics{1,3}(1)];
createfigure_theta_vine(datewt2, output_best.theta{1,1}(2:end,1), ...
                                 output_best.theta{1,2}(2:end,1), ...
                                 [tau_L13(2:end),tau_U13(2:end)],...
                                 copula_names, dynamics, 'Japan')
