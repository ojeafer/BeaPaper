function [LL,output]=model_SM2_Vine(paramtr,data,swarchtype,errortype,p,q,copulaeset)
%% estmargSM2tr: ARMA(P,Q) model considering heteroscedasticity assessment under Switching Markov model with two states (H of hierarchical strcuture)
%% SYNTAX
% [LL,u,mu,sigma2,xitt,xit1t,P_SM]=estmargSM2tr(paramtr,data,swarchtype,errortype,p,q,copula)
%% INPUT:
%               paramtr : trasnformed parameters
%               data : input
%               swarchtype: 'Cai'/'HS'/'HSL'
%               errortype :
%               'N'/'t'/'St'/'tN'/'StN'
%               (Gaussian [N] in the low-volatility regime)
%               p : lags for the AR model
%               q : lags for the MA model
%               copulaset : cell {3x1} for
%                           oil-currency link
%                           stock-currency link
%                           stock-oil|currency link
%               
%% OUTPUT:
%              LL : minus maximum loglikelihood value
%              u : cumulative distribution function of the data
%              mu : conditional mean given by the ARMA(P,Q) model
%              sigma2 : conditional variance
%              xitt : inference probability
%              xit1t : forecast probability
%              stdresid : standardized residual of the model
%              P : Markov Chain
%              param : original parameters
%%
np = length(p(p~=0));                         %   lags in AR model
nq = length(q(q~=0));                         %   lags in MA model
% number of parameters
if strcmpi(swarchtype,'Cai')|strcmpi(swarchtype,'HS')
    n_swarch = 3;
elseif strcmpi(swarchtype,'HSL')
    n_swarch = 4;
end
if strcmp(errortype,'t') | strcmp(errortype,'tN')
    n_dist = 1;
elseif strcmp(errortype,'St') | strcmp(errortype,'StN')
    n_dist = 2;
else
    n_dist = 0;
end
%getting the format
n_param=1+np+nq+n_swarch+n_dist;
n_asset=3;
for i_asset=1:n_asset
    paramtr0(:,i_asset)=paramtr(1+n_param*(i_asset-1):n_param*i_asset);
end
%undo the trasnformation
param0(1+np+nq,:) = (1-exp(-paramtr0(1+np+nq,:)))./(1+exp(-paramtr0(1+np+nq,:)));
switch swarchtype
    case 'Cai'
        param_swarch=[exp(paramtr0(1+np+nq+1,:));...    %kappa (level)
            exp(paramtr0(1+np+nq+2,:));...                  %alpha_0
            1./(1+exp(-paramtr0(1+np+nq+3,:)))];             %alpha_1
    case 'HS'
        param_swarch=[ exp(paramtr0(1+np+nq+1,:))+1;...  %kappa (scale)
            exp(paramtr0(1+np+nq+2,:));...                  %alpha_0
            1./(1+exp(-paramtr0(1+np+nq+3,:)))];             %alpha_1
    case 'HSL'
        param_swarch=[ exp(paramtr(1+np+nq+1,:))+1;...  %kappa (scale)
            exp(paramtr(1+np+nq+2,:));...                  %alpha_0
            1./(1+exp(-paramtr0(1+np+nq+3,:)));...           %alpha_1
            1./(1+exp(-paramtr0(1+np+nq+4,:)))];             %gamma
end
param0=[param0;param_swarch];
if strcmp(errortype,'t') | strcmp(errortype,'tN')
    param0(1+np+nq+n_swarch+1,:) = 97.9./(1+exp(-paramtr0(1+np+nq+n_swarch+1,:)))+2.1;
elseif strcmp(errortype,'St') | strcmp(errortype,'StN')
    param0(1+np+nq+n_swarch+1,:) = 97.9./(1+exp(-paramtr0(1+np+nq+n_swarch+1,:)))+2.1;
    param0(1+np+nq+n_swarch+2,:) = (1-exp(-paramtr0(1+nq+nq+n_swarch+2,:)))./...
        (1+exp(-paramtr0(1+np+nq+n_swarch+2,:)));
end
%Marginal model
for i_asset=1:n_asset
    [f_i,u_i,mu_i,sigma2_i,errors_i] = arma_swarch(param0(:,i_asset), data(:,i_asset), swarchtype, errortype, p, q);
    f(:,i_asset,1) = f_i(:,1);
    f(:,i_asset,2) = f_i(:,2);
    u(:,i_asset,1) = u_i(:,1);
    u(:,i_asset,2) = u_i(:,2);
    sigma2(:,i_asset,1) = sigma2_i(:,1);
    sigma2(:,i_asset,2) = sigma2_i(:,2);
    mu(:,i_asset) = mu_i;
    errors(:,i_asset) = errors_i;
    clear f_i u_i mu_i sigma2_i errors_i
end
%Copula model
copulaparamtr=paramtr(n_param*n_asset+1:end-2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Running copula models
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    n_param_cop(1,1)=0;
for ii = 1 : length(copulaeset)
       pp = sum(n_param_cop(1:ii,1));
    %First copula
    if  strcmp(copulaeset{ii,1},'Gaussian')
        %1. Gaussian copula --> -1<rho<1
        n_param_cop(ii+1,1) = 1*2;
        %         copuparam01tr=-log((1-copuparam01)./(1+copuparam01));
        copulaparam0(pp+1:pp+2,1) = ...
            (1-exp(-copulaparamtr(pp+1:pp+2,1)))./...
            (1+exp(-copulaparamtr(pp+1:pp+2,1)));
    elseif strcmp(copulaeset{ii,1},'Student')
        %2. Student copula--> -1<rho<1 ; 2.1<nu<100
        n_param_cop(ii+1,1) = 2*2;
        copulaparam0([1+pp,3+pp],1) = (1-exp(-copulaparamtr([1+pp,3+pp],1)))./(1+exp(-copulaparamtr([1+pp,3+pp],1)));
        copulaparam0([2+pp,4+pp],1) = 97.9./(1+exp(-copulaparamtr([2+pp,4+pp],1)))+2.1;
        %         copuparam01tr(1)=-log((1-copuparam01(1))./(1+copuparam01(1)));
    elseif strcmp(copulaeset{ii,1},'Clayton') |strcmp(copulaeset{ii,1},'90Clayton') | ...
            strcmp(copulaeset{ii,1},'Gumbel') | strcmp(copulaeset{ii,1},'90Gumbel')
        if strcmp(copulaeset{ii,1},'Clayton') |...
                strcmp(copulaeset{ii,1},'90Clayton') %0<theta<100
            n_param_cop(ii+1,1) = 1*2;
            copulaparam0(1+pp:2+pp) = 100./(1+exp(-copulaparamtr(1+pp:2+pp)));
            %             copuparam01tr=-log(100./copuparam01-1);
        elseif strcmp(copulaeset{ii,1},'Gumbel') |...
                strcmp(copulaeset{ii,1},'90Gumbel')   %1<theta<100
            n_param_cop(ii+1,1) = 1*2;
            copulaparam0(1+pp:2+pp) = 99./(1+exp(-copulaparamtr(1+pp:2+pp)))+1;
            %             copuparam01tr=-log(99./(copuparam01-1)-1);
        end
    elseif strcmp(copulaeset{ii,1},'BB1') | strcmp(copulaeset{ii,1},'90BB1')
        %         copuparam01tr(1)=-log(1./copuparam01(1)-1);
        %         copuparam01tr(2)=-log(1./copuparam01(2)-1);
        n_param_cop(ii+1,1) = 2*2;
        copulaparam0(1+pp:4+pp,1)=1./(1+exp(-copulaparamtr(1+pp:4+pp)));
    end
    if ii==1 %oil-currency
     [~, paramhat,CL] = biv_LogLike(copulaparam0(1+pp:pp+n_param_cop(ii+1,1)/2),[u(:,1,1),u(:,2,1)],copulaeset{ii,1});
     f_cop(:,ii,1) = exp(CL);
     phat{1,1} = paramhat(2:end);
     clear paramhat CL
     [~, paramhat,CL] = biv_LogLike(copulaparam0(1+pp+n_param_cop(ii+1,1)/2:pp+n_param_cop(ii+1,1)),[u(:,1,2),u(:,2,2)],copulaeset{ii,1});
     f_cop(:,ii,2) = exp(CL);
     phat{1,2}= paramhat(2:end);
     clear paramhat CL
    elseif ii==2 %currency-stock
     [~, paramhat,CL] = biv_LogLike(copulaparam0(1+pp:pp+n_param_cop(ii+1,1)/2),[u(:,2,1),u(:,3,1)],copulaeset{ii,1});
     f_cop(:,ii,1) = exp(CL);
     phat{2,1} = paramhat(2:end); 
     clear paramhat CL
    [~, paramhat,CL] = biv_LogLike(copulaparam0(1+pp+n_param_cop(ii+1,1)/2:pp+n_param_cop(ii+1,1)),[u(:,2,2),u(:,3,2)],copulaeset{ii,1});
    f_cop(:,ii,2) = exp(CL);
    phat{2,2}= paramhat(2:end); 
    clear paramhat CL
    elseif ii==3
    uc(:,1,1)=conditionalcdf(copulaeset{1,1},...
            phat{1,1},u(:,2,1),u(:,1,1));
    uc(:,2,1)=conditionalcdf(copulaeset{2,1},...
            phat{2,1},u(:,2,1),u(:,3,1));
    uc(:,1,2)=conditionalcdf(copulaeset{1,1},...
            phat{1,2},u(:,2,2),u(:,1,2));
    uc(:,2,2)=conditionalcdf(copulaeset{2,1},...
            phat{2,2},u(:,2,2),u(:,3,2));
     [~, paramhat,CL] = biv_LogLike(copulaparam0(1+pp:pp+n_param_cop(ii+1,1)/2),[uc(:,1,1),uc(:,2,1)],copulaeset{ii,1});
     f_cop(:,ii,1) = exp(CL);
     phat{3,1} = paramhat(2:end);
     clear paramhat CL
     [~, paramhat,CL] = biv_LogLike(copulaparam0(1+pp+n_param_cop(ii+1,1)/2:pp+n_param_cop(ii+1,1)),[uc(:,1,2),uc(:,2,2)],copulaeset{ii,1});
     f_cop(:,ii,2) = exp(CL);
     phat{3,2} = paramhat(2:end);
     clear paramhat CL
    end
end
n_state=2;
for i_state=1:n_state
    ff(:,i_state)=f(:,1,i_state).*f(:,2,i_state).*f(:,3,i_state).* f_cop(:,1,i_state).*f_cop(:,2,i_state).*f_cop(:,3,i_state);
end
T= length(ff);
p11=1./(1+exp(-paramtr(end-1)));
p22=1./(1+exp(-paramtr(end)));
P=[p11,1-p22;1-p11,p22];
A=[eye(n_state)-P; ones(1,n_state)];
eN1=[zeros(n_state,1);
    1];
ppi=inv(A'*A)*A'*eN1;
xi10=ppi';
xitt=zeros(T,n_state);
xit1t=zeros(T,n_state);
for t=1:T
    xitt(t,:)=(xi10.*ff(t,:))/((xi10.*ff(t,:))*ones(n_state,1));
    xit1t(t,:)=xitt(t,:)*P';
    xi10=xit1t(t,:);
end
xit1t=[xi10;xit1t];
fver=(xit1t(1:T,:).*ff)*ones(n_state,1);
lf=log(fver);
LL=-ones(1,T)*lf;
if isreal(LL)==0 | any(sum(param0(4:5,:))>0.99)
    LL=1e6;
end
%%%%%%%%%Kim's algorithm%%%%%%%%%%%%%%%%%%%%
 xitT=zeros(T-1,n_state);
    xitT=[xitT; xitt(T,:)];
for t=1:T-1
    a=xitt(T-t,:)'.*(P'*(xitT(T-t+1,:)'./xit1t(T+1-t,:)'));
    xitT(T-t,:)=a';
end
%save marginal features
output.MarginalSet.info.p = p;
output.MarginalSet.info.q = q;
output.MarginalSet.info.swarchtype = swarchtype;
output.MarginalSet.info.errortype = errortype;
output.MarginalSet.mean = mu;
output.MarginalSet.sigma2 = sigma2;
output.MarginalSet.u = u;
output.MarginalSet.errors = errors;
output.MarginalSet.param = param0;
output.MarginalSet.paramtr = paramtr0;
output.MarginalSet.data = data;
output.MarginalSet.f=f;
%save copula fetures
output.CopulaSet.info.copula=copulaeset;
output.CopulaSet.info.n_param_cop=n_param_cop(2:end,:);
output.CopulaSet.param=copulaparam0;
output.CopulaSet.paramtr=copulaparamtr;
output.CopulaSet.paramhat=phat;
output.CopulaSet.uc=uc;
output.CopulaSet.CL=f_cop;
output.SM.P=P;
output.SM.param=[p11;p22];
output.SM.paramtr=paramtr(end-1:end);
output.SM.xtt = xitt;
output.SM.xt1t = xit1t;
output.SM.xtT = xitT;
output.CL = fver;
output.LL = LL;
end