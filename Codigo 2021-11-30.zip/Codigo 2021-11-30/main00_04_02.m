clear all;
clc;

%% Import series
[prices_total,Date_total] = xlsread('datos datastream',4,'A2:D5588'); 
    % Sheet 1: Europe; Sheet 2: Japan; Sheet 3: Brazil; Sheet 4: UK
    
% prices = prices_total(1:4957,:); % Sample: 01/2001-12/2019
prices = prices_total(1:5218,:); % Sample: 01/2000-12/2019
Date = Date_total(1:5218);

% Weekly data
datenumer=datetime(Date, 'InputFormat', 'dd/MM/yyyy');
DayNumber = weekday(datenumer); %get the day of the week of each day
% Check that we have weekly data and not biweekly data
vec = DayNumber==6; % vector de fechas que coinciden en viernes
idx = find(vec==1) ;
iwant = diff(idx)-1;
clear iwant idx vec

DateW = Date((DayNumber==6)); % Friday quote
datewt = datetime(DateW, 'InputFormat', 'dd/MM/yyyy');
datewt2 = datewt(5:end);
Tp = length(DateW);
exc_rate = prices((DayNumber==6),1); % Exchange rate EUR/USD
stock = prices((DayNumber==6),2); % EUROSTOXX
gold = prices((DayNumber==6),3); % Gold
pricesw = [exc_rate, stock, gold]; 

% Calculate logaritmic returns
returns = log(pricesw(2:end,:)./pricesw(1:end-1,:));
r_fx = returns(:,1); % Variations of exchange rate 
r_st = returns(:,2); % Logaritmic returns of stock index
r_gold = returns(:,3); % Logaritmic returns of gold
returns = [r_fx, r_st, r_gold];
T = length(returns);


%% Marginal models
% garchtype = [{'GARCH'},{'GJR'},{'EWMA'},{'APARCH'},{'GARCHM'}];
% errortype = [{'Gaussian'}, {'t'}, {'Skewedt'}];

P = [1, 1, 1]; % AR lags
    % Europe: P_vec = [4, 1, 1]; UK: P_vec = [1, 1, 1]; 
    % Japan: P_vec = [1, 1, 1]; Brazil: P_vec = [1, 1, 1];
Q = [1, 13, 1]; % MA lags
    % Europe: Q_vec = [11, 13, 1]; UK: Q_vec = [1, 13, 1]; 
    % Japan: Q_vec = [1, 1, 1]; Brazil: Q_vec = [1, 1, 1];

options = optimset('Display','notify','MaxFunEvals',1.0e6,'MaxIter',1.0e6,'TolFun',1.0e-5);

% Exchange rate 
[params_fx,u_fx,mu_fx,sigma2_fx,z_fx,LLF_fx] = ...
            EstimateModel(r_fx,P(1),Q(1),'APARCH','Skewedt',options);
[aic_fx,bic_fx] = aicbic(LLF_fx,length(params_fx),T);

% Stock 
[params_st,u_st,mu_st,sigma2_st,z_st,LLF_st] = ...
            EstimateModel(r_st,P(2),Q(2),'APARCH','Skewedt',options);
[aic_st,bic_st] = aicbic(LLF_st,length(params_st),T); 

% Gold
[params_gold,u_gold,mu_gold,sigma2_gold,z_gold,LLF_gold] = ...
            EstimateModel(r_gold,P(3),Q(3),'APARCH','Skewedt',options);
[aic_gold,bic_gold] = aicbic(LLF_gold,length(params_gold),T);      

T2 = length(u_fx); %746


%% DCC for three variables (elliptical copulae)
TT = min(length(u_fx), min(length(u_st),length(u_gold)));
unif = [u_fx(end-TT+1:end), u_st(end-TT+1:end), u_gold(end-TT+1:end)];
alpha0 = 0.04;  
beta0 = 0.92;
nu0 = 4.0;
param0 = [alpha0 beta0];
param0t = [alpha0 beta0 nu0];

[lnL_dcc,dcc12,dcc13,dcc23,param_opt] = dcc_garch(unif,param0,datewt2(end-TT+1:end),1); % dist==1: Normal
param_opt
[lnL_dcc2,dcc12t,dcc13t,dcc23t,param_optt] = dcc_garch(unif,param0t,datewt2(end-TT+1:end),2); % dist==2: Student t
param_optt

createfigure_compare_dcc(datewt2,[dcc12,dcc12t],[dcc13,dcc13t],[dcc23,dcc23t])


%% Rolling window to obtain dynamic correlations
Sigma_rw_normal = corr_rolling_window(unif,datewt2,param_opt,1); % dist=1: innovations are Normal
Sigma_rw_t = corr_rolling_window(unif,datewt2,param_optt,2); % dist=2: innovations are Student t

%%
save('Main_UK2_nuevo')
