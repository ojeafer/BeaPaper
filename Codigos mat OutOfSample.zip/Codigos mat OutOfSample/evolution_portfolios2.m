clear all
clc

load('Forecast_Europe')
load('Portfolios_Gaussian_Europe')

%% Sample
w_mv2_is = w_mv2;
w_mES2_is = w_mES2;
Volat_min_is = Volat_min;
ES_min_is = ES_min;

w_mv3_is = w_mv3;
w_mES3_is = w_mES3;
Volat_min3_is = Volat_min3;
ES_min3_is = ES_min3;


%% Out-of-sample
w_mv2_oos = Portfolios_Forecast.Normal.Month.w2.W_mv;
w_mES2_oos = Portfolios_Forecast.Normal.Month.w2.W_mES;
Volat_min_oos = Portfolios_Forecast.Normal.Month.w2.Volat_min;
ES_min_oos = Portfolios_Forecast.Normal.Month.w2.ES_min;

w_mv3_oos = Portfolios_Forecast.Normal.Month.w3.W_mv;
w_mES3_oos = Portfolios_Forecast.Normal.Month.w3.W_mES;
Volat_min3_oos = Portfolios_Forecast.Normal.Month.w3.Volat_min;
ES_min3_oos = Portfolios_Forecast.Normal.Month.w3.ES_min;


%% A 29/12/2019 (última fecha de la muestra)
% a) Precio de los activos
price_2019Q4 = prices(end,:); % Ultimo precio de la muestra hasta 2019

% b) Pesos de los activos en las carteras de minimo-ES
w_mES2_end = [0;w_mES2_is(2:3,end)];
w_mES3_end = [w_mES3_is(1,end)-w_mES3_is(3,end); w_mES3_is(2,end); w_mES3_is(3,end)];


%% A principios de 2020 (primera fecha de la muestra del forecast)
% a) Pesos de los activos out-of-sample en las carteras
w_mES2_2020Q1 = [zeros(1,size(w_mES2_oos,2)); w_mES2_oos(2:3,1:end)];
w_mES3_2020Q1 = [w_mES3_oos(1,1:end)-w_mES3_oos(3,1:end); 
                 w_mES3_oos(2,1:end); 
                 w_mES3_oos(3,1:end)]; % size = NxT

    % Reordenamos los pesos para poderlos representar
    y1 = [w_mES2_2020Q1(:,1)'; w_mES3_2020Q1(:,1)'];
    y2 = [w_mES2_2020Q1(:,2)'; w_mES3_2020Q1(:,2)'];
    y3 = [w_mES2_2020Q1(:,3)'; w_mES3_2020Q1(:,3)'];
    Y = [y1; y2; y3];
    

% b) Variación de los precios en la primera semana del 2020
price_2020Q1 = pricesw_forecast; % Primer precio de la muestra out-of-sample
    pricem_2020Q1 = [price_2019Q4; 
                     price_2020Q1(3,:);
                     price_2020Q1(5,:);
                     price_2020Q1(7,:);
                     price_2020Q1(9,:);
                     price_2020Q1(12,:);
                     price_2020Q1(15,:);
                     price_2020Q1(18,:);
                     price_2020Q1(21,:);
                     price_2020Q1(24,:)];  % size = TxN
                 % Ponemos como primer valor el último dato de 2019 para
                 % luego utilizarlo al calcular los rendimientos (ratio_price)

t = 2:size(pricem_2020Q1,1);
ratio_price1 = pricem_2020Q1(t,:)./pricem_2020Q1(t-1,:) - 1;
    ratio_price = ratio_price1';  % size = NxT

evol_price_portfolio2 = sum((ratio_price .* w_mES2_oos(:,1:end-1)),1);
evol_price_portfolio3 = sum((ratio_price .* w_mES3_oos(:,1:end-1)),1);

    evol_prices = [evol_price_portfolio2(1), evol_price_portfolio3(1),...
                   evol_price_portfolio2(2), evol_price_portfolio3(2),...
                   evol_price_portfolio2(3), evol_price_portfolio3(3)]


% c) Variacion del ES de la cartera segun el modelo
    % Reordenamos los ES para la representación
evol_ES_model = [ES_min_oos(1), ES_min3_oos(1),...
                 ES_min_oos(2), ES_min3_oos(2),...
                 ES_min_oos(3), ES_min3_oos(3)]            


%% d) Rendimiento medio de la cartera
mean_price = NaN(3,4); mean_price(:,:) = mean(Pt,1);
vec_price = [price_2019Q4', mean_price];
returns_oos = vec_price(:,t)./vec_price(:,t-1) - 1;
mean_return_portfolio2 = sum((returns_oos .* w_mES2_oos(:,1:end-1)),1);
mean_return_portfolio3 = sum((returns_oos .* w_mES3_oos(:,1:end-1)),1);
evol_return_model = [mean_return_portfolio2(1), mean_return_portfolio3(1),...
                     mean_return_portfolio2(2), mean_return_portfolio3(2),...
                     mean_return_portfolio2(3), mean_return_portfolio3(3)]


%% Plot
c = categorical({'2020M1 (1)','2020M1 (2)', '2020M2 (1)','2020M2 (2)', '2020M3 (1)','2020M3 (2)'});
figure
haxes = axes();
hBar = bar(c,Y*100, 'stacked')
    set(hBar(1), 'FaceAlpha',0.4,'DisplayName','Exchange rate',...
        'FaceColor',[0.678431391716003 0.921568632125854 1]);
    set(hBar(2), 'FaceAlpha',0.4,'DisplayName','Stock',...
        'FaceColor',[0.39215686917305 0.474509805440903 0.635294139385223]);
    set(hBar(3), 'FaceAlpha',0.4,'DisplayName','Gold',...
        'FaceColor',[0.952941179275513 0.87058824300766 0.733333349227905]);
grid on
grid minor
set(haxes,'FontSize',15,'TickLabelInterpreter','latex');
ylabel('Weights $(\%)$','interpreter','latex')
xlabel('Date','interpreter','latex')

yyaxis(haxes,'right');
hPlot = plot(evol_prices*100,'x','MarkerSize',12,'MarkerEdgeColor',[1 .5 .5],'LineWidth',2.0) 
hold on
plot(evol_ES_model*100, 'o','MarkerSize',12,'MarkerEdgeColor',[1 .5 .5],'LineWidth',2.0) 
% plot(evol_return_model*100, 'd','MarkerSize',12,'MarkerEdgeColor',[1 .5 .5],'LineWidth',2.0) 
% plot(c,repmat(0.0,1,6),'--k')
yyLabel = ylabel('Returns $(\%)$','interpreter','latex');
set(yyLabel,'Color',[1 .5 .5]);
set(haxes,'YColor',[1 .5 .5]);
ylim([-8,5])
legend('Weight of the extra-investment in exchange rate','Weight of stock',...
       'Weight of gold','Real return of the portfolio','ES of the model','Expected return of the portfolio',...
       'Location','northeast','interpreter','latex')
title('Performance of the portfolio','interpreter','latex')
