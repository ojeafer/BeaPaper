clear all
clc

load('Main_Europe')

%% Forecast for returns (from 01/01/2020 to 01/05/2020)
Date_forecast = Date_total(4951:end);
DayNumber = weekday(datestr(Date_forecast));
% Check that we have weekly data and not biweekly data
vec = DayNumber==6; % vector de fechas que coinciden en viernes
idx = find(vec==1) ;
iwant = diff(idx)-1;
clear iwant idx vec
DateWF = Date_forecast((DayNumber==6)); % Friday quote
datef = datetime(DateWF, 'InputFormat', 'dd/MM/yyyy');

prices_forecast = prices_total(4951:end,:);
    exc_rate_forecast = prices_forecast((DayNumber==6),1); % Exchange rate EUR/USD
    stock_forecast = prices_forecast((DayNumber==6),2); % EUROSTOXX
    gold_forecast = prices_forecast((DayNumber==6),3); % Gold
pricesw_forecast = [exc_rate_forecast, stock_forecast, gold_forecast]; 
returns_forecast = log(pricesw_forecast(2:end,:)./pricesw_forecast(1:end-1,:));
    r_fx_forecast = returns_forecast(:,1);
    r_st_forecast = returns_forecast(:,2);
    r_gold_forecast = returns_forecast(:,3);
datef2 = datef(2:end);


%% Simulate returns (3 months)
T_f = size(returns_forecast,1);
W = 5e4;

% params_st2 = [params_st(1:7); 2.0; params_st(end-1:end)]; % for Brazil

% Simulate Gaussian copula
[R_forecast.Normal,u_forecast.Normal,sigma.Normal,mu.Normal] = ...
    simul(returns,[dcc12(end);dcc13(end);dcc23(end)],[params_fx,params_st,params_gold],param_opt,W,T_f);
    % R_forecast = TxWxN \equiv 9x50000x3
                        
% Simulate Student t copula 
[R_forecast.Student,u_forecast.Student,sigma.Student,mu.Student] = ...
    simul(returns,[dcc12t(end);dcc13t(end);dcc23t(end)],[params_fx,params_st,params_gold],param_optt,W,T_f);


%% Compute monthly returns (from January to September, i.e. 2020Q1-2020Q3)
R_month.Normal(1,:,:) = sum(R_forecast.Normal(1:2,:,:),1);
R_month.Normal(2,:,:) = sum(R_forecast.Normal(3:4,:,:),1);
R_month.Normal(3,:,:) = sum(R_forecast.Normal(5:6,:,:),1);
R_month.Normal(4,:,:) = sum(R_forecast.Normal(7:8,:,:),1);
R_month.Normal(5,:,:) = sum(R_forecast.Normal(9:11,:,:),1);
R_month.Normal(6,:,:) = sum(R_forecast.Normal(12:14,:,:),1);
R_month.Normal(7,:,:) = sum(R_forecast.Normal(15:17,:,:),1);
R_month.Normal(8,:,:) = sum(R_forecast.Normal(18:20,:,:),1);
R_month.Normal(9,:,:) = sum(R_forecast.Normal(21:23,:,:),1);
% R_month.Normal(10,:,:) = sum(R_forecast.Normal(24:26,:,:),1);

R_month.Student(1,:,:) = sum(R_forecast.Student(1:2,:,:),1);
R_month.Student(2,:,:) = sum(R_forecast.Student(3:4,:,:),1);
R_month.Student(3,:,:) = sum(R_forecast.Student(5:6,:,:),1);
R_month.Student(4,:,:) = sum(R_forecast.Student(7:9,:,:),1);
R_month.Student(5,:,:) = sum(R_forecast.Student(9:11,:,:),1);
R_month.Student(6,:,:) = sum(R_forecast.Student(12:14,:,:),1);
R_month.Student(7,:,:) = sum(R_forecast.Student(15:17,:,:),1);
R_month.Student(8,:,:) = sum(R_forecast.Student(18:20,:,:),1);
R_month.Student(9,:,:) = sum(R_forecast.Student(21:23,:,:),1);
% R_month.Student(10,:,:) = sum(R_forecast.Student(24:26,:,:),1);

datef2_m = [datef2(1), datef2(3), datef2(5), datef2(7), datef2(9),...
            datef2(12), datef2(14), datef2(18), datef2(21), datef2(23)];


%% Compute quartly returns
R_quart.Normal(1,:,:) = sum(R_month.Normal(1:3,:,:),1);
R_quart.Normal(2,:,:) = sum(R_month.Normal(4:6,:,:),1);
R_quart.Normal(3,:,:) = sum(R_month.Normal(7:9,:,:),1);

R_quart.Student(1,:,:) = sum(R_month.Student(1:3,:,:),1);
R_quart.Student(2,:,:) = sum(R_month.Student(4:6,:,:),1);
R_quart.Student(3,:,:) = sum(R_month.Student(7:9,:,:),1);

datef2_q = [datef2(1), datef2(7), datef2(14), datef2(23)];

%% Use aritmetic returns instead logaritmic returns
R_arit.Normal = exp(R_forecast.Normal)-1;
R_arit_month.Normal = exp(R_month.Normal)-1;
R_arit_quart.Normal = exp(R_quart.Normal)-1;

R_arit.Student = exp(R_forecast.Student)-1;
R_arit_month.Student = exp(R_month.Student)-1;
R_arit_quart.Student = exp(R_quart.Student)-1;

% * Usamos rendimientos aritméticos para explicar mejor la performance de la
% cartera y ver los resultados


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Construct portfolios 
%% GAUSSIAN COPULA
%%% Weekly returns
Rw = permute(R_arit.Normal(2:end,:,:),[2,3,1]); 

% Equally-weighted portfolio without extra investment in FX
Portfolios_Forecast.Normal.Week.w2.W_ew = [0.5; 0.5; 0.5];

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Normal.Week.w2.W_mv, Portfolios_Forecast.Normal.Week.w2.Sigma2_min,...
    Portfolios_Forecast.Normal.Week.w2.W_mES, Portfolios_Forecast.Normal.Week.w2.ES_min] = ...
    weights_minVar_minES(Rw,size(Rw,3),2);
h = 52; % Annualized volatility
Portfolios_Forecast.Normal.Week.w2.Volat_min = (Portfolios_Forecast.Normal.Week.w2.Sigma2_min * h).^0.5; 


% Equally-weighted portfolio with extra investment in FX
Portfolios_Forecast.Normal.Week.w3.W_ew = [1/3; 1/3; 1/3];

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Normal.Week.w3.W_mv, Portfolios_Forecast.Normal.Week.w3.Sigma2_min,...
    Portfolios_Forecast.Normal.Week.w3.W_mES, Portfolios_Forecast.Normal.Week.w3.ES_min] = ...
    weights_minVar_minES(Rw,size(Rw,3),3);
Portfolios_Forecast.Normal.Week.w3.Volat_min = (Portfolios_Forecast.Normal.Week.w3.Sigma2_min * h).^0.5; 

%%
%%% Monthly returns
Rm = permute(R_arit_month.Normal,[2,3,1]); 

% Equally-weighted portfolio without extra investment in FX
Portfolios_Forecast.Normal.Month.w2.W_ew = [0.5; 0.5; 0.5];

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Normal.Month.w2.W_mv, Portfolios_Forecast.Normal.Month.w2.Sigma2_min,...
    Portfolios_Forecast.Normal.Month.w2.W_mES, Portfolios_Forecast.Normal.Month.w2.ES_min] = ...
    weights_minVar_minES(Rm,size(Rm,3),2);
h = 52; % Annualized volatility
Portfolios_Forecast.Normal.Month.w2.Volat_min = (Portfolios_Forecast.Normal.Month.w2.Sigma2_min * h).^0.5; 


% Equally-weighted portfolio with extra investment in FX
Portfolios_Forecast.Normal.Month.w3.W_ew = [1/3; 1/3; 1/3];

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Normal.Month.w3.W_mv, Portfolios_Forecast.Normal.Month.w3.Sigma2_min,...
    Portfolios_Forecast.Normal.Month.w3.W_mES, Portfolios_Forecast.Normal.Month.w3.ES_min] = ...
    weights_minVar_minES(Rm,size(Rm,3),3);
Portfolios_Forecast.Normal.Month.w3.Volat_min = (Portfolios_Forecast.Normal.Month.w3.Sigma2_min * h).^0.5; 

%%% Quarterly returns
Rt = permute(R_arit_quart.Normal,[2,3,1]); 

% Equally-weighted portfolio without extra investment in FX
Portfolios_Forecast.Normal.Quarter.w2.W_ew = [0.5; 0.5; 0.5];

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Normal.Quarter.w2.W_mv, Portfolios_Forecast.Normal.Quarter.w2.Sigma2_min,...
    Portfolios_Forecast.Normal.Quarter.w2.W_mES, Portfolios_Forecast.Normal.Quarter.w2.ES_min] = ...
    weights_minVar_minES(Rt,size(Rt,3),2);
h = 52; % Annualized volatility
Portfolios_Forecast.Normal.Quarter.w2.Volat_min = (Portfolios_Forecast.Normal.Quarter.w2.Sigma2_min * h).^0.5; 


% Equally-weighted portfolio with extra investment in FX
Portfolios_Forecast.Normal.Quarter.w3.W_ew = [1/3; 1/3; 1/3];

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Normal.Quarter.w3.W_mv, Portfolios_Forecast.Normal.Quarter.w3.Sigma2_min,...
    Portfolios_Forecast.Normal.Quarter.w3.W_mES, Portfolios_Forecast.Normal.Quarter.w3.ES_min] = ...
    weights_minVar_minES(Rt,size(Rt,3),3);
Portfolios_Forecast.Normal.Quarter.w3.Volat_min = (Portfolios_Forecast.Normal.Quarter.w3.Sigma2_min * h).^0.5; 


%% STUDENT T COPULA
%%% Weekly returns
Rw2 = permute(R_arit.Student(2:end,:,:),[2,3,1]); 

% Equally-weighted portfolio without extra investment in FX
Portfolios_Forecast.Student.Week.w2.W_ew = [0.5; 0.5; 0.5];

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Student.Week.w2.W_mv, Portfolios_Forecast.Student.Week.w2.Sigma2_min,...
    Portfolios_Forecast.Student.Week.w2.W_mES, Portfolios_Forecast.Student.Week.w2.ES_min] = ...
    weights_minVar_minES(Rw2,size(Rw2,3),2);
h = 52; % Annualized volatility
Portfolios_Forecast.Student.Week.w2.Volat_min = (Portfolios_Forecast.Student.Week.w2.Sigma2_min * h).^0.5; 


% Equally-weighted portfolio with extra investment in FX
Portfolios_Forecast.Student.Week.w3.W_ew = [1/3; 1/3; 1/3];

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Student.Week.w3.W_mv, Portfolios_Forecast.Student.Week.w3.Sigma2_min,...
    Portfolios_Forecast.Student.Week.w3.W_mES, Portfolios_Forecast.Student.Week.w3.ES_min] = ...
    weights_minVar_minES(Rw2,size(Rw2,3),3);
Portfolios_Forecast.Student.Week.w3.Volat_min = (Portfolios_Forecast.Student.Week.w3.Sigma2_min * h).^0.5; 

%%
%%% Monthly returns
Rm2 = permute(R_arit_month.Student,[2,3,1]); 

% Equally-weighted portfolio without extra investment in FX
Portfolios_Forecast.Student.Month.w2.W_ew = [0.5; 0.5; 0.5];

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Student.Month.w2.W_mv, Portfolios_Forecast.Student.Month.w2.Sigma2_min,...
    Portfolios_Forecast.Student.Month.w2.W_mES, Portfolios_Forecast.Student.Month.w2.ES_min] = ...
    weights_minVar_minES(Rm2,size(Rm2,3),2);
h = 52; % Annualized volatility
Portfolios_Forecast.Student.Month.w2.Volat_min = (Portfolios_Forecast.Student.Month.w2.Sigma2_min * h).^0.5; 


% Equally-weighted portfolio with extra investment in FX
Portfolios_Forecast.Student.Month.w3.W_ew = [1/3; 1/3; 1/3];

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Student.Month.w3.W_mv, Portfolios_Forecast.Student.Month.w3.Sigma2_min,...
    Portfolios_Forecast.Student.Month.w3.W_mES, Portfolios_Forecast.Student.Month.w3.ES_min] = ...
    weights_minVar_minES(Rm2,size(Rm2,3),3);
Portfolios_Forecast.Student.Month.w3.Volat_min = (Portfolios_Forecast.Student.Month.w3.Sigma2_min * h).^0.5; 

%%% Quarterly returns
Rt2 = permute(R_arit_quart.Student,[2,3,1]); 

% Equally-weighted portfolio without extra investment in FX
Portfolios_Forecast.Student.Quarter.w2.W_ew = [0.5; 0.5; 0.5];

% Minimum-variance and minimum-ES portfolios without extra investment in FX
[Portfolios_Forecast.Student.Quarter.w2.W_mv, Portfolios_Forecast.Student.Quarter.w2.Sigma2_min,...
    Portfolios_Forecast.Student.Quarter.w2.W_mES, Portfolios_Forecast.Student.Quarter.w2.ES_min] = ...
    weights_minVar_minES(Rt2,size(Rt2,3),2);
h = 52; % Annualized volatility
Portfolios_Forecast.Student.Quarter.w2.Volat_min = (Portfolios_Forecast.Student.Quarter.w2.Sigma2_min * h).^0.5; 


% Equally-weighted portfolio with extra investment in FX
Portfolios_Forecast.Student.Quarter.w3.W_ew = [1/3; 1/3; 1/3];

% Minimum-variance and minimum-ES portfolios with extra investment in FX
[Portfolios_Forecast.Student.Quarter.w3.W_mv, Portfolios_Forecast.Student.Quarter.w3.Sigma2_min,...
    Portfolios_Forecast.Student.Quarter.w3.W_mES, Portfolios_Forecast.Student.Quarter.w3.ES_min] = ...
    weights_minVar_minES(Rt2,size(Rt2,3),3);
Portfolios_Forecast.Student.Quarter.w3.Volat_min = (Portfolios_Forecast.Student.Quarter.w3.Sigma2_min * h).^0.5; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% For the plot
%% a) Expected returns (model)
% R_arit_mean.Normal = NaN(size(R_arit.Normal,1), size(R_arit.Normal,3));
R_arit_month_mean.Normal = NaN(size(R_arit_month.Normal,1), size(R_arit_month.Normal,3));
R_arit_quart_mean.Normal = NaN(size(R_arit_quart.Normal,1), size(R_arit_quart.Normal,3));
% R_arit_mean.Student = NaN(size(R_arit.Student,1), size(R_arit.Student,3));
R_arit_month_mean.Student = NaN(size(R_arit_month.Student,1), size(R_arit_month.Student,3));
R_arit_quart_mean.Student = NaN(size(R_arit_quart.Student,1), size(R_arit_quart.Student,3));

% R_arit_mean.Normal(:,:) = mean(R_arit.Normal,2);
%     R_portfolio2.Normal = sum(R_arit_mean.Normal(2:end,:)' .* Portfolios_Forecast.Normal.Week.w2.W_mES,1);
%     R_portfolio3.Normal = sum(R_arit_mean.Normal(2:end,:)' .* Portfolios_Forecast.Normal.Week.w3.W_mES,1);
    
R_arit_month_mean.Normal(:,:) = mean(R_arit_month.Normal,2);
    R_portfolio_month2.Normal = sum(R_arit_month_mean.Normal' .* Portfolios_Forecast.Normal.Month.w2.W_mES,1);
    R_portfolio_month3.Normal = sum(R_arit_month_mean.Normal' .* Portfolios_Forecast.Normal.Month.w3.W_mES,1);

R_arit_quart_mean.Normal(:,:) = mean(R_arit_quart.Normal,2);
    R_portfolio_quart2.Normal = sum(R_arit_quart_mean.Normal' .* Portfolios_Forecast.Normal.Quarter.w2.W_mES,1);
    R_portfolio_quart3.Normal = sum(R_arit_quart_mean.Normal' .* Portfolios_Forecast.Normal.Quarter.w3.W_mES,1);

% R_arit_mean.Student(:,:) = mean(R_arit.Student,2);
%     R_portfolio2.Student = sum(R_arit_mean.Student(2:end,:)' .* Portfolios_Forecast.Student.Week.w2.W_mES,1);
%     R_portfolio3.Student = sum(R_arit_mean.Student(2:end,:)' .* Portfolios_Forecast.Student.Week.w3.W_mES,1);
    
R_arit_month_mean.Student(:,:) = mean(R_arit_month.Student,2);
    R_portfolio_month2.Student = sum(R_arit_month_mean.Student' .* Portfolios_Forecast.Student.Month.w2.W_mES,1);
    R_portfolio_month3.Student = sum(R_arit_month_mean.Student' .* Portfolios_Forecast.Student.Month.w3.W_mES,1);

R_arit_quart_mean.Student(:,:) = mean(R_arit_quart.Student,2);
    R_portfolio_quart2.Student = sum(R_arit_quart_mean.Student' .* Portfolios_Forecast.Student.Quarter.w2.W_mES,1);
    R_portfolio_quart3.Student = sum(R_arit_quart_mean.Student' .* Portfolios_Forecast.Student.Quarter.w3.W_mES,1);


%% b) Expected Shortfall (model)
% ES_min2.Normal = Portfolios_Forecast.Normal.Week.w2.ES_min;
% ES_min3.Normal = Portfolios_Forecast.Normal.Week.w3.ES_min;
ES_min2_month.Normal = Portfolios_Forecast.Normal.Month.w2.ES_min;
ES_min3_month.Normal = Portfolios_Forecast.Normal.Month.w3.ES_min;
ES_min2_quart.Normal = Portfolios_Forecast.Normal.Quarter.w2.ES_min;
ES_min3_quart.Normal = Portfolios_Forecast.Normal.Quarter.w3.ES_min;

% ES_min2.Student = Portfolios_Forecast.Student.Week.w2.ES_min;
% ES_min3.Student = Portfolios_Forecast.Student.Week.w3.ES_min;
ES_min2_month.Student = Portfolios_Forecast.Student.Month.w2.ES_min;
ES_min3_month.Student = Portfolios_Forecast.Student.Month.w3.ES_min;
ES_min2_quart.Student = Portfolios_Forecast.Student.Quarter.w2.ES_min;
ES_min3_quart.Student = Portfolios_Forecast.Student.Quarter.w3.ES_min;


%% c) Evolution of the weights
% w_mES2.Normal = Portfolios_Forecast.Normal.Week.w2.W_mES;
% w_mES3.Normal = Portfolios_Forecast.Normal.Week.w3.W_mES;
w_mES2_month.Normal = Portfolios_Forecast.Normal.Month.w2.W_mES;
w_mES3_month.Normal = Portfolios_Forecast.Normal.Month.w3.W_mES;
w_mES2_quart.Normal = Portfolios_Forecast.Normal.Quarter.w2.W_mES;
w_mES3_quart.Normal = Portfolios_Forecast.Normal.Quarter.w3.W_mES;

% w_mES2.Student = Portfolios_Forecast.Student.Week.w2.W_mES;
% w_mES3.Student = Portfolios_Forecast.Student.Week.w3.W_mES;
w_mES2_month.Student = Portfolios_Forecast.Student.Month.w2.W_mES;
w_mES3_month.Student = Portfolios_Forecast.Student.Month.w3.W_mES;
w_mES2_quart.Student = Portfolios_Forecast.Student.Quarter.w2.W_mES;
w_mES3_quart.Student = Portfolios_Forecast.Student.Quarter.w3.W_mES;


%% d) Real returns
price_2019Q4 = prices(end,:); % Ultimo precio de la muestra hasta 2019
price_2020 = pricesw_forecast; % Primer precio de la muestra out-of-sample
    pricem_2020 = [price_2019Q4; 
                   price_2020(2,:);
                   price_2020(4,:);
                   price_2020(6,:);
                   price_2020(8,:);
                   price_2020(11,:);
                   price_2020(14,:);
                   price_2020(17,:);
                   price_2020(20,:);
                   price_2020(23,:)];  % size = TxN
                 % Ponemos como primer valor el último dato de 2019 para
                 % luego utilizarlo al calcular los rendimientos (ratio_price)
    priceq_2020 = [price_2019Q4; 
                   pricem_2020(3,:);
                   pricem_2020(6,:);
                   pricem_2020(8,:)];

% t0 = 3:size(price_2020,1);
% ratio_price1w = price_2020(t0,:)./price_2020(t0-1,:) - 1;
%     ratio_pricew = ratio_price1w';  % size = NxT
t = 2:size(pricem_2020,1);
ratio_price1m = pricem_2020(t,:)./pricem_2020(t-1,:) - 1;
    ratio_pricem = ratio_price1m';  % size = NxT
tt = 2:size(priceq_2020,1);
ratio_price1q = priceq_2020(tt,:)./priceq_2020(tt-1,:) - 1;
    ratio_priceq = ratio_price1q';  % size = NxT

% return_real2.Normal = sum((ratio_pricew .* w_mES2.Normal),1);
% return_real3.Normal = sum((ratio_pricew .* w_mES3.Normal),1);
return_real_month2.Normal = sum((ratio_pricem .* w_mES2_month.Normal),1);
return_real_month3.Normal = sum((ratio_pricem .* w_mES3_month.Normal),1);
return_real_quart2.Normal = sum((ratio_priceq .* w_mES2_quart.Normal),1);
return_real_quart3.Normal = sum((ratio_priceq .* w_mES3_quart.Normal),1);

% return_real2.Student = sum((ratio_pricew .* w_mES2.Student),1);
% return_real3.Student = sum((ratio_pricew .* w_mES3.Student),1);
return_real_month2.Student = sum((ratio_pricem .* w_mES2_month.Student),1);
return_real_month3.Student = sum((ratio_pricem .* w_mES3_month.Student),1);
return_real_quart2.Student = sum((ratio_priceq .* w_mES2_quart.Student),1);
return_real_quart3.Student = sum((ratio_priceq .* w_mES3_quart.Student),1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot monthly-forecast
t1 = datetime('2020-01-01');
t2 = datetime('2020-09-05');
date_plot_forecast = t1:caldays(31):t2;
date_plot_forecast(end) = datetime('2020-09-01');

for i = 3:4
    if i == 1
        evol_ES_model = ES_min2_month.Normal';
        w_mES = [w_mES2_month.Normal(3,:); w_mES2_month.Normal(2,:)];
        evol_prices = return_real_month2.Normal';
        
    elseif i == 2
        evol_ES_model = ES_min3_month.Normal';
        w_mES = [w_mES3_month.Normal(1,:)-w_mES3_month.Normal(3,:); ...
                 w_mES3_month.Normal(2,:); ...
                 w_mES3_month.Normal(3,:)];
        evol_prices = return_real_month3.Normal';
        
    elseif i == 3
        evol_ES_model = ES_min2_month.Student';
        w_mES = [w_mES2_month.Student(3,:); w_mES2_month.Student(2,:)];
        evol_prices = return_real_month2.Student';
        
    elseif i == 4
        evol_ES_model = ES_min3_month.Student';
        w_mES = [w_mES3_month.Student(1,:)-w_mES3_month.Student(3,:); ...
                 w_mES3_month.Student(2,:); ...
                 w_mES3_month.Student(3,:)];
        evol_prices = return_real_month3.Student';
    end
    
    if rem(i,2) == 0 
        w = 3;
    else 
        w = 2;
    end

    createfigure_performance_forecast2(date_plot_forecast, w_mES'*100, ...
                    [evol_prices, evol_ES_model]'*100, w)
end


%% Comparison between models
YMatrix1 = [abs(ES_min2_month.Normal);
            abs(ES_min3_month.Normal);
            abs(ES_min2_month.Student);
            abs(ES_min3_month.Student)]*100;
% Y1 = [(return_real_month2.Normal-return_real_month2.Student);
%       (return_real_month3.Normal-return_real_month3.Student)]*100;
  
createfigure_comparison_forecast2(date_plot_forecast, YMatrix1)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
tic
save('Forecast_Europe', 'Date_total','Date_forecast','datef','datef2','datef2_m',...
    'datef2_q', 'date_plot_forecast','R_quart','R_arit_quart','R_arit_month_mean',...
    'R_arit_quart_mean','R_portfolio_month2','R_portfolio_month3','pricem_2020',...
    'R_portfolio_quart2','R_portfolio_quart3','priceq_2020','ratio_pricem','ratio_priceq',...
    'return_real_month2','return_real_month3','return_real_quart2','return_real_quart3',...
    'DateWF','datewt2','exc_rate','exc_rate_forecast','gold','gold_forecast',...
    'stock','stock_forecast','h','params_fx','params_st','params_gold','prices',...
    'prices_forecast','prices_total','Portfolios_Forecast','pricesw_forecast',...
    'R_arit','R_arit_month','R_forecast',...
    'R_month','returns','returns_forecast','r_fx','r_st','r_gold','r_fx_forecast',...
    'r_st_forecast','r_gold_forecast','T2','T_f','u_forecast','W','sigma','mu', '-v7.3')
toc