clear all
clc

load('Forecast_Europe')
load('Portfolios_Gaussian_Europe')

%% Sample
w_mv2_is = w_mv2;
w_mES2_is = w_mES2;
Volat_min_is = Volat_min;
ES_min_is = ES_min;

w_mv3_is = w_mv3;
w_mES3_is = w_mES3;
Volat_min3_is = Volat_min3;
ES_min3_is = ES3_min;


%% Out-of-sample
w_mv2_oos = Portfolios_Forecast.Normal.w2.W_mv;
w_mES2_oos = Portfolios_Forecast.Normal.w2.W_mES;
Volat_min_oos = Portfolios_Forecast.Normal.w2.Volat_min;
ES_min_oos = Portfolios_Forecast.Normal.w2.ES_min;

w_mv3_oos = Portfolios_Forecast.Normal.w3.W_mv;
w_mES3_oos = Portfolios_Forecast.Normal.w3.W_mES;
Volat_min3_oos = Portfolios_Forecast.Normal.w3.Volat_min;
ES_min3_oos = Portfolios_Forecast.Normal.w3.ES_min;

%%
% A 29/12/2019 (última fecha de la muestra)
% a) Precio de los activos
price_2019Q4 = prices(end,:); % Ultimo precio de la muestra hasta 2019
returns_2019Q4 = returns(end,:); % Ultimo rendimiento de la muestra hasta 2019

% b) Pesos de los activos en las carteras de minimo-ES
w_mES2_end1 = w_mES2_is(:,end); 
    w_mES2_end = [0;w_mES2_end1(2:3)];
w_mES3_end1 = w_mES3_is(:,end);
    w_mES3_end = [w_mES3_end1(1)-w_mES3_end1(3); w_mES3_end1(2); w_mES3_end1(3)];


% A principios de 2020 (primera fecha de la muestra del forecast)
% a) Variación de los precios en la primera semana del 2020
price_2020Q1 = pricesw_forecast; % Primer precio de la muestra out-of-sample
    pricem_2020Q1 = [price_2020Q1(2,:); 
                     price_2020Q1(4,:);
                     price_2020Q1(6,:);
                     price_2020Q1(9,:)];
returns_2020Q1 = returns_forecast; % Primer rendimiento de la muestra out-of-sample
    returnsm_2020Q1 = log(pricem_2020Q1(2:end,:)./pricem_2020Q1(1:end-1,:));
    returnsm_arit_2020Q1 = exp(returnsm_2020Q1) - 1; % Rendimientos aritmeticos

ratio_price = [price_2019Q4; pricem_2020Q1(1:end-1,:)]./price_2019Q4;
ratio_returns = [returns_2019Q4; returnsm_2020Q1]./returns_2019Q4;

evol_price_portfolio2 = returnsm_arit_2020Q1 * w_mES2_end;
evol_price_portfolio3 = ratio_price * w_mES3_end; %(1+returnsm_arit_2020Q1) * w_mES3_end
evol_prices = [evol_price_portfolio2(1), evol_price_portfolio3(1),...
               evol_price_portfolio2(2), evol_price_portfolio3(2),...
               evol_price_portfolio2(3), evol_price_portfolio3(3)];

% b) Pesos de los activos out-of-sample en las carteras
w_mES2_2020Q1 = [zeros(1,4); w_mES2_oos(2:3,:)];
w_mES3_2020Q1 = [w_mES3_oos(1,:)-w_mES3_oos(3,:); w_mES3_oos(2,:); w_mES3_oos(3,:)];

% c) Variacion del ES de la cartera segun el modelo
ratio_ES_min = [ES_min_is(end), ES_min_oos] ./ ES_min_is(end);
ratio_ES3_min = [ES_min3_is(end), ES_min3_oos] ./ ES_min3_is(end);

evol_ES_model = [ratio_ES_min(1),ratio_ES3_min(1),...
                 ratio_ES_min(2),ratio_ES3_min(2),...
                 ratio_ES_min(3),ratio_ES3_min(3),...
                 ratio_ES_min(4),ratio_ES3_min(4)];
evol_ES_model2 = [vec_ES_min(1),vec_ES3_min(1),...
                  vec_ES_min(2),vec_ES3_min(2),...
                  vec_ES_min(3),vec_ES3_min(3),...
                  vec_ES_min(4),vec_ES3_min(4)];  

%% Plot
    % Reordenamos los pesos para poderlos representar
    y0 = [w_mES2_end'; w_mES3_end'];
    y1 = [w_mES2_2020Q1(:,1)'; w_mES3_2020Q1(:,1)'];
    y2 = [w_mES2_2020Q1(:,2)'; w_mES3_2020Q1(:,2)'];
    y3 = [w_mES2_2020Q1(:,3)'; w_mES3_2020Q1(:,3)'];
    y4 = [w_mES2_2020Q1(:,4)'; w_mES3_2020Q1(:,4)'];
    Y = [y0; y1; y2; y3];

c = categorical({'2019M12 (1)','2019M12 (2)', '2020M1 (1)','2020M1 (2)', ...
                   '2020M2 (1)','2020M2 (2)', '2020M3 (1)','2020M3 (2)'});
figure
haxes = axes()
hBar = bar(c,Y*100, 'stacked')
    set(hBar(1), 'FaceAlpha',0.4,'DisplayName','Exchange rate',...
        'FaceColor',[0.678431391716003 0.921568632125854 1])
    set(hBar(2), 'FaceAlpha',0.4,'DisplayName','Stock',...
        'FaceColor',[0.39215686917305 0.474509805440903 0.635294139385223])
    set(hBar(3), 'FaceAlpha',0.4,'DisplayName','Gold',...
        'FaceColor',[0.952941179275513 0.87058824300766 0.733333349227905])
grid on
grid minor
set(haxes,'FontSize',15,'TickLabelInterpreter','latex')
ylabel('Weights $(\%)$','interpreter','latex')
xlabel('Date','interpreter','latex')

yyaxis(haxes,'right');
hPlot = plot([1,1,evol_prices]*100,'x','MarkerSize',12,'MarkerEdgeColor',[1 .5 .5],'LineWidth',2.0) 
hold on
plot(abs(evol_ES_model)*100, 'o','MarkerSize',12,'MarkerEdgeColor',[1 .5 .5],'LineWidth',2.0) 
% plot(repmat(100,1,12),':k')
yyLabel = ylabel('Evolution of returns $(\%)$','interpreter','latex')
set(yyLabel,'Color',[1 .5 .5])
set(haxes,'YColor',[1 .5 .5])
ylim([99, 104])
legend('Weight of exchange rate','Weight of stock','Weight of gold','Real returns','ES of the model',...
       'Location','northwest','interpreter','latex')
title('Performance of the portfolio','interpreter','latex')
