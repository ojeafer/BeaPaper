clear all
clc

load('Forecast_Europe')
load('Portfolios_Gaussian_Europe')

%% Sample
w_mv2_is = w_mv2;
w_mES2_is = w_mES2;
Volat_min_is = Volat_min;
% Volat_min_is = sqrt(Sigma2_min*52);
ES_min_is = ES_min;

% w_mv3_is = [w_mv3(1,:)+w_mv3(3,:), w_mv3(2,:), w_mv3(3,:)]';
w_mv3_is = w_var3';
w_mES3_is = w_mES3';
% Volat_min3_is = Volat_min3;
Volat_min3_is = sqrt(Sigma2_min3*52);
ES_min3_is = ES3_min;


%% Out-of-sample
w_mv2_oos = Portfolios_Forecast.Normal.w2.W_mv;
w_mES2_oos = Portfolios_Forecast.Normal.w2.W_mES;
Volat_min_oos = Portfolios_Forecast.Normal.w2.Volat_min;
ES_min_oos = Portfolios_Forecast.Normal.w2.ES_min;

w_mv3_oos = Portfolios_Forecast.Normal.w3.W_mv;
w_mES3_oos = Portfolios_Forecast.Normal.w3.W_mES;
Volat_min3_oos = Portfolios_Forecast.Normal.w3.Volat_min;
ES_min3_oos = Portfolios_Forecast.Normal.w3.ES_min;


%% Union
w_mv2_total = [w_mv2_is, w_mv2_oos];
w_mES2_total = [w_mES2_is, w_mES2_oos];
Volat_min_total = [Volat_min_is, Volat_min_oos];
ES_min_total = [ES_min_is, ES_min_oos];

w_mv3_total = [w_mv3_is, w_mv3_oos];
w_mES3_total = [w_mES3_is, w_mES3_oos];
Volat_min_total3 = [Volat_min3_is, Volat_min3_oos];
ES_min_total3 = [ES_min3_is, ES_min3_oos];

date_portf = [datewt2; datef2_m'];


%% Plots
% Case 1
line_gold2 = repmat(50,1,size(w_mv2_total,2));

createfigure_minVar_2w(date_portf, w_mv2_total(1:2,:)'*100, line_gold2, Volat_min_total*100, 'UK')

createfigure_minES_2w(date_portf, w_mES2_total(1:2,:)'*100, line_gold2, abs(ES_min_total)*100, 1, 'UK') 
                       % abs=1: The ES is expressed in absolute terms

% Case 2
line_gold3 = repmat(1/3*100,1,size(w_mv3_total,2));

w_var3 = [w_mv3_total(1,:)-w_mv3_total(3,:); w_mv3_total(2,:); w_mv3_total(3,:)];
createfigure_minVar_3w(date_portf, w_var3'*100, [line_gold3;line_gold3*2], Volat_min_total3*100, 'UK')

w_es3 = [w_mES3_total(1,:)-w_mES3_total(3,:); w_mES3_total(2,:); w_mES3_total(3,:)];
createfigure_minES_3w(date_portf, w_es3'*100, [line_gold3;line_gold3*2], abs(ES_min_total3)*100, 1, 'UK')


%%
save('TotalPortfolios_Student_Brazil', 'date_portf', ...
     'w_mv2_is', 'w_mES2_is','w_mv3_is', 'w_mES3_is',...
     'Volat_min_is','ES_min_is','Volat_min3_is','ES_min3_is',...
     'w_mv2_oos', 'w_mES2_oos','w_mv3_oos', 'w_mES3_oos',...
     'Volat_min_oos','ES_min_oos','Volat_min3_oos','ES_min3_oos',...
     'w_mv2_total', 'w_mES2_total','w_mv3_total', 'w_mES3_total',...
     'Volat_min_total','ES_min_total','Volat_min_total3','ES_min_total3')
    